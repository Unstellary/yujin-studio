package fr.unstellary.yujinstudio;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Coque Android de Yujin Studio : affiche l'appli web (embarquée dans l'APK),
 * la met à jour toute seule depuis GitHub et enregistre les exports dans la galerie / les téléchargements.
 */
public class MainActivity extends Activity {
    static final String TAG = "YujinStudio";
    static final String HOST = "appassets.androidplatform.net";
    static final String START = "https://" + HOST + "/index.html";
    static final String BASE = "https://raw.githubusercontent.com/Unstellary/yujin-studio/main/";
    static final String APK_INFO = "https://github.com/Unstellary/yujin-studio/releases/latest/download/apk.json";
    static final long CHECK_EVERY = 3L * 60 * 60 * 1000;
    static final int REQ_FILE = 1, REQ_CAM = 2;

    static final String NOTIFIER = "<script>(function(){function bar(t,b,f){var d=document.createElement('div');"
            + "d.style.cssText='position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:2147483647;background:#2a2533;color:#fff;font:15px system-ui,sans-serif;padding:10px 14px;border-radius:14px;box-shadow:0 8px 28px rgba(0,0,0,.55);display:flex;gap:12px;align-items:center;max-width:92vw';"
            + "d.innerHTML='<span></span><button style=\"background:#8b5cf6;color:#fff;border:0;border-radius:9px;padding:7px 14px;font:inherit\"></button><button style=\"background:none;color:#aaa;border:0;font:inherit;padding:4px 6px\">\\u2715</button>';"
            + "d.children[0].textContent=t;d.children[1].textContent=b;d.children[1].onclick=f;d.children[2].onclick=function(){d.remove()};document.body.appendChild(d)}"
            + "window.__ysUpdate=function(v){bar('Mise \\u00e0 jour '+v+' install\\u00e9e','Recharger',function(){YSAndroid.reload()})};"
            + "window.__ysApk=function(u,v){bar('Nouvelle version de l\\'appli Android ('+v+')','T\\u00e9l\\u00e9charger',function(){YSAndroid.openUrl(u)})};"
            + "})();</script>";

    WebView web;
    ValueCallback<Uri[]> fileCb;
    PermissionRequest pendingPerm;
    boolean immersive = true;
    final Handler ui = new Handler(Looper.getMainLooper());
    final Map<Integer, Save> saves = new HashMap<>();
    int nextSave = 1;
    File appDir;

    static class Save { File tmp; OutputStream out; String name, mime; }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        appDir = new File(getFilesDir(), "app");
        appDir.mkdirs();
        getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.rgb(24, 22, 28)));
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }

        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(24, 22, 28));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setTextZoom(100);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        web.addJavascriptInterface(new Bridge(), "YSAndroid");
        web.setWebViewClient(new Client());
        web.setWebChromeClient(new Chrome());
        setContentView(web);
        applyImmersive();
        web.loadUrl(START);

        ui.postDelayed(this::scheduleChecks, 4000);
    }

    // ---------- Plein écran ----------
    @SuppressWarnings("deprecation")
    void applyImmersive() {
        View d = getWindow().getDecorView();
        if (immersive) {
            d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        } else {
            d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) applyImmersive();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        ui.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    // ---------- Contenu de l'appli : version téléchargée si valide, sinon celle de l'APK ----------
    byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        in.close();
        return o.toByteArray();
    }

    long embeddedBuild() {
        try { return new JSONObject(new String(readAll(getAssets().open("version.json")), StandardCharsets.UTF_8)).getLong("build"); }
        catch (Exception e) { return 0; }
    }

    long cachedBuild() {
        try {
            File v = new File(appDir, "version.json"), h = new File(appDir, "index.html");
            if (!v.exists() || !h.exists()) return 0;
            return new JSONObject(new String(readAll(new FileInputStream(v)), StandardCharsets.UTF_8)).getLong("build");
        } catch (Exception e) { return 0; }
    }

    long currentBuild() { return Math.max(embeddedBuild(), cachedBuild()); }

    byte[] appHtml() throws Exception {
        byte[] html = null;
        if (cachedBuild() > embeddedBuild()) {
            try { html = readAll(new FileInputStream(new File(appDir, "index.html"))); } catch (Exception ignored) { }
        }
        if (html == null) html = readAll(getAssets().open("index.html"));
        String sHtml = new String(html, StandardCharsets.UTF_8);
        int i = sHtml.lastIndexOf("</body>");
        sHtml = i >= 0 ? sHtml.substring(0, i) + NOTIFIER + sHtml.substring(i) : sHtml + NOTIFIER;
        return sHtml.getBytes(StandardCharsets.UTF_8);
    }

    class Client extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            if (!HOST.equals(u.getHost())) return null;
            String p = u.getPath() == null ? "/" : u.getPath();
            try {
                Map<String, String> h = new HashMap<>();
                h.put("Cache-Control", "no-store");
                if (p.equals("/") || p.equals("/index.html")) {
                    return new WebResourceResponse("text/html", "utf-8", 200, "OK", h, new ByteArrayInputStream(appHtml()));
                }
                if (p.equals("/icon.png")) {
                    return new WebResourceResponse("image/png", null, 200, "OK", h, getAssets().open("icon.png"));
                }
            } catch (Exception e) {
                Log.e(TAG, "intercept", e);
            }
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", new HashMap<>(), new ByteArrayInputStream(new byte[0]));
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            if (HOST.equals(u.getHost())) return false;
            openExternal(u.toString());
            return true;
        }
    }

    void openExternal(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception e) { Log.e(TAG, "open", e); }
    }

    // ---------- Fichiers à importer, caméra (mode Visage) ----------
    class Chrome extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = cb;
            String type = "*/*";
            String[] acc = params.getAcceptTypes();
            boolean allImages = acc != null && acc.length > 0;
            if (acc != null) for (String a : acc) if (a == null || !a.startsWith("image/")) allImages = false;
            if (allImages) type = "image/*";
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType(type);
            if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            try {
                startActivityForResult(Intent.createChooser(i, "Choisir un fichier"), REQ_FILE);
            } catch (Exception e) {
                fileCb = null;
                return false;
            }
            return true;
        }

        @Override
        public void onPermissionRequest(PermissionRequest req) {
            boolean cam = false;
            for (String r : req.getResources()) if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) cam = true;
            if (!cam) { req.deny(); return; }
            if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                req.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
            } else {
                pendingPerm = req;
                requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAM);
            }
        }

        @Override
        public boolean onConsoleMessage(ConsoleMessage m) {
            Log.d(TAG, m.message() + " (" + m.sourceId() + ":" + m.lineNumber() + ")");
            return true;
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == REQ_CAM && pendingPerm != null) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED)
                pendingPerm.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
            else pendingPerm.deny();
            pendingPerm = null;
        }
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code != REQ_FILE || fileCb == null) return;
        Uri[] out = null;
        if (result == RESULT_OK && data != null) {
            ArrayList<Uri> list = new ArrayList<>();
            if (data.getClipData() != null) {
                for (int i = 0; i < data.getClipData().getItemCount(); i++) list.add(data.getClipData().getItemAt(i).getUri());
            } else if (data.getData() != null) list.add(data.getData());
            if (!list.isEmpty()) out = list.toArray(new Uri[0]);
        }
        fileCb.onReceiveValue(out);
        fileCb = null;
    }

    // ---------- Pont avec l'appli web ----------
    class Bridge {
        @JavascriptInterface
        public int begin(String name, String mime) {
            synchronized (saves) {
                try {
                    Save sv = new Save();
                    sv.name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
                    sv.mime = mime == null || mime.isEmpty() ? "application/octet-stream" : mime;
                    sv.tmp = File.createTempFile("export", ".bin", getCacheDir());
                    sv.out = new FileOutputStream(sv.tmp);
                    int id = nextSave++;
                    saves.put(id, sv);
                    return id;
                } catch (Exception e) {
                    Log.e(TAG, "begin", e);
                    return 0;
                }
            }
        }

        @JavascriptInterface
        public boolean append(int id, String b64) {
            Save sv;
            synchronized (saves) { sv = saves.get(id); }
            if (sv == null) return false;
            try { sv.out.write(Base64.decode(b64, Base64.DEFAULT)); return true; }
            catch (Exception e) { Log.e(TAG, "append", e); return false; }
        }

        @JavascriptInterface
        public String finish(int id) {
            Save sv;
            synchronized (saves) { sv = saves.remove(id); }
            if (sv == null) return "";
            try {
                sv.out.close();
                return store(sv);
            } catch (Exception e) {
                Log.e(TAG, "finish", e);
                return "";
            } finally {
                sv.tmp.delete();
            }
        }

        @JavascriptInterface
        public void toggleImmersive() { ui.post(() -> { immersive = !immersive; applyImmersive(); }); }

        @JavascriptInterface
        public void reload() { ui.post(() -> web.loadUrl(START)); }

        @JavascriptInterface
        public void openUrl(String u) { ui.post(() -> openExternal(u)); }

        @JavascriptInterface
        public String version() { return versionName() + " / contenu " + currentBuild(); }
    }

    /** Images → Images/Yujin Studio, vidéos → Films/Yujin Studio, le reste → Téléchargements/Yujin Studio. */
    String store(Save sv) throws Exception {
        String lower = sv.name.toLowerCase();
        boolean img = sv.mime.startsWith("image/") && !lower.endsWith(".psd");
        boolean vid = sv.mime.startsWith("video/");
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver cr = getContentResolver();
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, sv.name);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, sv.mime);
            String dir;
            Uri coll;
            if (img) { dir = Environment.DIRECTORY_PICTURES; coll = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY); }
            else if (vid) { dir = Environment.DIRECTORY_MOVIES; coll = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY); }
            else { dir = Environment.DIRECTORY_DOWNLOADS; coll = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY); }
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, dir + "/Yujin Studio");
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri u = cr.insert(coll, cv);
            if (u == null) throw new Exception("insert failed");
            try (OutputStream o = cr.openOutputStream(u); InputStream in = new FileInputStream(sv.tmp)) {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
            }
            cv.clear();
            cv.put(MediaStore.MediaColumns.IS_PENDING, 0);
            cr.update(u, cv, null, null);
            return (img ? "Images" : vid ? "Films" : "Téléchargements") + "/Yujin Studio";
        } else {
            File d = new File(getExternalFilesDir(img ? Environment.DIRECTORY_PICTURES : vid ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_DOWNLOADS), "Yujin Studio");
            d.mkdirs();
            File f = new File(d, sv.name);
            try (OutputStream o = new FileOutputStream(f); InputStream in = new FileInputStream(sv.tmp)) {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
            }
            return f.getParent();
        }
    }

    // ---------- Mises à jour ----------
    void scheduleChecks() {
        new Thread(this::checkAll, "ys-update").start();
        ui.postDelayed(this::scheduleChecks, CHECK_EVERY);
    }

    @SuppressWarnings("deprecation")
    long versionCode() {
        try {
            PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            return Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
        } catch (Exception e) { return 0; }
    }

    String versionName() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (Exception e) { return "?"; }
    }

    byte[] get(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(60000);
        c.setInstanceFollowRedirects(true);
        c.setUseCaches(false);
        c.setRequestProperty("Cache-Control", "no-cache");
        try {
            if (c.getResponseCode() != 200) throw new Exception("HTTP " + c.getResponseCode());
            return readAll(c.getInputStream());
        } finally {
            c.disconnect();
        }
    }

    static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x));
        return sb.toString();
    }

    void js(String code) { ui.post(() -> web.evaluateJavascript(code, null)); }

    static String q(String s) { return JSONObject.quote(s); }

    void checkAll() {
        // 1) contenu de l'appli (dessin, pinceaux…)
        try {
            byte[] vj = get(BASE + "version.json?t=" + System.currentTimeMillis());
            JSONObject m = new JSONObject(new String(vj, StandardCharsets.UTF_8));
            long build = m.getLong("build");
            if (build > currentBuild()) {
                byte[] html = get(BASE + "index.html?t=" + System.currentTimeMillis());
                String sum = hex(MessageDigest.getInstance("SHA-256").digest(html));
                String text = new String(html, StandardCharsets.UTF_8);
                if (sum.equalsIgnoreCase(m.getString("sha256")) && text.contains("<title>Yujin Studio")) {
                    File th = new File(appDir, "index.html.tmp"), tv = new File(appDir, "version.json.tmp");
                    try (OutputStream o = new FileOutputStream(th)) { o.write(html); }
                    try (OutputStream o = new FileOutputStream(tv)) { o.write(vj); }
                    if (!th.renameTo(new File(appDir, "index.html")) || !tv.renameTo(new File(appDir, "version.json")))
                        throw new Exception("rename failed");
                    js("window.__ysUpdate&&__ysUpdate(" + q(m.optString("version", String.valueOf(build))) + ")");
                } else {
                    Log.w(TAG, "mise à jour rejetée (empreinte)");
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "maj contenu : " + e);
        }
        // 2) nouvelle version de l'APK lui-même
        try {
            JSONObject a = new JSONObject(new String(get(APK_INFO), StandardCharsets.UTF_8));
            if (a.getLong("versionCode") > versionCode()) {
                js("window.__ysApk&&__ysApk(" + q(a.getString("url")) + "," + q(a.optString("versionName", "")) + ")");
            }
        } catch (Exception e) {
            Log.w(TAG, "maj apk : " + e);
        }
    }
}
