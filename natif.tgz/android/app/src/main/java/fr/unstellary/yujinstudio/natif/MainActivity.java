package fr.unstellary.yujinstudio.natif;

import android.app.NativeActivity;
import android.content.ClipData;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

/**
 * Activité native de Yujin Studio. Le dessin est entièrement en Rust (libyujin_studio.so) ;
 * cette petite classe sert seulement au sélecteur de fichiers et à « Ouvrir avec ».
 */
public class MainActivity extends NativeActivity {
    static {
        System.loadLibrary("yujin_studio");
    }

    static native void nativeFilesPicked(String[] paths);

    private static final int REQ_PICK = 42;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        handleIntent(i);
    }

    private void handleIntent(Intent i) {
        if (i == null) return;
        ArrayList<Uri> uris = new ArrayList<>();
        if (Intent.ACTION_VIEW.equals(i.getAction()) && i.getData() != null) uris.add(i.getData());
        if (Intent.ACTION_SEND.equals(i.getAction())) {
            Uri u = i.getParcelableExtra(Intent.EXTRA_STREAM);
            if (u != null) uris.add(u);
        }
        if (!uris.isEmpty()) deliver(uris);
    }

    /** Appelée depuis Rust : ouvre le sélecteur de fichiers du système. */
    public void pickFiles() {
        runOnUiThread(() -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            try {
                startActivityForResult(i, REQ_PICK);
            } catch (Exception e) {
                Log.e("YujinStudio", "sélecteur", e);
            }
        });
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code != REQ_PICK || result != RESULT_OK || data == null) return;
        ArrayList<Uri> uris = new ArrayList<>();
        ClipData cd = data.getClipData();
        if (cd != null) for (int k = 0; k < cd.getItemCount(); k++) uris.add(cd.getItemAt(k).getUri());
        else if (data.getData() != null) uris.add(data.getData());
        deliver(uris);
    }

    private void deliver(final ArrayList<Uri> uris) {
        new Thread(() -> {
            ArrayList<String> paths = new ArrayList<>();
            for (Uri u : uris) {
                String p = copy(u);
                if (p != null) paths.add(p);
            }
            if (!paths.isEmpty()) nativeFilesPicked(paths.toArray(new String[0]));
        }).start();
    }

    /** Copie le fichier choisi dans le cache de l'appli (Rust lit ensuite un vrai chemin). */
    private String copy(Uri u) {
        String name = "fichier";
        try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) name = c.getString(idx);
            }
        } catch (Exception ignored) {
        }
        name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
        File dir = new File(getCacheDir(), "import");
        dir.mkdirs();
        File f = new File(dir, System.currentTimeMillis() + "-" + name);
        try (InputStream in = getContentResolver().openInputStream(u); OutputStream out = new FileOutputStream(f)) {
            if (in == null) return null;
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return f.getAbsolutePath();
        } catch (Exception e) {
            Log.e("YujinStudio", "copie", e);
            return null;
        }
    }
}
