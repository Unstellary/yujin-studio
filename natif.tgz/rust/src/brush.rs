//! Pinceaux : réglages (intégrés ou importés de Procreate) et calcul des tampons le long du trait.

use crate::gpu::Dab;
use serde::{Deserialize, Serialize};

pub const TIP: u32 = 256;

#[derive(Clone, Copy, PartialEq, Eq, Debug, Serialize, Deserialize)]
pub enum Shape {
    Hard,
    Soft,
    Pencil,
    Chalk,
}

#[derive(Clone, PartialEq, Eq, Debug, Serialize, Deserialize)]
pub enum TipSrc {
    Builtin(Shape),
    /// Forme importée : fichier PNG (niveaux de gris) dans le dossier des pinceaux
    Custom(String),
}

#[derive(Clone, PartialEq, Eq, Debug, Serialize, Deserialize)]
pub enum GrainSrc {
    Noise,
    Custom(String),
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(default)]
pub struct Brush {
    pub id: String,
    pub name: String,
    pub cat: String,
    pub tip: TipSrc,
    pub grain: Option<GrainSrc>,
    pub grain_scale: f32,
    /// Espacement entre tampons (fraction de la taille)
    pub spacing: f32,
    /// Taille minimale (fraction)
    pub min_size: f32,
    /// Influence de la pression sur la taille / l'opacité (0..1)
    pub size_p: f32,
    pub op_p: f32,
    /// Débit de chaque tampon
    pub flow: f32,
    pub size_curve: Option<Vec<[f32; 2]>>,
    pub op_curve: Option<Vec<[f32; 2]>>,
    /// Lissage du trait (StreamLine)
    pub streamline: f32,
    pub rot_rand: bool,
    /// La forme suit la direction du trait
    pub follow: bool,
    /// Aplatissement de la forme (1 = ronde)
    pub squash: f32,
    pub scatter: f32,
    pub count: u32,
    pub op_jitter: f32,
    pub size_jitter: f32,
    pub speed_size: f32,
    pub taper_start: f32,
    pub taper_end: f32,
    pub taper_size: f32,
    pub max_size: f32,
    pub def_size: f32,
    /// « Max transfer » : l'opacité ne s'accumule pas dans un même trait
    pub op_map: bool,
    pub presets: Vec<f32>,
}

impl Default for Brush {
    fn default() -> Self {
        Brush {
            id: String::new(),
            name: "Pinceau".into(),
            cat: "Importés".into(),
            tip: TipSrc::Builtin(Shape::Hard),
            grain: None,
            grain_scale: 1.0,
            spacing: 0.08,
            min_size: 0.0,
            size_p: 0.5,
            op_p: 0.0,
            flow: 1.0,
            size_curve: None,
            op_curve: None,
            streamline: 0.2,
            rot_rand: false,
            follow: false,
            squash: 1.0,
            scatter: 0.0,
            count: 1,
            op_jitter: 0.0,
            size_jitter: 0.0,
            speed_size: 0.0,
            taper_start: 0.0,
            taper_end: 0.0,
            taper_size: 0.0,
            max_size: 120.0,
            def_size: 0.3,
            op_map: false,
            presets: Vec::new(),
        }
    }
}

#[allow(clippy::too_many_arguments)]
fn b(id: &str, name: &str, cat: &str, shape: Shape, spacing: f32, size_p: f32, op_p: f32, flow: f32, stream: f32, rot: bool, max: f32) -> Brush {
    Brush { id: id.into(), name: name.into(), cat: cat.into(), tip: TipSrc::Builtin(shape), spacing, size_p, op_p, flow, streamline: stream, rot_rand: rot, max_size: max, ..Default::default() }
}

pub fn builtins() -> Vec<Brush> {
    let mut v = vec![
        b("encre-tech", "Encre technique", "Encrage", Shape::Hard, 0.06, 0.75, 0.0, 1.0, 0.35, false, 120.0),
        b("encre-studio", "Encre de studio", "Encrage", Shape::Hard, 0.05, 0.95, 0.0, 1.0, 0.5, false, 160.0),
        b("stylo-gel", "Stylo gel", "Encrage", Shape::Hard, 0.06, 0.4, 0.3, 1.0, 0.25, false, 80.0),
        b("crayon-6b", "Crayon 6B", "Croquis", Shape::Pencil, 0.08, 0.5, 0.85, 0.55, 0.1, true, 60.0),
        b("crayon-hb", "Crayon HB", "Croquis", Shape::Pencil, 0.1, 0.3, 0.9, 0.35, 0.1, true, 30.0),
        b("craie", "Craie", "Croquis", Shape::Chalk, 0.1, 0.4, 0.7, 0.7, 0.1, true, 200.0),
        b("aero-doux", "Aérographe doux", "Aérographie", Shape::Soft, 0.08, 0.0, 1.0, 0.12, 0.1, false, 900.0),
        b("aero-dur", "Aérographe dur", "Aérographie", Shape::Hard, 0.08, 0.0, 1.0, 0.25, 0.1, false, 900.0),
        b("pinceau-rond", "Pinceau rond", "Peinture", Shape::Hard, 0.04, 0.65, 0.5, 0.85, 0.2, false, 300.0),
        b("gouache", "Gouache", "Peinture", Shape::Chalk, 0.05, 0.5, 0.6, 0.8, 0.15, true, 300.0),
    ];
    // Encres : effilement léger comme dans Procreate
    for x in v.iter_mut().take(2) {
        x.taper_start = 0.15;
        x.taper_end = 0.15;
        x.taper_size = 0.6;
    }
    for i in [3, 4, 5] {
        v[i].grain = Some(GrainSrc::Noise);
    }
    v
}

fn hash(x: u32, y: u32, s: u32) -> f32 {
    let mut h = x.wrapping_mul(374761393) ^ y.wrapping_mul(668265263) ^ s.wrapping_mul(2246822519);
    h = (h ^ (h >> 13)).wrapping_mul(1274126177);
    ((h ^ (h >> 16)) & 0xffff) as f32 / 65535.0
}

/// Génère une forme intégrée (taille TIP × TIP).
pub fn builtin_tip(shape: Shape) -> Vec<u8> {
    let n = TIP as usize;
    let mut base = vec![0u8; n * n];
    let c = (n as f32 - 1.0) / 2.0;
    for y in 0..n {
        for x in 0..n {
            let dx = (x as f32 - c) / (n as f32 / 2.0);
            let dy = (y as f32 - c) / (n as f32 / 2.0);
            let r = (dx * dx + dy * dy).sqrt();
            let v = match shape {
                Shape::Hard => (1.0 - ((r - 0.97) / 0.03).clamp(0.0, 1.0)).clamp(0.0, 1.0),
                Shape::Soft => {
                    let t = (1.0 - r).clamp(0.0, 1.0);
                    t * t * (3.0 - 2.0 * t)
                }
                Shape::Pencil => (1.0 - ((r - 0.8) / 0.2).clamp(0.0, 1.0)).clamp(0.0, 1.0),
                Shape::Chalk => {
                    let edge = (1.0 - ((r - 0.75) / 0.25).clamp(0.0, 1.0)).clamp(0.0, 1.0);
                    let g = hash(x as u32 / 4, y as u32 / 4, 3) * 0.5 + hash(x as u32 / 9, y as u32 / 9, 5) * 0.5;
                    edge * ((g - 0.25) / 0.5).clamp(0.0, 1.0)
                }
            };
            base[y * n + x] = (v * 255.0).round() as u8;
        }
    }
    base
}

/// Grain de papier par défaut (bruit en amas, se répète sans couture).
pub fn noise_grain() -> Vec<u8> {
    let n = TIP as usize;
    let mut v = vec![0u8; n * n];
    for y in 0..n {
        for x in 0..n {
            let g = hash(x as u32, y as u32, 31) * 0.45 + hash(x as u32 / 2 % 128, y as u32 / 2 % 128, 37) * 0.35 + hash(x as u32 * 51 / 256, y as u32 * 51 / 256, 41) * 0.2;
            v[y * n + x] = (((g - 0.3) / 0.55).clamp(0.0, 1.0).powf(1.3) * 255.0) as u8;
        }
    }
    v
}

/// Chaîne de mipmaps d'un masque carré.
pub fn mips(base: Vec<u8>, size: usize) -> Vec<Vec<u8>> {
    let mut levels = vec![base];
    let mut s = size;
    while s > 1 {
        let prev = levels.last().unwrap();
        let ns = s / 2;
        let mut next = vec![0u8; ns * ns];
        for y in 0..ns {
            for x in 0..ns {
                let a = prev[(2 * y) * s + 2 * x] as u32 + prev[(2 * y) * s + 2 * x + 1] as u32 + prev[(2 * y + 1) * s + 2 * x] as u32 + prev[(2 * y + 1) * s + 2 * x + 1] as u32;
                next[y * ns + x] = ((a + 2) / 4) as u8;
            }
        }
        levels.push(next);
        s = ns;
    }
    levels
}

pub fn eval_curve(c: &Option<Vec<[f32; 2]>>, x: f32) -> f32 {
    let Some(c) = c else { return x };
    if c.is_empty() {
        return x;
    }
    if x <= c[0][0] {
        return c[0][1];
    }
    for w in c.windows(2) {
        if x <= w[1][0] {
            let t = (x - w[0][0]) / (w[1][0] - w[0][0]).max(1e-6);
            return w[0][1] + (w[1][1] - w[0][1]) * t;
        }
    }
    c[c.len() - 1][1]
}

#[derive(Clone, Copy, Debug)]
pub struct Point {
    pub x: f32,
    pub y: f32,
    pub p: f32,
    /// Temps en secondes depuis le début du trait
    pub t: f32,
}

/// Construit les tampons au fur et à mesure du trait.
pub struct StrokeBuilder {
    pub brush: Brush,
    pub size: f32,
    pub pressure_curve: f32,
    smooth: Option<Point>,
    last: Option<Point>,
    carry: f32,
    /// longueur parcourue jusqu'au début du segment en cours
    dist: f32,
    /// position du tampon en cours le long du trait
    cur: f32,
    total: Option<f32>,
    speed: f32,
    rng: u32,
    dir: f32,
    pub points: Vec<Point>,
    pub dabs_count: usize,
}

impl StrokeBuilder {
    pub fn new(brush: Brush, size: f32, pressure_curve: f32) -> Self {
        StrokeBuilder { brush, size, pressure_curve, smooth: None, last: None, carry: 0.0, dist: 0.0, cur: 0.0, total: None, speed: 0.0, rng: 0x9e37_79b9, dir: 0.0, points: Vec::new(), dabs_count: 0 }
    }

    fn rand(&mut self) -> f32 {
        self.rng ^= self.rng << 13;
        self.rng ^= self.rng >> 17;
        self.rng ^= self.rng << 5;
        (self.rng & 0xff_ffff) as f32 / 16_777_215.0
    }

    fn pr(&self, p: f32) -> f32 {
        p.clamp(0.0, 1.0).powf(self.pressure_curve)
    }

    fn size_at(&self, p: f32) -> f32 {
        let b = &self.brush;
        let ps = eval_curve(&b.size_curve, self.pr(p));
        let mut s = self.size * (b.min_size + (1.0 - b.min_size) * (1.0 - b.size_p + b.size_p * ps));
        if b.speed_size != 0.0 {
            s *= 1.0 - 0.45 * b.speed_size * (self.speed / 2.5).min(1.0);
        }
        if b.taper_size > 0.0 {
            let k = 1.0 - b.taper_size.min(1.0);
            if b.taper_start > 0.0 {
                let l = b.taper_start * 400.0;
                if self.cur < l {
                    s *= k + (1.0 - k) * (self.cur / l * std::f32::consts::FRAC_PI_2).sin();
                }
            }
            if let Some(total) = self.total {
                if b.taper_end > 0.0 {
                    let l = b.taper_end * 400.0;
                    let rem = (total - self.cur).max(0.0);
                    if rem < l {
                        s *= k + (1.0 - k) * (rem / l * std::f32::consts::FRAC_PI_2).sin();
                    }
                }
            }
        }
        s.max(0.3)
    }

    fn dabs_at(&mut self, x: f32, y: f32, p: f32, out: &mut Vec<Dab>) {
        let b = self.brush.clone();
        let mut size = self.size_at(p);
        if b.size_jitter > 0.0 {
            size *= 1.0 - b.size_jitter * self.rand();
        }
        for _ in 0..b.count.clamp(1, 8) {
            let (mut px, mut py) = (x, y);
            if b.scatter > 0.0 {
                let a = self.rand() * std::f32::consts::TAU;
                let r = self.rand() * b.scatter * size;
                px += a.cos() * r;
                py += a.sin() * r;
            }
            let opc = eval_curve(&b.op_curve, self.pr(p));
            let mut alpha = b.flow * (1.0 - b.op_p + b.op_p * opc);
            if b.op_jitter > 0.0 {
                alpha *= 1.0 - b.op_jitter * self.rand();
            }
            if size < 1.0 {
                alpha *= size;
            }
            let angle = if b.follow {
                self.dir + std::f32::consts::FRAC_PI_2
            } else if b.rot_rand {
                self.rand() * std::f32::consts::TAU
            } else {
                0.0
            };
            out.push(Dab { pos: [px, py], size, angle, alpha, aspect: if b.follow { b.squash.clamp(0.05, 1.0) } else { 1.0 } });
            self.dabs_count += 1;
        }
    }

    fn spacing_px(&self, p: f32) -> f32 {
        (self.size_at(p) * self.brush.spacing).max(0.35)
    }

    /// Ajoute un point d'entrée ; renvoie les tampons à dessiner.
    pub fn add(&mut self, raw: Point) -> Vec<Dab> {
        if self.total.is_none() {
            self.points.push(raw);
        }
        let k = self.brush.streamline.clamp(0.0, 0.95);
        let pt = match self.smooth {
            None => raw,
            Some(s) => Point { x: s.x + (raw.x - s.x) * (1.0 - k), y: s.y + (raw.y - s.y) * (1.0 - k), p: s.p + (raw.p - s.p) * 0.6, t: raw.t },
        };
        self.smooth = Some(pt);
        let mut out = Vec::new();
        match self.last {
            None => {
                if !self.brush.follow {
                    self.cur = 0.0;
                    self.dabs_at(pt.x, pt.y, pt.p, &mut out);
                }
                self.last = Some(pt);
                self.carry = 0.0;
            }
            Some(l) => {
                let dx = pt.x - l.x;
                let dy = pt.y - l.y;
                let dist = (dx * dx + dy * dy).sqrt();
                if dist < 1e-4 {
                    return out;
                }
                let dt = ((pt.t - l.t) * 1000.0).max(1.0);
                self.speed = self.speed * 0.7 + (dist / dt) * 0.3;
                self.dir = dy.atan2(dx);
                let mut pos = 0.0f32;
                loop {
                    self.cur = self.dist + pos;
                    let p = l.p + (pt.p - l.p) * (pos / dist).min(1.0);
                    let need = self.spacing_px(p) - self.carry;
                    if pos + need > dist {
                        self.carry += dist - pos;
                        break;
                    }
                    pos += need.max(0.0);
                    self.carry = 0.0;
                    self.cur = self.dist + pos;
                    let f = pos / dist;
                    self.dabs_at(l.x + dx * f, l.y + dy * f, l.p + (pt.p - l.p) * f, &mut out);
                }
                self.dist += dist;
                self.last = Some(pt);
            }
        }
        out
    }

    /// Termine le trait : rattrape le lissage jusqu'au dernier point réel.
    pub fn finish(&mut self, raw: Point) -> Vec<Dab> {
        let saved = self.brush.streamline;
        self.brush.streamline = 0.0;
        let mut out = if self.smooth.is_some() { self.add(raw) } else { Vec::new() };
        self.brush.streamline = saved;
        if self.dabs_count == 0 {
            // simple toucher : au moins un tampon
            let follow = self.brush.follow;
            self.brush.follow = false;
            self.dabs_at(raw.x, raw.y, raw.p, &mut out);
            self.brush.follow = follow;
        }
        out
    }

    /// L'effilement de fin demande de connaître la longueur totale : on recalcule tout le trait.
    pub fn needs_replay(&self) -> bool {
        self.brush.taper_end > 0.0 && self.brush.taper_size > 0.0 && self.dist > 2.0 && self.points.len() > 1
    }

    pub fn replay(&mut self) -> Vec<Dab> {
        let total = self.dist;
        let pts = std::mem::take(&mut self.points);
        let mut fresh = StrokeBuilder::new(self.brush.clone(), self.size, self.pressure_curve);
        fresh.total = Some(total);
        let mut out = Vec::new();
        for p in &pts[..pts.len() - 1] {
            out.extend(fresh.add(*p));
        }
        out.extend(fresh.finish(*pts.last().unwrap()));
        out
    }
}
