//! Pinceaux : formes (générées), réglages et calcul des tampons le long du trait.

use crate::gpu::Dab;

pub const TIP: u32 = 256;

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Shape {
    Hard,
    Soft,
    Pencil,
    Chalk,
}

#[derive(Clone, Debug)]
pub struct Brush {
    pub name: &'static str,
    pub cat: &'static str,
    pub shape: Shape,
    /// Espacement entre tampons (fraction de la taille)
    pub spacing: f32,
    /// Taille minimale à pression nulle (fraction)
    pub min_size: f32,
    /// Opacité minimale à pression nulle (fraction)
    pub min_flow: f32,
    /// Débit de chaque tampon
    pub flow: f32,
    /// Lissage du trait (0 = aucun, 1 = très fort)
    pub streamline: f32,
    /// Rotation aléatoire de la forme
    pub jitter_angle: bool,
    /// Taille maximale en pixels
    pub max_size: f32,
}

pub fn library() -> Vec<Brush> {
    vec![
        Brush { name: "Encre technique", cat: "Encrage", shape: Shape::Hard, spacing: 0.06, min_size: 0.25, min_flow: 1.0, flow: 1.0, streamline: 0.35, jitter_angle: false, max_size: 120.0 },
        Brush { name: "Encre de studio", cat: "Encrage", shape: Shape::Hard, spacing: 0.05, min_size: 0.05, min_flow: 1.0, flow: 1.0, streamline: 0.5, jitter_angle: false, max_size: 160.0 },
        Brush { name: "Stylo gel", cat: "Encrage", shape: Shape::Hard, spacing: 0.06, min_size: 0.6, min_flow: 0.7, flow: 1.0, streamline: 0.25, jitter_angle: false, max_size: 80.0 },
        Brush { name: "Crayon 6B", cat: "Croquis", shape: Shape::Pencil, spacing: 0.08, min_size: 0.5, min_flow: 0.15, flow: 0.55, streamline: 0.1, jitter_angle: true, max_size: 60.0 },
        Brush { name: "Crayon HB", cat: "Croquis", shape: Shape::Pencil, spacing: 0.1, min_size: 0.7, min_flow: 0.1, flow: 0.35, streamline: 0.1, jitter_angle: true, max_size: 30.0 },
        Brush { name: "Craie", cat: "Croquis", shape: Shape::Chalk, spacing: 0.1, min_size: 0.6, min_flow: 0.3, flow: 0.7, streamline: 0.1, jitter_angle: true, max_size: 200.0 },
        Brush { name: "Aérographe doux", cat: "Aérographie", shape: Shape::Soft, spacing: 0.08, min_size: 1.0, min_flow: 0.0, flow: 0.12, streamline: 0.1, jitter_angle: false, max_size: 900.0 },
        Brush { name: "Aérographe dur", cat: "Aérographie", shape: Shape::Hard, spacing: 0.08, min_size: 1.0, min_flow: 0.0, flow: 0.25, streamline: 0.1, jitter_angle: false, max_size: 900.0 },
        Brush { name: "Pinceau rond", cat: "Peinture", shape: Shape::Hard, spacing: 0.04, min_size: 0.35, min_flow: 0.5, flow: 0.85, streamline: 0.2, jitter_angle: false, max_size: 300.0 },
        Brush { name: "Gouache", cat: "Peinture", shape: Shape::Chalk, spacing: 0.05, min_size: 0.5, min_flow: 0.4, flow: 0.8, streamline: 0.15, jitter_angle: true, max_size: 300.0 },
    ]
}

fn hash(x: u32, y: u32, s: u32) -> f32 {
    let mut h = x.wrapping_mul(374761393) ^ y.wrapping_mul(668265263) ^ s.wrapping_mul(2246822519);
    h = (h ^ (h >> 13)).wrapping_mul(1274126177);
    ((h ^ (h >> 16)) & 0xffff) as f32 / 65535.0
}

/// Génère la forme d'un pinceau et ses mipmaps.
pub fn make_tip(shape: Shape) -> Vec<Vec<u8>> {
    let n = TIP as usize;
    let mut base = vec![0u8; n * n];
    let c = (n as f32 - 1.0) / 2.0;
    for y in 0..n {
        for x in 0..n {
            let dx = (x as f32 - c) / (n as f32 / 2.0);
            let dy = (y as f32 - c) / (n as f32 / 2.0);
            let r = (dx * dx + dy * dy).sqrt();
            let v = match shape {
                Shape::Hard => (1.0 - ((r - 0.97) / 0.03).clamp(0.0, 1.0)).clamp(0.0, 1.0),
                Shape::Soft => {
                    let t = (1.0 - r).clamp(0.0, 1.0);
                    t * t * (3.0 - 2.0 * t)
                }
                Shape::Pencil => {
                    let edge = (1.0 - ((r - 0.85) / 0.15).clamp(0.0, 1.0)).clamp(0.0, 1.0);
                    let g = hash(x as u32, y as u32, 7);
                    let g2 = hash(x as u32 / 3, y as u32 / 3, 11);
                    edge * if g * 0.6 + g2 * 0.4 > 0.45 { 1.0 } else { 0.15 }
                }
                Shape::Chalk => {
                    let edge = (1.0 - ((r - 0.75) / 0.25).clamp(0.0, 1.0)).clamp(0.0, 1.0);
                    let g = hash(x as u32 / 4, y as u32 / 4, 3) * 0.5 + hash(x as u32 / 9, y as u32 / 9, 5) * 0.5;
                    edge * ((g - 0.25) / 0.5).clamp(0.0, 1.0)
                }
            };
            base[y * n + x] = (v * 255.0).round() as u8;
        }
    }
    let mut levels = vec![base];
    let mut s = n;
    while s > 1 {
        let prev = levels.last().unwrap();
        let ns = s / 2;
        let mut next = vec![0u8; ns * ns];
        for y in 0..ns {
            for x in 0..ns {
                let a = prev[(2 * y) * s + 2 * x] as u32
                    + prev[(2 * y) * s + 2 * x + 1] as u32
                    + prev[(2 * y + 1) * s + 2 * x] as u32
                    + prev[(2 * y + 1) * s + 2 * x + 1] as u32;
                next[y * ns + x] = ((a + 2) / 4) as u8;
            }
        }
        levels.push(next);
        s = ns;
    }
    levels
}

#[derive(Clone, Copy, Debug)]
pub struct Point {
    pub x: f32,
    pub y: f32,
    pub p: f32,
}

/// Construit les tampons au fur et à mesure du trait.
pub struct StrokeBuilder {
    pub brush: Brush,
    pub size: f32,
    pub pressure_curve: f32,
    smooth: Option<Point>,
    last: Option<Point>,
    carry: f32,
    seed: u32,
}

impl StrokeBuilder {
    pub fn new(brush: Brush, size: f32, pressure_curve: f32) -> Self {
        StrokeBuilder { brush, size, pressure_curve, smooth: None, last: None, carry: 0.0, seed: 1 }
    }

    fn dab(&mut self, pt: Point) -> Dab {
        let p = pt.p.clamp(0.0, 1.0).powf(self.pressure_curve);
        let b = &self.brush;
        let size = (self.size * (b.min_size + (1.0 - b.min_size) * p)).max(0.6);
        let alpha = b.flow * (b.min_flow + (1.0 - b.min_flow) * p);
        self.seed = self.seed.wrapping_add(1);
        let angle = if b.jitter_angle { hash(self.seed, 17, 23) * std::f32::consts::TAU } else { 0.0 };
        // Les très petites tailles s'éclaircissent au lieu de disparaître
        let alpha = if size < 1.0 { alpha * size } else { alpha };
        Dab { pos: [pt.x, pt.y], size, angle, alpha }
    }

    fn spacing_px(&self, p: f32) -> f32 {
        let pp = p.clamp(0.0, 1.0).powf(self.pressure_curve);
        let size = self.size * (self.brush.min_size + (1.0 - self.brush.min_size) * pp);
        (size * self.brush.spacing).max(0.35)
    }

    /// Ajoute un point d'entrée ; renvoie les tampons à dessiner.
    pub fn add(&mut self, raw: Point) -> Vec<Dab> {
        let k = self.brush.streamline.clamp(0.0, 0.95);
        let pt = match self.smooth {
            None => raw,
            Some(s) => Point { x: s.x + (raw.x - s.x) * (1.0 - k), y: s.y + (raw.y - s.y) * (1.0 - k), p: s.p + (raw.p - s.p) * 0.6 },
        };
        self.smooth = Some(pt);
        let mut out = Vec::new();
        match self.last {
            None => {
                out.push(self.dab(pt));
                self.last = Some(pt);
                self.carry = 0.0;
            }
            Some(l) => {
                let dx = pt.x - l.x;
                let dy = pt.y - l.y;
                let dist = (dx * dx + dy * dy).sqrt();
                if dist < 1e-4 {
                    return out;
                }
                // `carry` = distance parcourue depuis le dernier tampon
                let mut pos = 0.0f32;
                loop {
                    let p = l.p + (pt.p - l.p) * (pos / dist).min(1.0);
                    let need = self.spacing_px(p) - self.carry;
                    if pos + need > dist {
                        self.carry += dist - pos;
                        break;
                    }
                    pos += need.max(0.0);
                    self.carry = 0.0;
                    let f = pos / dist;
                    out.push(self.dab(Point { x: l.x + dx * f, y: l.y + dy * f, p: l.p + (pt.p - l.p) * f }));
                }
                self.last = Some(pt);
            }
        }
        out
    }

    /// Termine le trait : rattrape le lissage jusqu'au dernier point réel.
    pub fn finish(&mut self, raw: Point) -> Vec<Dab> {
        let mut out = Vec::new();
        if self.smooth.is_some() {
            let saved = self.brush.streamline;
            self.brush.streamline = 0.0;
            out = self.add(raw);
            self.brush.streamline = saved;
        }
        out
    }
}
