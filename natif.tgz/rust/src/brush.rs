//! Pinceaux : réglages (intégrés ou importés de Procreate) et calcul des tampons le long du trait.

use crate::gpu::Dab;
use serde::{Deserialize, Serialize};

pub const TIP: u32 = 256;

#[derive(Clone, Copy, PartialEq, Eq, Debug, Serialize, Deserialize)]
pub enum Shape {
    Hard,
    Soft,
    Pencil,
    Chalk,
    Square,
    Flat,
    Bristle,
    Spatter,
    Cloud,
    Star,
    Leaf,
    Rough,
    Hair,
    Ring,
}

#[derive(Clone, PartialEq, Eq, Debug, Serialize, Deserialize)]
pub enum TipSrc {
    Builtin(Shape),
    /// Forme importée : fichier PNG (niveaux de gris) dans le dossier des pinceaux
    Custom(String),
}

#[derive(Clone, PartialEq, Eq, Debug, Serialize, Deserialize)]
pub enum GrainSrc {
    Noise,
    Paper,
    Canvas,
    Custom(String),
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(default)]
pub struct Brush {
    pub id: String,
    pub name: String,
    pub cat: String,
    pub tip: TipSrc,
    pub grain: Option<GrainSrc>,
    pub grain_scale: f32,
    /// Espacement entre tampons (fraction de la taille)
    pub spacing: f32,
    /// Taille minimale (fraction)
    pub min_size: f32,
    /// Influence de la pression sur la taille / l'opacité (0..1)
    pub size_p: f32,
    pub op_p: f32,
    /// Débit de chaque tampon
    pub flow: f32,
    pub size_curve: Option<Vec<[f32; 2]>>,
    pub op_curve: Option<Vec<[f32; 2]>>,
    /// Lissage du trait (StreamLine)
    pub streamline: f32,
    pub rot_rand: bool,
    /// La forme suit la direction du trait
    pub follow: bool,
    /// Aplatissement de la forme (1 = ronde)
    pub squash: f32,
    pub scatter: f32,
    pub count: u32,
    pub op_jitter: f32,
    pub size_jitter: f32,
    pub speed_size: f32,
    pub taper_start: f32,
    pub taper_end: f32,
    pub taper_size: f32,
    pub max_size: f32,
    pub def_size: f32,
    /// « Max transfer » : l'opacité ne s'accumule pas dans un même trait
    pub op_map: bool,
    pub presets: Vec<f32>,
    /// Lumière : la couleur s'ajoute (néon, éclat)
    pub glow: bool,
}

impl Default for Brush {
    fn default() -> Self {
        Brush {
            id: String::new(),
            name: "Pinceau".into(),
            cat: "Importés".into(),
            tip: TipSrc::Builtin(Shape::Hard),
            grain: None,
            grain_scale: 1.0,
            spacing: 0.08,
            min_size: 0.0,
            size_p: 0.5,
            op_p: 0.0,
            flow: 1.0,
            size_curve: None,
            op_curve: None,
            streamline: 0.2,
            rot_rand: false,
            follow: false,
            squash: 1.0,
            scatter: 0.0,
            count: 1,
            op_jitter: 0.0,
            size_jitter: 0.0,
            speed_size: 0.0,
            taper_start: 0.0,
            taper_end: 0.0,
            taper_size: 0.0,
            max_size: 120.0,
            def_size: 0.3,
            op_map: false,
            presets: Vec::new(),
            glow: false,
        }
    }
}

#[allow(clippy::too_many_arguments)]

/// Catégories de la bibliothèque (ordre et nom, comme dans Procreate).
pub const CATEGORIES: &[&str] = &[
    "Esquisse", "Encrage", "Dessin", "Peinture", "Artistique", "Calligraphie", "Aérographie", "Textures", "Abstrait",
    "Fusains", "Éléments", "Aérosols", "Retouches", "Vintage", "Luminance", "Industriel", "Organique", "Eau",
];

struct B(Brush);
impl B {
    fn new(id: &str, name: &str, cat: &str, shape: Shape) -> Self {
        B(Brush { id: id.into(), name: name.into(), cat: cat.into(), tip: TipSrc::Builtin(shape), ..Default::default() })
    }
    fn sp(mut self, v: f32) -> Self { self.0.spacing = v; self }
    fn press(mut self, size: f32, op: f32) -> Self { self.0.size_p = size; self.0.op_p = op; self }
    fn flow(mut self, v: f32) -> Self { self.0.flow = v; self }
    fn stream(mut self, v: f32) -> Self { self.0.streamline = v; self }
    fn rot(mut self) -> Self { self.0.rot_rand = true; self }
    fn max(mut self, v: f32) -> Self { self.0.max_size = v; self }
    fn grain(mut self, g: GrainSrc, scale: f32) -> Self { self.0.grain = Some(g); self.0.grain_scale = scale; self }
    fn taper(mut self, a: f32, b: f32, s: f32) -> Self { self.0.taper_start = a; self.0.taper_end = b; self.0.taper_size = s; self }
    fn scatter(mut self, v: f32, count: u32) -> Self { self.0.scatter = v; self.0.count = count; self }
    fn jitter(mut self, size: f32, op: f32) -> Self { self.0.size_jitter = size; self.0.op_jitter = op; self }
    fn follow(mut self, squash: f32) -> Self { self.0.follow = true; self.0.squash = squash; self }
    fn glow(mut self) -> Self { self.0.glow = true; self }
    fn opmap(mut self) -> Self { self.0.op_map = true; self }
    fn min(mut self, v: f32) -> Self { self.0.min_size = v; self }
}

pub fn builtins() -> Vec<Brush> {
    use GrainSrc::*;
    use Shape::*;
    let v: Vec<B> = vec![
        // Esquisse
        B::new("crayon-6b", "Crayon 6B", "Esquisse", Pencil).sp(0.08).press(0.5, 0.85).flow(0.55).stream(0.1).rot().max(60.0).grain(Paper, 0.8),
        B::new("crayon-hb", "Crayon HB", "Esquisse", Pencil).sp(0.1).press(0.3, 0.9).flow(0.35).stream(0.1).rot().max(30.0).grain(Paper, 0.6),
        B::new("crayon-tech", "Crayon technique", "Esquisse", Hard).sp(0.08).press(0.3, 0.7).flow(0.6).stream(0.2).max(25.0).grain(Paper, 0.5),
        B::new("esquisse-legere", "Esquisse légère", "Esquisse", Pencil).sp(0.1).press(0.2, 1.0).flow(0.25).stream(0.05).rot().max(40.0).grain(Noise, 1.0),
        B::new("pastel-sec", "Pastel sec", "Esquisse", Chalk).sp(0.1).press(0.4, 0.6).flow(0.7).rot().max(120.0).grain(Paper, 1.4),
        // Encrage
        B::new("encre-tech", "Encre technique", "Encrage", Hard).sp(0.06).press(0.75, 0.0).stream(0.35).max(120.0).taper(0.15, 0.15, 0.6),
        B::new("encre-studio", "Encre de studio", "Encrage", Hard).sp(0.05).press(0.95, 0.0).stream(0.5).max(160.0).taper(0.15, 0.15, 0.6),
        B::new("stylo-gel", "Stylo gel", "Encrage", Hard).sp(0.06).press(0.4, 0.3).stream(0.25).max(80.0),
        B::new("pointe-fine", "Pointe fine", "Encrage", Hard).sp(0.05).press(0.6, 0.0).stream(0.4).max(20.0).taper(0.1, 0.1, 0.8),
        B::new("encre-seche", "Encre sèche", "Encrage", Rough).sp(0.06).press(0.6, 0.2).flow(0.95).stream(0.3).rot().max(90.0).grain(Noise, 0.8),
        B::new("feutre", "Feutre", "Encrage", Hard).sp(0.05).press(0.1, 0.0).flow(0.5).stream(0.25).max(70.0).opmap(),
        B::new("encre-bavee", "Encre bavée", "Encrage", Cloud).sp(0.05).press(0.7, 0.1).stream(0.3).rot().max(120.0),
        // Dessin
        B::new("crayon-couleur", "Crayon de couleur", "Dessin", Pencil).sp(0.08).press(0.3, 0.8).flow(0.6).rot().max(40.0).grain(Paper, 0.9),
        B::new("fusain-dessin", "Mine de plomb", "Dessin", Chalk).sp(0.08).press(0.3, 0.8).flow(0.5).rot().max(50.0).grain(Paper, 0.7),
        B::new("stylo-bille", "Stylo bille", "Dessin", Hard).sp(0.05).press(0.3, 0.6).flow(0.8).stream(0.2).max(14.0),
        B::new("marqueur", "Marqueur", "Dessin", Flat).sp(0.04).press(0.0, 0.0).flow(0.4).stream(0.2).max(80.0).opmap().follow(0.45),
        // Peinture
        B::new("pinceau-rond", "Pinceau rond", "Peinture", Hard).sp(0.04).press(0.65, 0.5).flow(0.85).stream(0.2).max(300.0),
        B::new("gouache", "Gouache", "Peinture", Chalk).sp(0.05).press(0.5, 0.6).flow(0.8).stream(0.15).rot().max(300.0),
        B::new("acrylique", "Acrylique", "Peinture", Bristle).sp(0.04).press(0.5, 0.5).flow(0.9).stream(0.15).follow(0.7).max(260.0),
        B::new("huile", "Peinture à l'huile", "Peinture", Bristle).sp(0.03).press(0.4, 0.3).flow(1.0).stream(0.2).follow(0.55).max(300.0).grain(Canvas, 1.2),
        B::new("brosse-plate", "Brosse plate", "Peinture", Flat).sp(0.03).press(0.5, 0.4).flow(0.85).stream(0.2).follow(0.3).max(260.0),
        // Artistique
        B::new("pastel-gras", "Pastel gras", "Artistique", Chalk).sp(0.06).press(0.4, 0.4).flow(0.85).rot().max(150.0).grain(Canvas, 1.0),
        B::new("aquarelle-art", "Lavis", "Artistique", Cloud).sp(0.06).press(0.3, 0.9).flow(0.18).stream(0.1).rot().max(400.0).grain(Paper, 1.5),
        B::new("impasto", "Empâtement", "Artistique", Bristle).sp(0.03).press(0.5, 0.2).flow(1.0).follow(0.8).max(240.0),
        // Calligraphie
        B::new("calligraphie", "Calligraphie", "Calligraphie", Flat).sp(0.03).press(0.3, 0.0).stream(0.4).max(120.0).follow(0.18),
        B::new("monoligne", "Monoligne", "Calligraphie", Hard).sp(0.04).press(0.0, 0.0).stream(0.6).max(60.0),
        B::new("script", "Script", "Calligraphie", Hard).sp(0.04).press(0.95, 0.0).stream(0.6).max(90.0).min(0.05),
        B::new("craie-calli", "Craie calligraphique", "Calligraphie", Flat).sp(0.05).press(0.3, 0.2).flow(0.9).follow(0.25).max(110.0).grain(Paper, 1.2),
        // Aérographie
        B::new("aero-doux", "Aérographe doux", "Aérographie", Soft).sp(0.08).press(0.0, 1.0).flow(0.12).stream(0.1).max(900.0),
        B::new("aero-dur", "Aérographe dur", "Aérographie", Hard).sp(0.08).press(0.0, 1.0).flow(0.25).stream(0.1).max(900.0),
        B::new("aero-moyen", "Aérographe moyen", "Aérographie", Cloud).sp(0.08).press(0.0, 1.0).flow(0.18).stream(0.1).max(900.0),
        B::new("aero-eclabousse", "Éclaboussures", "Aérographie", Spatter).sp(0.3).press(0.3, 0.5).flow(0.9).rot().scatter(0.4, 2).max(500.0),
        // Textures
        B::new("tex-grille", "Grille", "Textures", Square).sp(0.5).press(0.2, 0.0).flow(0.7).max(120.0).grain(Canvas, 0.5),
        B::new("tex-papier", "Papier froissé", "Textures", Soft).sp(0.1).press(0.0, 0.6).flow(0.5).max(600.0).grain(Paper, 2.5),
        B::new("tex-toile", "Toile", "Textures", Soft).sp(0.1).press(0.0, 0.6).flow(0.5).max(600.0).grain(Canvas, 2.0),
        B::new("tex-bruit", "Grain", "Textures", Soft).sp(0.1).press(0.0, 0.6).flow(0.6).max(600.0).grain(Noise, 1.5),
        // Abstrait
        B::new("abs-etoiles", "Étoiles", "Abstrait", Star).sp(0.9).press(0.4, 0.2).rot().jitter(0.6, 0.3).scatter(0.6, 1).max(120.0),
        B::new("abs-anneaux", "Anneaux", "Abstrait", Ring).sp(0.6).press(0.3, 0.2).jitter(0.5, 0.3).scatter(0.5, 1).max(140.0),
        B::new("abs-confettis", "Confettis", "Abstrait", Square).sp(0.8).rot().jitter(0.7, 0.4).scatter(1.0, 2).max(60.0),
        // Fusains
        B::new("fusain", "Fusain", "Fusains", Chalk).sp(0.08).press(0.4, 0.7).flow(0.7).rot().max(140.0).grain(Paper, 1.2),
        B::new("fusain-vigne", "Fusain de vigne", "Fusains", Rough).sp(0.08).press(0.3, 0.8).flow(0.6).rot().max(80.0).grain(Paper, 0.9),
        B::new("fusain-compresse", "Fusain compressé", "Fusains", Square).sp(0.06).press(0.4, 0.6).flow(0.8).rot().max(160.0).grain(Paper, 1.4),
        // Éléments
        B::new("el-nuages", "Nuages", "Éléments", Cloud).sp(0.15).press(0.3, 0.6).flow(0.3).rot().jitter(0.4, 0.3).scatter(0.3, 2).max(700.0),
        B::new("el-pluie", "Pluie", "Éléments", Hair).sp(0.4).press(0.0, 0.3).flow(0.7).jitter(0.5, 0.5).scatter(1.5, 3).max(200.0),
        B::new("el-feu", "Feu", "Éléments", Leaf).sp(0.2).press(0.4, 0.5).flow(0.7).rot().jitter(0.5, 0.4).scatter(0.4, 2).max(200.0).glow(),
        B::new("el-neige", "Neige", "Éléments", Soft).sp(1.0).press(0.0, 0.0).jitter(0.8, 0.5).scatter(3.0, 3).max(40.0),
        // Aérosols
        B::new("aerosol", "Aérosol", "Aérosols", Spatter).sp(0.15).press(0.0, 0.7).flow(0.6).rot().max(400.0),
        B::new("aerosol-gouttes", "Gouttes", "Aérosols", Spatter).sp(0.25).press(0.3, 0.4).flow(0.9).rot().scatter(0.6, 2).max(400.0),
        B::new("aerosol-fin", "Embout fin", "Aérosols", Soft).sp(0.08).press(0.2, 0.6).flow(0.3).max(200.0).grain(Noise, 0.6),
        // Retouches
        B::new("ret-doux", "Retouche douce", "Retouches", Soft).sp(0.06).press(0.2, 0.8).flow(0.2).max(300.0),
        B::new("ret-mouchetures", "Mouchetures", "Retouches", Spatter).sp(0.3).press(0.2, 0.3).rot().jitter(0.3, 0.6).max(160.0),
        B::new("ret-ombre", "Ombre portée", "Retouches", Cloud).sp(0.1).press(0.0, 0.8).flow(0.12).max(500.0),
        // Vintage
        B::new("vin-trame", "Trame", "Vintage", Ring).sp(0.9).press(0.6, 0.0).max(40.0),
        B::new("vin-encre-vieillie", "Encre vieillie", "Vintage", Rough).sp(0.06).press(0.6, 0.3).flow(0.9).rot().max(100.0).grain(Paper, 1.6),
        B::new("vin-tampon", "Tampon", "Vintage", Square).sp(0.08).press(0.2, 0.3).flow(0.85).max(160.0).grain(Noise, 1.2),
        // Luminance
        B::new("lum-lueur", "Lueur", "Luminance", Soft).sp(0.08).press(0.0, 0.8).flow(0.15).max(600.0).glow(),
        B::new("lum-neon", "Néon", "Luminance", Hard).sp(0.05).press(0.3, 0.0).flow(0.5).stream(0.4).max(60.0).glow(),
        B::new("lum-eclat", "Éclat", "Luminance", Star).sp(0.8).press(0.5, 0.3).rot().jitter(0.6, 0.4).scatter(0.5, 1).max(150.0).glow(),
        B::new("lum-bokeh", "Bokeh", "Luminance", Soft).sp(0.9).press(0.2, 0.4).jitter(0.7, 0.6).scatter(1.2, 1).max(200.0).glow(),
        // Industriel
        B::new("ind-beton", "Béton", "Industriel", Rough).sp(0.06).press(0.2, 0.5).flow(0.8).rot().max(300.0).grain(Noise, 2.0),
        B::new("ind-rouille", "Rouille", "Industriel", Spatter).sp(0.1).press(0.2, 0.5).flow(0.7).rot().max(300.0).grain(Paper, 2.0),
        B::new("ind-metal", "Métal brossé", "Industriel", Hair).sp(0.03).press(0.2, 0.3).flow(0.5).follow(1.0).max(300.0),
        // Organique
        B::new("org-feuilles", "Feuilles", "Organique", Leaf).sp(0.5).press(0.4, 0.2).rot().jitter(0.5, 0.3).scatter(0.6, 2).max(150.0),
        B::new("org-herbe", "Herbe", "Organique", Hair).sp(0.15).press(0.5, 0.2).jitter(0.5, 0.3).scatter(0.4, 3).max(120.0),
        B::new("org-ecorce", "Écorce", "Organique", Bristle).sp(0.05).press(0.4, 0.3).follow(0.5).max(200.0).grain(Paper, 1.8),
        // Eau
        B::new("eau-aquarelle", "Aquarelle", "Eau", Cloud).sp(0.06).press(0.3, 0.9).flow(0.15).stream(0.1).rot().max(400.0).grain(Paper, 1.2),
        B::new("eau-lavis", "Lavis humide", "Eau", Soft).sp(0.06).press(0.3, 0.9).flow(0.1).stream(0.1).max(500.0),
        B::new("eau-goutte", "Gouttes d'eau", "Eau", Ring).sp(0.7).press(0.4, 0.3).jitter(0.6, 0.3).scatter(0.6, 1).max(80.0),
    ];
    v.into_iter().map(|b| b.0).collect()
}

fn hash(x: u32, y: u32, s: u32) -> f32 {
    let mut h = x.wrapping_mul(374761393) ^ y.wrapping_mul(668265263) ^ s.wrapping_mul(2246822519);
    h = (h ^ (h >> 13)).wrapping_mul(1274126177);
    ((h ^ (h >> 16)) & 0xffff) as f32 / 65535.0
}

/// Génère une forme intégrée (taille TIP × TIP).
pub fn builtin_tip(shape: Shape) -> Vec<u8> {
    let n = TIP as usize;
    let mut base = vec![0u8; n * n];
    let c = (n as f32 - 1.0) / 2.0;
    for y in 0..n {
        for x in 0..n {
            let dx = (x as f32 - c) / (n as f32 / 2.0);
            let dy = (y as f32 - c) / (n as f32 / 2.0);
            let r = (dx * dx + dy * dy).sqrt();
            let v = match shape {
                Shape::Hard => (1.0 - ((r - 0.97) / 0.03).clamp(0.0, 1.0)).clamp(0.0, 1.0),
                Shape::Soft => {
                    let t = (1.0 - r).clamp(0.0, 1.0);
                    t * t * (3.0 - 2.0 * t)
                }
                Shape::Pencil => (1.0 - ((r - 0.8) / 0.2).clamp(0.0, 1.0)).clamp(0.0, 1.0),
                Shape::Chalk => {
                    let edge = (1.0 - ((r - 0.75) / 0.25).clamp(0.0, 1.0)).clamp(0.0, 1.0);
                    let g = hash(x as u32 / 4, y as u32 / 4, 3) * 0.5 + hash(x as u32 / 9, y as u32 / 9, 5) * 0.5;
                    edge * ((g - 0.25) / 0.5).clamp(0.0, 1.0)
                }
                Shape::Square => {
                    let m = dx.abs().max(dy.abs());
                    (1.0 - ((m - 0.9) / 0.06).clamp(0.0, 1.0)).clamp(0.0, 1.0)
                }
                Shape::Flat => {
                    // ellipse aplatie (pointe biseautée)
                    let rr = (dx * dx + (dy * 3.0) * (dy * 3.0)).sqrt();
                    (1.0 - ((rr - 0.92) / 0.06).clamp(0.0, 1.0)).clamp(0.0, 1.0)
                }
                Shape::Bristle => {
                    // poils : bandes verticales irrégulières
                    let band = hash((x / 6) as u32, 0, 13);
                    let len = 0.55 + 0.45 * hash((x / 6) as u32, 1, 17);
                    let inside = dx.abs() < 0.95 && dy.abs() < len;
                    if inside { 0.35 + 0.65 * band } else { 0.0 }
                }
                Shape::Spatter => {
                    // gouttelettes aléatoires dans le disque
                    let cell = 10;
                    let (cx, cy) = (x / cell, y / cell);
                    let h = hash(cx as u32, cy as u32, 23);
                    let ox = (cx * cell) as f32 + cell as f32 * hash(cx as u32, cy as u32, 29);
                    let oy = (cy * cell) as f32 + cell as f32 * hash(cx as u32, cy as u32, 31);
                    let d = ((x as f32 - ox).powi(2) + (y as f32 - oy).powi(2)).sqrt();
                    let rad = 1.5 + 4.0 * hash(cx as u32, cy as u32, 37);
                    if h > 0.55 && r < 1.0 && d < rad { 1.0 - (d / rad).powi(4) } else { 0.0 }
                }
                Shape::Cloud => {
                    let t = (1.0 - r).clamp(0.0, 1.0);
                    let g = hash(x as u32 / 8, y as u32 / 8, 41) * 0.6 + hash(x as u32 / 20, y as u32 / 20, 43) * 0.4;
                    (t * t * (3.0 - 2.0 * t)) * (0.45 + 0.55 * g)
                }
                Shape::Star => {
                    let a = dy.atan2(dx);
                    let lim = 0.45 + 0.5 * ((a * 5.0).cos() * 0.5 + 0.5).powf(3.0);
                    (1.0 - ((r - lim) / 0.04).clamp(0.0, 1.0)).clamp(0.0, 1.0)
                }
                Shape::Leaf => {
                    // feuille en amande verticale
                    let w = 0.5 * (1.0 - dy * dy).max(0.0).sqrt();
                    (1.0 - ((dx.abs() - w) / 0.05).clamp(0.0, 1.0)).clamp(0.0, 1.0) * if dy.abs() < 0.98 { 1.0 } else { 0.0 }
                }
                Shape::Rough => {
                    let a = dy.atan2(dx);
                    let lim = 0.8 + 0.15 * (hash(((a + 3.2) * 12.0) as u32, 0, 47) - 0.5) * 2.0;
                    let g = 0.7 + 0.3 * hash(x as u32 / 3, y as u32 / 3, 53);
                    (1.0 - ((r - lim) / 0.05).clamp(0.0, 1.0)).clamp(0.0, 1.0) * g
                }
                Shape::Hair => {
                    // trait fin vertical
                    (1.0 - ((dx.abs() - 0.06) / 0.04).clamp(0.0, 1.0)).clamp(0.0, 1.0) * (1.0 - dy.abs()).clamp(0.0, 1.0).sqrt()
                }
                Shape::Ring => {
                    let d = (r - 0.8).abs();
                    (1.0 - ((d - 0.1) / 0.05).clamp(0.0, 1.0)).clamp(0.0, 1.0)
                }
            };
            base[y * n + x] = (v * 255.0).round() as u8;
        }
    }
    base
}

/// Grain « papier » (fibres) et « toile » (tissage), se répètent sans couture.
pub fn paper_grain() -> Vec<u8> {
    let n = TIP as usize;
    let mut v = vec![0u8; n * n];
    for y in 0..n {
        for x in 0..n {
            let f1 = hash(x as u32 % 256, (y / 3) as u32 % 86, 61);
            let f2 = hash((x / 3) as u32 % 86, y as u32 % 256, 67);
            let g = hash(x as u32, y as u32, 71);
            v[y * n + x] = ((0.35 * f1 + 0.35 * f2 + 0.3 * g).powf(0.8).clamp(0.0, 1.0) * 255.0) as u8;
        }
    }
    v
}

pub fn canvas_grain() -> Vec<u8> {
    let n = TIP as usize;
    let mut v = vec![0u8; n * n];
    for y in 0..n {
        for x in 0..n {
            let a = ((x as f32 / 8.0) * std::f32::consts::TAU).sin();
            let b = ((y as f32 / 8.0) * std::f32::consts::TAU).sin();
            let w = 0.5 + 0.25 * a * b.signum() + 0.25 * b * a.signum();
            let g = 0.8 * w + 0.2 * hash(x as u32, y as u32, 73);
            v[y * n + x] = (g.clamp(0.0, 1.0) * 255.0) as u8;
        }
    }
    v
}

/// Grain de papier par défaut (bruit en amas, se répète sans couture).
pub fn noise_grain() -> Vec<u8> {
    let n = TIP as usize;
    let mut v = vec![0u8; n * n];
    for y in 0..n {
        for x in 0..n {
            let g = hash(x as u32, y as u32, 31) * 0.45 + hash(x as u32 / 2 % 128, y as u32 / 2 % 128, 37) * 0.35 + hash(x as u32 * 51 / 256, y as u32 * 51 / 256, 41) * 0.2;
            v[y * n + x] = (((g - 0.3) / 0.55).clamp(0.0, 1.0).powf(1.3) * 255.0) as u8;
        }
    }
    v
}

/// Chaîne de mipmaps d'un masque carré.
pub fn mips(base: Vec<u8>, size: usize) -> Vec<Vec<u8>> {
    let mut levels = vec![base];
    let mut s = size;
    while s > 1 {
        let prev = levels.last().unwrap();
        let ns = s / 2;
        let mut next = vec![0u8; ns * ns];
        for y in 0..ns {
            for x in 0..ns {
                let a = prev[(2 * y) * s + 2 * x] as u32 + prev[(2 * y) * s + 2 * x + 1] as u32 + prev[(2 * y + 1) * s + 2 * x] as u32 + prev[(2 * y + 1) * s + 2 * x + 1] as u32;
                next[y * ns + x] = ((a + 2) / 4) as u8;
            }
        }
        levels.push(next);
        s = ns;
    }
    levels
}

pub fn eval_curve(c: &Option<Vec<[f32; 2]>>, x: f32) -> f32 {
    let Some(c) = c else { return x };
    if c.is_empty() {
        return x;
    }
    if x <= c[0][0] {
        return c[0][1];
    }
    for w in c.windows(2) {
        if x <= w[1][0] {
            let t = (x - w[0][0]) / (w[1][0] - w[0][0]).max(1e-6);
            return w[0][1] + (w[1][1] - w[0][1]) * t;
        }
    }
    c[c.len() - 1][1]
}

#[derive(Clone, Copy, Debug)]
pub struct Point {
    pub x: f32,
    pub y: f32,
    pub p: f32,
    /// Temps en secondes depuis le début du trait
    pub t: f32,
}

/// Construit les tampons au fur et à mesure du trait.
pub struct StrokeBuilder {
    pub brush: Brush,
    pub size: f32,
    pub pressure_curve: f32,
    smooth: Option<Point>,
    last: Option<Point>,
    carry: f32,
    /// longueur parcourue jusqu'au début du segment en cours
    dist: f32,
    /// position du tampon en cours le long du trait
    cur: f32,
    total: Option<f32>,
    speed: f32,
    rng: u32,
    dir: f32,
    pub points: Vec<Point>,
    pub dabs_count: usize,
    /// trait remplacé par une forme rapide
    pub shaped: bool,
}

impl StrokeBuilder {
    pub fn new(brush: Brush, size: f32, pressure_curve: f32) -> Self {
        StrokeBuilder { brush, size, pressure_curve, smooth: None, last: None, carry: 0.0, dist: 0.0, cur: 0.0, total: None, speed: 0.0, rng: 0x9e37_79b9, dir: 0.0, points: Vec::new(), dabs_count: 0, shaped: false }
    }

    fn rand(&mut self) -> f32 {
        self.rng ^= self.rng << 13;
        self.rng ^= self.rng >> 17;
        self.rng ^= self.rng << 5;
        (self.rng & 0xff_ffff) as f32 / 16_777_215.0
    }

    fn pr(&self, p: f32) -> f32 {
        p.clamp(0.0, 1.0).powf(self.pressure_curve)
    }

    fn size_at(&self, p: f32) -> f32 {
        let b = &self.brush;
        let ps = eval_curve(&b.size_curve, self.pr(p));
        let mut s = self.size * (b.min_size + (1.0 - b.min_size) * (1.0 - b.size_p + b.size_p * ps));
        if b.speed_size != 0.0 {
            s *= 1.0 - 0.45 * b.speed_size * (self.speed / 2.5).min(1.0);
        }
        if b.taper_size > 0.0 {
            let k = 1.0 - b.taper_size.min(1.0);
            if b.taper_start > 0.0 {
                let l = b.taper_start * 400.0;
                if self.cur < l {
                    s *= k + (1.0 - k) * (self.cur / l * std::f32::consts::FRAC_PI_2).sin();
                }
            }
            if let Some(total) = self.total {
                if b.taper_end > 0.0 {
                    let l = b.taper_end * 400.0;
                    let rem = (total - self.cur).max(0.0);
                    if rem < l {
                        s *= k + (1.0 - k) * (rem / l * std::f32::consts::FRAC_PI_2).sin();
                    }
                }
            }
        }
        s.max(0.3)
    }

    fn dabs_at(&mut self, x: f32, y: f32, p: f32, out: &mut Vec<Dab>) {
        let b = self.brush.clone();
        let mut size = self.size_at(p);
        if b.size_jitter > 0.0 {
            size *= 1.0 - b.size_jitter * self.rand();
        }
        for _ in 0..b.count.clamp(1, 8) {
            let (mut px, mut py) = (x, y);
            if b.scatter > 0.0 {
                let a = self.rand() * std::f32::consts::TAU;
                let r = self.rand() * b.scatter * size;
                px += a.cos() * r;
                py += a.sin() * r;
            }
            let opc = eval_curve(&b.op_curve, self.pr(p));
            let mut alpha = b.flow * (1.0 - b.op_p + b.op_p * opc);
            if b.op_jitter > 0.0 {
                alpha *= 1.0 - b.op_jitter * self.rand();
            }
            if size < 1.0 {
                alpha *= size;
            }
            let angle = if b.follow {
                self.dir + std::f32::consts::FRAC_PI_2
            } else if b.rot_rand {
                self.rand() * std::f32::consts::TAU
            } else {
                0.0
            };
            out.push(Dab { pos: [px, py], size, angle, alpha, aspect: if b.follow { b.squash.clamp(0.05, 1.0) } else { 1.0 } });
            self.dabs_count += 1;
        }
    }

    fn spacing_px(&self, p: f32) -> f32 {
        (self.size_at(p) * self.brush.spacing).max(0.35)
    }

    /// Ajoute un point d'entrée ; renvoie les tampons à dessiner.
    pub fn add(&mut self, raw: Point) -> Vec<Dab> {
        if self.total.is_none() {
            self.points.push(raw);
        }
        let k = self.brush.streamline.clamp(0.0, 0.95);
        let pt = match self.smooth {
            None => raw,
            Some(s) => Point { x: s.x + (raw.x - s.x) * (1.0 - k), y: s.y + (raw.y - s.y) * (1.0 - k), p: s.p + (raw.p - s.p) * 0.6, t: raw.t },
        };
        self.smooth = Some(pt);
        let mut out = Vec::new();
        match self.last {
            None => {
                if !self.brush.follow {
                    self.cur = 0.0;
                    self.dabs_at(pt.x, pt.y, pt.p, &mut out);
                }
                self.last = Some(pt);
                self.carry = 0.0;
            }
            Some(l) => {
                let dx = pt.x - l.x;
                let dy = pt.y - l.y;
                let dist = (dx * dx + dy * dy).sqrt();
                if dist < 1e-4 {
                    return out;
                }
                let dt = ((pt.t - l.t) * 1000.0).max(1.0);
                self.speed = self.speed * 0.7 + (dist / dt) * 0.3;
                self.dir = dy.atan2(dx);
                let mut pos = 0.0f32;
                loop {
                    self.cur = self.dist + pos;
                    let p = l.p + (pt.p - l.p) * (pos / dist).min(1.0);
                    let need = self.spacing_px(p) - self.carry;
                    if pos + need > dist {
                        self.carry += dist - pos;
                        break;
                    }
                    pos += need.max(0.0);
                    self.carry = 0.0;
                    self.cur = self.dist + pos;
                    let f = pos / dist;
                    self.dabs_at(l.x + dx * f, l.y + dy * f, l.p + (pt.p - l.p) * f, &mut out);
                }
                self.dist += dist;
                self.last = Some(pt);
            }
        }
        out
    }

    /// Termine le trait : rattrape le lissage jusqu'au dernier point réel.
    pub fn finish(&mut self, raw: Point) -> Vec<Dab> {
        let saved = self.brush.streamline;
        self.brush.streamline = 0.0;
        let mut out = if self.smooth.is_some() { self.add(raw) } else { Vec::new() };
        self.brush.streamline = saved;
        if self.dabs_count == 0 {
            // simple toucher : au moins un tampon
            let follow = self.brush.follow;
            self.brush.follow = false;
            self.dabs_at(raw.x, raw.y, raw.p, &mut out);
            self.brush.follow = follow;
        }
        out
    }

    /// L'effilement de fin demande de connaître la longueur totale : on recalcule tout le trait.
    pub fn needs_replay(&self) -> bool {
        self.brush.taper_end > 0.0 && self.brush.taper_size > 0.0 && self.dist > 2.0 && self.points.len() > 1
    }

    pub fn replay(&mut self) -> Vec<Dab> {
        let total = self.dist;
        let pts = std::mem::take(&mut self.points);
        let mut fresh = StrokeBuilder::new(self.brush.clone(), self.size, self.pressure_curve);
        fresh.total = Some(total);
        let mut out = Vec::new();
        for p in &pts[..pts.len() - 1] {
            out.extend(fresh.add(*p));
        }
        out.extend(fresh.finish(*pts.last().unwrap()));
        out
    }
}

// ---------------- Formes rapides (QuickShape) ----------------

fn rdp(pts: &[(f32, f32)], eps: f32, out: &mut Vec<(f32, f32)>) {
    if pts.len() < 3 {
        out.extend_from_slice(pts);
        return;
    }
    let (a, b) = (pts[0], pts[pts.len() - 1]);
    let (dx, dy) = (b.0 - a.0, b.1 - a.1);
    let len = (dx * dx + dy * dy).sqrt().max(1e-6);
    let (mut imax, mut dmax) = (0, 0.0f32);
    for (i, p) in pts.iter().enumerate().skip(1).take(pts.len() - 2) {
        let d = ((p.0 - a.0) * dy - (p.1 - a.1) * dx).abs() / len;
        if d > dmax {
            dmax = d;
            imax = i;
        }
    }
    if dmax > eps {
        rdp(&pts[..=imax], eps, out);
        out.pop();
        rdp(&pts[imax..], eps, out);
    } else {
        out.push(a);
        out.push(b);
    }
}

/// Transforme un trait à main levée en forme nette : ligne, ellipse ou polygone.
pub fn quick_shape(pts: &[Point]) -> Option<(Vec<(f32, f32)>, &'static str)> {
    if pts.len() < 4 {
        return None;
    }
    let xy: Vec<(f32, f32)> = pts.iter().map(|p| (p.x, p.y)).collect();
    let (a, b) = (xy[0], xy[xy.len() - 1]);
    let chord = ((b.0 - a.0).powi(2) + (b.1 - a.1).powi(2)).sqrt();
    let path: f32 = xy.windows(2).map(|w| ((w[1].0 - w[0].0).powi(2) + (w[1].1 - w[0].1).powi(2)).sqrt()).sum();
    if path < 12.0 {
        return None;
    }
    // ligne droite
    let maxdev = xy.iter().map(|p| ((p.0 - a.0) * (b.1 - a.1) - (p.1 - a.1) * (b.0 - a.0)).abs() / chord.max(1e-6)).fold(0.0f32, f32::max);
    if chord > 0.8 * path && maxdev < (0.06 * chord).max(6.0) {
        return Some((vec![a, b], "ligne"));
    }
    let closed = chord < 0.2 * path;
    if closed {
        // ellipse : centre, axes principaux (covariance)
        let n = xy.len() as f32;
        let (mx, my) = (xy.iter().map(|p| p.0).sum::<f32>() / n, xy.iter().map(|p| p.1).sum::<f32>() / n);
        let (mut sxx, mut syy, mut sxy) = (0.0, 0.0, 0.0);
        for p in &xy {
            sxx += (p.0 - mx).powi(2);
            syy += (p.1 - my).powi(2);
            sxy += (p.0 - mx) * (p.1 - my);
        }
        let th = 0.5 * (2.0 * sxy).atan2(sxx - syy);
        let (sn, cs) = th.sin_cos();
        let (mut ra, mut rb) = (0.0f32, 0.0f32);
        for p in &xy {
            let (u, v) = ((p.0 - mx) * cs + (p.1 - my) * sn, -(p.0 - mx) * sn + (p.1 - my) * cs);
            ra += u * u;
            rb += v * v;
        }
        let (ra, rb) = ((2.0 * ra / n).sqrt(), (2.0 * rb / n).sqrt());
        // erreur de l'ellipse
        let err = xy
            .iter()
            .map(|p| {
                let (u, v) = ((p.0 - mx) * cs + (p.1 - my) * sn, -(p.0 - mx) * sn + (p.1 - my) * cs);
                ((u / ra.max(1.0)).powi(2) + (v / rb.max(1.0)).powi(2)).sqrt() - 1.0
            })
            .map(f32::abs)
            .sum::<f32>()
            / n;
        let mut poly = Vec::new();
        rdp(&xy, 0.08 * ra.max(rb), &mut poly);
        if err > 0.12 && (4..=7).contains(&poly.len()) {
            // polygone fermé (triangle, carré…)
            poly.pop();
            poly.push(poly[0]);
            return Some((poly, "polygone"));
        }
        let pts: Vec<(f32, f32)> = (0..=120)
            .map(|i| {
                let t = i as f32 / 120.0 * std::f32::consts::TAU;
                let (u, v) = (ra * t.cos(), rb * t.sin());
                (mx + u * cs - v * sn, my + u * sn + v * cs)
            })
            .collect();
        return Some((pts, "ellipse"));
    }
    let mut poly = Vec::new();
    rdp(&xy, (0.04 * path).max(4.0), &mut poly);
    Some((poly, "polyligne"))
}
