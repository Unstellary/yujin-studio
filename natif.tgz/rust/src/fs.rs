//! Fichiers de l'appli. Sur ordinateur et Android : le vrai disque.
//! Dans le navigateur (iPad…) : un petit disque virtuel en mémoire, enregistré dans IndexedDB.

use std::path::{Path, PathBuf};

#[cfg(not(target_arch = "wasm32"))]
mod imp {
    use super::*;

    pub fn read(p: &Path) -> std::io::Result<Vec<u8>> {
        std::fs::read(p)
    }
    pub fn write(p: &Path, data: &[u8]) -> std::io::Result<()> {
        if let Some(d) = p.parent() {
            let _ = std::fs::create_dir_all(d);
        }
        std::fs::write(p, data)
    }
    pub fn remove(p: &Path) -> std::io::Result<()> {
        std::fs::remove_file(p)
    }
    pub fn exists(p: &Path) -> bool {
        p.exists()
    }
    /// Fichiers d'un dossier, avec leur date de modification (ms).
    pub fn list(dir: &Path) -> Vec<(PathBuf, u64)> {
        let _ = std::fs::create_dir_all(dir);
        std::fs::read_dir(dir)
            .map(|rd| {
                rd.flatten()
                    .filter(|e| e.file_type().map(|t| t.is_file()).unwrap_or(false))
                    .map(|e| {
                        let t = e.metadata().and_then(|m| m.modified()).ok().and_then(|t| t.duration_since(std::time::UNIX_EPOCH).ok()).map(|d| d.as_millis() as u64).unwrap_or(0);
                        (e.path(), t)
                    })
                    .collect()
            })
            .unwrap_or_default()
    }
}

#[cfg(target_arch = "wasm32")]
mod imp {
    use super::*;
    use std::cell::RefCell;
    use std::collections::BTreeMap;
    use wasm_bindgen::prelude::*;

    #[wasm_bindgen(inline_js = r#"
let dbp = null;
function db() {
  if (!dbp) dbp = new Promise((ok, ko) => {
    const r = indexedDB.open('yujin-studio-natif', 1);
    r.onupgradeneeded = () => { if (!r.result.objectStoreNames.contains('fichiers')) r.result.createObjectStore('fichiers'); };
    r.onsuccess = () => ok(r.result);
    r.onerror = () => ko(r.error);
  });
  return dbp;
}
export async function idb_load_all() {
  try { return await load_all(); } catch (e) { console.error('IndexedDB', e); return []; }
}
async function load_all() {
  const d = await db();
  return await new Promise((ok, ko) => {
    const out = [];
    const tx = d.transaction('fichiers', 'readonly');
    const c = tx.objectStore('fichiers').openCursor();
    c.onsuccess = () => {
      const cur = c.result;
      if (cur) { out.push([String(cur.key), cur.value.t || 0, new Uint8Array(cur.value.d)]); cur.continue(); }
      else ok(out);
    };
    c.onerror = () => ko(c.error);
  });
}
export function idb_put(k, t, data) {
  const copy = data.slice();
  db().then(d => d.transaction('fichiers', 'readwrite').objectStore('fichiers').put({ t, d: copy.buffer }, k)).catch(e => console.error(e));
}
export function idb_del(k) {
  db().then(d => d.transaction('fichiers', 'readwrite').objectStore('fichiers').delete(k)).catch(e => console.error(e));
}
export function persist() { try { navigator.storage && navigator.storage.persist && navigator.storage.persist(); } catch (e) {} }
"#)]
    extern "C" {
        async fn idb_load_all() -> JsValue;
        fn idb_put(k: &str, t: f64, data: &[u8]);
        fn idb_del(k: &str);
        fn persist();
    }

    thread_local! {
        static FILES: RefCell<BTreeMap<String, (u64, Vec<u8>)>> = RefCell::new(BTreeMap::new());
    }

    fn key(p: &Path) -> String {
        p.to_string_lossy().replace('\\', "/")
    }

    fn now() -> u64 {
        js_sys::Date::now() as u64
    }

    /// Charge tout le disque virtuel depuis IndexedDB (au démarrage).
    pub async fn init() {
        persist();
        let v = idb_load_all().await;
        let arr = js_sys::Array::from(&v);
        FILES.with(|f| {
            let mut f = f.borrow_mut();
            for e in arr.iter() {
                let e = js_sys::Array::from(&e);
                let k = e.get(0).as_string().unwrap_or_default();
                let t = e.get(1).as_f64().unwrap_or(0.0) as u64;
                let d = js_sys::Uint8Array::new(&e.get(2)).to_vec();
                f.insert(k, (t, d));
            }
        });
    }

    fn nf(p: &Path) -> std::io::Error {
        std::io::Error::new(std::io::ErrorKind::NotFound, format!("{} introuvable", p.display()))
    }

    pub fn read(p: &Path) -> std::io::Result<Vec<u8>> {
        FILES.with(|f| f.borrow().get(&key(p)).map(|(_, d)| d.clone())).ok_or_else(|| nf(p))
    }
    pub fn write(p: &Path, data: &[u8]) -> std::io::Result<()> {
        let k = key(p);
        let t = now();
        idb_put(&k, t as f64, data);
        FILES.with(|f| f.borrow_mut().insert(k, (t, data.to_vec())));
        Ok(())
    }
    pub fn remove(p: &Path) -> std::io::Result<()> {
        let k = key(p);
        idb_del(&k);
        FILES.with(|f| f.borrow_mut().remove(&k)).map(|_| ()).ok_or_else(|| nf(p))
    }
    pub fn exists(p: &Path) -> bool {
        FILES.with(|f| f.borrow().contains_key(&key(p)))
    }
    pub fn list(dir: &Path) -> Vec<(PathBuf, u64)> {
        let mut pre = key(dir);
        if !pre.ends_with('/') {
            pre.push('/');
        }
        FILES.with(|f| {
            f.borrow()
                .iter()
                .filter(|(k, _)| k.starts_with(&pre) && !k[pre.len()..].contains('/'))
                .map(|(k, (t, _))| (PathBuf::from(k), *t))
                .collect()
        })
    }
}

pub use imp::*;

pub fn read_to_string(p: &Path) -> std::io::Result<String> {
    String::from_utf8(read(p)?).map_err(|e| std::io::Error::new(std::io::ErrorKind::InvalidData, e))
}
