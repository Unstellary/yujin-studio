//! Bibliothèque de pinceaux : pinceaux intégrés + pinceaux importés (enregistrés dans le dossier de l'appli).

use crate::brush::{self, Brush, GrainSrc, TipSrc};
use std::path::PathBuf;

fn dir() -> PathBuf {
    crate::doc::data_dir().join("pinceaux")
}

fn index_path() -> PathBuf {
    dir().join("bibliotheque.json")
}

/// Pinceaux importés uniquement (les intégrés sont ajoutés au chargement).
fn load_imported() -> Vec<Brush> {
    crate::fs::read_to_string(&index_path()).ok().and_then(|s| serde_json::from_str(&s).ok()).unwrap_or_default()
}

pub fn load() -> Vec<Brush> {
    let mut v = brush::builtins();
    v.extend(load_imported());
    v
}

pub fn save(all: &[Brush]) {
    let imported: Vec<&Brush> = all.iter().filter(|b| !is_builtin(b)).collect();
    if let Ok(s) = serde_json::to_string(&imported) {
        let _ = crate::fs::write(&index_path(), s.as_bytes());
    }
}

pub fn is_builtin(b: &Brush) -> bool {
    !b.id.starts_with("imp-")
}

pub fn tip_key(b: &Brush) -> String {
    format!("{}|{:?}|{:?}|{}|{}", b.id, b.tip, b.grain, b.grain_scale, b.op_map)
}

fn load_mask(name: &str) -> Option<Vec<u8>> {
    let data = crate::fs::read(&dir().join(name)).ok()?;
    let (w, h, px) = crate::doc::decode_png(&data)?;
    if w != brush::TIP || h != brush::TIP {
        return None;
    }
    Some(px.chunks_exact(4).map(|p| p[0]).collect())
}

fn save_mask(name: &str, m: &[u8]) {
    let rgba: Vec<u8> = m.iter().flat_map(|&v| [v, v, v, 255]).collect();
    let _ = crate::fs::write(&dir().join(name), &crate::doc::encode_png(brush::TIP, brush::TIP, &rgba));
}

/// Masques (avec mipmaps) de la forme et du grain d'un pinceau.
pub fn masks(b: &Brush) -> (Vec<Vec<u8>>, Option<Vec<Vec<u8>>>) {
    let n = brush::TIP as usize;
    let tip = match &b.tip {
        TipSrc::Builtin(s) => brush::builtin_tip(*s),
        TipSrc::Custom(f) => load_mask(f).unwrap_or_else(|| brush::builtin_tip(brush::Shape::Hard)),
    };
    let grain = b.grain.as_ref().map(|g| match g {
        GrainSrc::Noise => brush::noise_grain(),
        GrainSrc::Paper => brush::paper_grain(),
        GrainSrc::Canvas => brush::canvas_grain(),
        GrainSrc::Custom(f) => load_mask(f).unwrap_or_else(brush::noise_grain),
    });
    (brush::mips(tip, n), grain.map(|g| brush::mips(g, n)))
}

fn new_id() -> String {
    static N: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
    let t = web_time::SystemTime::now().duration_since(web_time::UNIX_EPOCH).map(|d| d.as_nanos()).unwrap_or(0);
    let n = N.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
    format!("imp-{:x}{:x}", t, n)
}

/// Importe un .brush / .brushset ; renvoie (catégorie, nombre de pinceaux).
pub fn import(all: &mut Vec<Brush>, data: &[u8], file_name: &str) -> Result<(String, usize), String> {
    let (set, list) = crate::procreate::import_brushes(data, file_name)?;
    let cat = set.unwrap_or_else(|| "Importés".to_string());
    let mut n = 0;
    for ib in list {
        let mut b = ib.brush;
        // pas de doublon (même nom dans la même catégorie)
        if all.iter().any(|x| x.cat == cat && x.name == b.name) {
            continue;
        }
        b.id = new_id();
        b.cat = cat.clone();
        if let Some(t) = &ib.tip {
            let f = format!("{}-forme.png", b.id);
            save_mask(&f, t);
            b.tip = TipSrc::Custom(f);
        }
        if let Some(g) = &ib.grain {
            let f = format!("{}-grain.png", b.id);
            save_mask(&f, g);
            b.grain = Some(GrainSrc::Custom(f));
        }
        all.push(b);
        n += 1;
        #[cfg(not(target_arch = "wasm32"))]
        std::thread::sleep(std::time::Duration::from_micros(10));
    }
    save(all);
    Ok((cat, n))
}

pub fn delete(all: &mut Vec<Brush>, id: &str) {
    if let Some(i) = all.iter().position(|b| b.id == id && !is_builtin(b)) {
        let b = all.remove(i);
        if let TipSrc::Custom(f) = &b.tip {
            let _ = crate::fs::remove(&dir().join(f));
        }
        if let Some(GrainSrc::Custom(f)) = &b.grain {
            let _ = crate::fs::remove(&dir().join(f));
        }
        save(all);
    }
}

pub fn categories(all: &[Brush]) -> Vec<String> {
    let mut cats: Vec<String> = brush::CATEGORIES.iter().map(|s| s.to_string()).collect();
    for b in all {
        if !cats.contains(&b.cat) {
            cats.push(b.cat.clone());
        }
    }
    cats
}
