#![cfg_attr(all(windows, not(debug_assertions)), windows_subsystem = "windows")]

fn main() {
    #[cfg(not(target_os = "android"))]
    yujin_studio::run_desktop();
}
