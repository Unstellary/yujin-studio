//! Écriture d'un fichier PSD (Photoshop) avec calques, noms, opacité, visibilité et modes de fusion.

use crate::doc::DocInfo;

fn blend_key(m: u32) -> &'static [u8; 4] {
    match m {
        1 => b"mul ",
        2 => b"scrn",
        3 => b"over",
        4 => b"dark",
        5 => b"lite",
        6 => b"div ",
        7 => b"idiv",
        8 => b"hLit",
        9 => b"sLit",
        10 => b"diff",
        11 => b"smud",
        12 => b"lddg",
        13 => b"fsub",
        14 => b"hue ",
        15 => b"sat ",
        16 => b"colr",
        17 => b"lum ",
        18 => b"lbrn",
        _ => b"norm",
    }
}

struct W(Vec<u8>);
impl W {
    fn u8(&mut self, v: u8) {
        self.0.push(v);
    }
    fn u16(&mut self, v: u16) {
        self.0.extend_from_slice(&v.to_be_bytes());
    }
    fn i16(&mut self, v: i16) {
        self.0.extend_from_slice(&v.to_be_bytes());
    }
    fn u32(&mut self, v: u32) {
        self.0.extend_from_slice(&v.to_be_bytes());
    }
    fn bytes(&mut self, b: &[u8]) {
        self.0.extend_from_slice(b);
    }
    fn patch_u32(&mut self, at: usize, v: u32) {
        self.0[at..at + 4].copy_from_slice(&v.to_be_bytes());
    }
}

/// Compression RLE (PackBits) d'une ligne.
fn packbits(row: &[u8], out: &mut Vec<u8>) {
    let n = row.len();
    let mut i = 0;
    while i < n {
        let mut j = i + 1;
        while j < n && j - i < 128 && row[j] == row[i] {
            j += 1;
        }
        if j - i >= 2 {
            out.push((1i16 - (j - i) as i16) as u8);
            out.push(row[i]);
            i = j;
        } else {
            let start = i;
            let mut k = i + 1;
            while k < n && k - start < 128 && !(k + 1 < n && row[k] == row[k + 1]) {
                k += 1;
            }
            out.push((k - start - 1) as u8);
            out.extend_from_slice(&row[start..k]);
            i = k;
        }
    }
}

/// Canal compressé en RLE : (tailles des lignes, données).
fn rle_channel(px: &[u8], w: usize, h: usize, ch: usize) -> (Vec<u16>, Vec<u8>) {
    let mut sizes = Vec::with_capacity(h);
    let mut data = Vec::new();
    let mut row = vec![0u8; w];
    for y in 0..h {
        for x in 0..w {
            row[x] = px[(y * w + x) * 4 + ch];
        }
        let before = data.len();
        packbits(&row, &mut data);
        sizes.push((data.len() - before) as u16);
    }
    (sizes, data)
}

/// `layers` : pixels RGBA non prémultipliés ; `flat` : image finale non prémultipliée.
pub fn write(info: &DocInfo, layers: &[Vec<u8>], flat: &[u8]) -> Vec<u8> {
    let (w, h) = (info.w as usize, info.h as usize);
    let mut o = W(Vec::with_capacity(w * h * 4));
    o.bytes(b"8BPS");
    o.u16(1);
    o.bytes(&[0; 6]);
    o.u16(4); // RVBA
    o.u32(h as u32);
    o.u32(w as u32);
    o.u16(8);
    o.u16(3); // RVB
    o.u32(0); // couleurs
    o.u32(0); // ressources
    // ---- calques ----
    let lm_at = o.0.len();
    o.u32(0);
    let li_at = o.0.len();
    o.u32(0);
    o.i16(-(layers.len() as i16)); // négatif : le canal alpha est la transparence de l'image fusionnée
    let mut channels = Vec::new();
    for (i, px) in layers.iter().enumerate() {
        let l = &info.layers[i];
        let chans: Vec<(i16, (Vec<u16>, Vec<u8>))> = [(-1i16, 3usize), (0, 0), (1, 1), (2, 2)].iter().map(|&(id, c)| (id, rle_channel(px, w, h, c))).collect();
        o.u32(0);
        o.u32(0);
        o.u32(h as u32);
        o.u32(w as u32);
        o.u16(4);
        for (id, (sizes, data)) in &chans {
            o.i16(*id);
            o.u32((2 + sizes.len() * 2 + data.len()) as u32);
        }
        o.bytes(b"8BIM");
        o.bytes(blend_key(l.mode));
        o.u8((l.opacity.clamp(0.0, 1.0) * 255.0).round() as u8);
        o.u8(0);
        let mut flags = 0u8;
        if l.lock_alpha {
            flags |= 1;
        }
        if !l.visible {
            flags |= 2;
        }
        o.u8(flags);
        o.u8(0);
        // données supplémentaires : masque (vide), plages de fusion (vides), nom, nom Unicode
        let extra_at = o.0.len();
        o.u32(0);
        o.u32(0);
        o.u32(0);
        let name_bytes: Vec<u8> = l.name.chars().map(|c| if (c as u32) < 128 { c as u8 } else { b'?' }).take(255).collect();
        let pn = name_bytes.len() + 1;
        o.u8(name_bytes.len() as u8);
        o.bytes(&name_bytes);
        for _ in 0..((4 - pn % 4) % 4) {
            o.u8(0);
        }
        o.bytes(b"8BIMluni");
        let utf16: Vec<u16> = l.name.encode_utf16().collect();
        let len = 4 + utf16.len() * 2;
        let padded = len + (len % 2);
        o.u32(padded as u32);
        o.u32(utf16.len() as u32);
        for c in &utf16 {
            o.u16(*c);
        }
        if len % 2 == 1 {
            o.u8(0);
        }
        let extra_len = o.0.len() - extra_at - 4;
        o.patch_u32(extra_at, extra_len as u32);
        channels.push(chans);
    }
    for chans in channels {
        for (_, (sizes, data)) in chans {
            o.u16(1); // RLE
            for s in sizes {
                o.u16(s);
            }
            o.bytes(&data);
        }
    }
    if (o.0.len() - li_at - 4) % 2 == 1 {
        o.u8(0);
    }
    let li_len = o.0.len() - li_at - 4;
    o.patch_u32(li_at, li_len as u32);
    o.u32(0); // masque global
    let lm_len = o.0.len() - lm_at - 4;
    o.patch_u32(lm_at, lm_len as u32);
    // ---- image fusionnée ----
    o.u16(1);
    let merged: Vec<(Vec<u16>, Vec<u8>)> = [0usize, 1, 2, 3].iter().map(|&c| rle_channel(flat, w, h, c)).collect();
    for (sizes, _) in &merged {
        for s in sizes {
            o.u16(*s);
        }
    }
    for (_, data) in merged {
        o.bytes(&data);
    }
    o.0
}
