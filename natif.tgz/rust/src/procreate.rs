//! Import des fichiers Procreate : .brush / .brushset (pinceaux), .swatches (palettes), .procreate (dessins).

use crate::brush::{Brush, GrainSrc, TipSrc};
use std::collections::HashMap;
use std::io::Read;

// ---------------- plist binaire ----------------

#[derive(Clone, Debug)]
pub enum V {
    Null,
    Bool(bool),
    Int(i64),
    Real(f64),
    Data(Vec<u8>),
    Str(String),
    Uid(u64),
    Arr(Vec<V>),
    Dict(Vec<(V, V)>),
}

impl V {
    pub fn get(&self, key: &str) -> Option<&V> {
        match self {
            V::Dict(d) => d.iter().find(|(k, _)| matches!(k, V::Str(s) if s == key)).map(|(_, v)| v),
            _ => None,
        }
    }
    pub fn num(&self) -> Option<f64> {
        match self {
            V::Int(i) => Some(*i as f64),
            V::Real(r) if r.is_finite() => Some(*r),
            V::Bool(b) => Some(*b as i64 as f64),
            _ => None,
        }
    }
    pub fn str(&self) -> Option<&str> {
        match self {
            V::Str(s) => Some(s),
            _ => None,
        }
    }
    pub fn truthy(&self) -> bool {
        match self {
            V::Bool(b) => *b,
            V::Int(i) => *i != 0,
            V::Real(r) => *r != 0.0,
            V::Null => false,
            _ => true,
        }
    }
    pub fn keys(&self) -> Vec<&str> {
        match self {
            V::Dict(d) => d.iter().filter_map(|(k, _)| k.str()).collect(),
            _ => vec![],
        }
    }
}

fn be(b: &[u8], o: usize, n: usize) -> Option<u64> {
    let s = b.get(o..o + n)?;
    Some(s.iter().fold(0u64, |a, &x| (a << 8) | x as u64))
}

pub fn parse_bplist(b: &[u8]) -> Option<V> {
    if b.len() < 40 || &b[..6] != b"bplist" {
        return None;
    }
    let t = b.len() - 32;
    let off_size = b[t + 6] as usize;
    let ref_size = b[t + 7] as usize;
    let num = be(b, t + 8, 8)? as usize;
    let top = be(b, t + 16, 8)? as usize;
    let table = be(b, t + 24, 8)? as usize;
    let offs: Vec<usize> = (0..num).map(|i| be(b, table + i * off_size, off_size).unwrap_or(0) as usize).collect();
    fn obj(b: &[u8], offs: &[usize], ref_size: usize, i: usize, depth: u32) -> V {
        if depth > 64 || i >= offs.len() {
            return V::Null;
        }
        let o = offs[i];
        let Some(&m) = b.get(o) else { return V::Null };
        let (hi, lo) = (m >> 4, (m & 15) as usize);
        let count = || -> (usize, usize) {
            if lo != 15 {
                return (lo, o + 1);
            }
            let im = *b.get(o + 1).unwrap_or(&0);
            let sz = 1usize << (im & 15);
            (be(b, o + 2, sz).unwrap_or(0) as usize, o + 2 + sz)
        };
        match hi {
            0 => match lo {
                8 => V::Bool(false),
                9 => V::Bool(true),
                _ => V::Null,
            },
            1 => {
                let sz = 1usize << lo;
                let v = be(b, o + 1, sz).unwrap_or(0);
                V::Int(if sz == 8 { v as i64 } else { v as i64 })
            }
            2 => {
                if lo == 2 {
                    V::Real(f32::from_bits(be(b, o + 1, 4).unwrap_or(0) as u32) as f64)
                } else {
                    V::Real(f64::from_bits(be(b, o + 1, 8).unwrap_or(0)))
                }
            }
            3 => V::Real(f64::from_bits(be(b, o + 1, 8).unwrap_or(0))),
            4 => {
                let (c, s) = count();
                V::Data(b.get(s..s + c).unwrap_or(&[]).to_vec())
            }
            5 => {
                let (c, s) = count();
                V::Str(b.get(s..s + c).unwrap_or(&[]).iter().map(|&x| x as char).collect())
            }
            6 => {
                let (c, s) = count();
                let u: Vec<u16> = (0..c).map(|k| be(b, s + k * 2, 2).unwrap_or(0) as u16).collect();
                V::Str(String::from_utf16_lossy(&u))
            }
            8 => V::Uid(be(b, o + 1, lo + 1).unwrap_or(0)),
            10 | 12 => {
                let (c, s) = count();
                V::Arr((0..c).map(|k| obj(b, offs, ref_size, be(b, s + k * ref_size, ref_size).unwrap_or(0) as usize, depth + 1)).collect())
            }
            13 => {
                let (c, s) = count();
                V::Dict(
                    (0..c)
                        .map(|k| {
                            let kk = be(b, s + k * ref_size, ref_size).unwrap_or(0) as usize;
                            let vv = be(b, s + (c + k) * ref_size, ref_size).unwrap_or(0) as usize;
                            (obj(b, offs, ref_size, kk, depth + 1), obj(b, offs, ref_size, vv, depth + 1))
                        })
                        .collect(),
                )
            }
            _ => V::Null,
        }
    }
    Some(obj(b, &offs, ref_size, top, 0))
}

/// Déréférence une archive NSKeyedArchiver en valeurs simples.
pub fn unarchive(p: &V) -> V {
    let Some(V::Arr(objs)) = p.get("$objects") else { return p.clone() };
    fn res(x: &V, objs: &[V], depth: u32) -> V {
        if depth > 48 {
            return V::Null;
        }
        match x {
            V::Uid(u) => {
                let Some(o) = objs.get(*u as usize) else { return V::Null };
                match o {
                    V::Str(s) if s == "$null" => V::Null,
                    V::Dict(_) => {
                        if let Some(s) = o.get("NS.string") {
                            return res(s, objs, depth + 1);
                        }
                        if let Some(d) = o.get("NS.bytes") {
                            return d.clone();
                        }
                        if let (Some(V::Arr(keys)), Some(V::Arr(vals))) = (o.get("NS.keys"), o.get("NS.objects")) {
                            return V::Dict(keys.iter().zip(vals).map(|(k, v)| (res(k, objs, depth + 1), res(v, objs, depth + 1))).collect());
                        }
                        if let Some(V::Arr(vals)) = o.get("NS.objects") {
                            return V::Arr(vals.iter().map(|v| res(v, objs, depth + 1)).collect());
                        }
                        let V::Dict(d) = o else { unreachable!() };
                        V::Dict(d.iter().filter(|(k, _)| k.str() != Some("$class")).map(|(k, v)| (k.clone(), res(v, objs, depth + 1))).collect())
                    }
                    other => other.clone(),
                }
            }
            V::Arr(a) => V::Arr(a.iter().map(|v| res(v, objs, depth + 1)).collect()),
            other => other.clone(),
        }
    }
    let top = p.get("$top");
    let root = top.and_then(|t| t.get("root").cloned().or_else(|| match t {
        V::Dict(d) => d.first().map(|(_, v)| v.clone()),
        _ => None,
    }));
    match root {
        Some(r) => res(&r, objs, 0),
        None => V::Null,
    }
}

/// plist XML minimal (brushset.plist peut être en XML).
fn parse_xml_plist(s: &str) -> V {
    // Lecteur très simple : suffisant pour { name, brushes[] }
    let mut out = Vec::new();
    if let Some(i) = s.find("<key>name</key>") {
        if let Some(a) = s[i..].find("<string>") {
            let st = i + a + 8;
            if let Some(e) = s[st..].find("</string>") {
                out.push((V::Str("name".into()), V::Str(s[st..st + e].to_string())));
            }
        }
    }
    if let Some(i) = s.find("<key>brushes</key>") {
        if let Some(a) = s[i..].find("<array>") {
            let st = i + a;
            let en = s[st..].find("</array>").map(|e| st + e).unwrap_or(s.len());
            let mut v = Vec::new();
            let mut k = st;
            while let Some(a) = s[k..en].find("<string>") {
                let b0 = k + a + 8;
                let Some(e) = s[b0..en].find("</string>") else { break };
                v.push(V::Str(s[b0..b0 + e].to_string()));
                k = b0 + e;
            }
            out.push((V::Str("brushes".into()), V::Arr(v)));
        }
    }
    V::Dict(out)
}

fn read_plist_any(bytes: &[u8]) -> V {
    if bytes.starts_with(b"bplist") {
        let p = parse_bplist(bytes).unwrap_or(V::Null);
        if p.get("$objects").is_some() {
            unarchive(&p)
        } else {
            p
        }
    } else {
        parse_xml_plist(&String::from_utf8_lossy(bytes))
    }
}

// ---------------- images ----------------

/// Redimensionne une image RGBA (moyenne des pixels sources).
fn resample(src: &[u8], sw: u32, sh: u32, dw: u32, dh: u32) -> Vec<u8> {
    let mut out = vec![0u8; (dw * dh * 4) as usize];
    let fx = sw as f32 / dw as f32;
    let fy = sh as f32 / dh as f32;
    for y in 0..dh {
        let y0 = (y as f32 * fy) as u32;
        let y1 = (((y + 1) as f32 * fy).ceil() as u32).clamp(y0 + 1, sh);
        for x in 0..dw {
            let x0 = (x as f32 * fx) as u32;
            let x1 = (((x + 1) as f32 * fx).ceil() as u32).clamp(x0 + 1, sw);
            let mut acc = [0u32; 4];
            let mut n = 0u32;
            for yy in y0..y1 {
                for xx in x0..x1 {
                    let i = ((yy * sw + xx) * 4) as usize;
                    for k in 0..4 {
                        acc[k] += src[i + k] as u32;
                    }
                    n += 1;
                }
            }
            let o = ((y * dw + x) * 4) as usize;
            for k in 0..4 {
                out[o + k] = (acc[k] / n.max(1)) as u8;
            }
        }
    }
    out
}

/// Image → masque N×N (blanc = peinture). `invert` : None = détection automatique.
pub fn img_to_mask(png: &[u8], n: u32, invert: Option<bool>, fit: bool) -> Option<Vec<u8>> {
    let (w, h, px) = crate::doc::decode_png(png)?;
    let mut canvas = vec![0u8; (n * n * 4) as usize];
    let (rx0, ry0, rx1, ry1);
    if fit {
        let s = (n as f32 / w as f32).min(n as f32 / h as f32);
        let tw = ((w as f32 * s).round() as u32).clamp(1, n);
        let th = ((h as f32 * s).round() as u32).clamp(1, n);
        let r = resample(&px, w, h, tw, th);
        let ox = (n - tw) / 2;
        let oy = (n - th) / 2;
        for y in 0..th {
            let d = (((oy + y) * n + ox) * 4) as usize;
            let s0 = (y * tw * 4) as usize;
            canvas[d..d + (tw * 4) as usize].copy_from_slice(&r[s0..s0 + (tw * 4) as usize]);
        }
        rx0 = ox;
        ry0 = oy;
        rx1 = ox + tw - 1;
        ry1 = oy + th - 1;
    } else {
        canvas = resample(&px, w, h, n, n);
        rx0 = 0;
        ry0 = 0;
        rx1 = n - 1;
        ry1 = n - 1;
    }
    let lum = |p: &[u8]| p[0] as f32 * 0.299 + p[1] as f32 * 0.587 + p[2] as f32 * 0.114;
    let (mut transparent, mut border, mut bn) = (0usize, 0f32, 0usize);
    for y in 0..n {
        for x in 0..n {
            let i = ((y * n + x) * 4) as usize;
            if canvas[i + 3] < 250 {
                transparent += 1;
            }
            if x < 2 || y < 2 || x >= n - 2 || y >= n - 2 {
                border += if canvas[i + 3] < 128 { 0.0 } else { lum(&canvas[i..i + 4]) };
                bn += 1;
            }
        }
    }
    let auto = invert.is_none();
    let use_alpha = auto && transparent as f32 > (n * n) as f32 * 0.2;
    let white_bg = auto && !use_alpha && border / bn.max(1) as f32 > 140.0;
    let mut m = vec![0u8; (n * n) as usize];
    for i in 0..(n * n) as usize {
        let p = &canvas[i * 4..i * 4 + 4];
        let l = lum(p) * if auto { 1.0 } else { p[3] as f32 / 255.0 };
        let mut a = if use_alpha { p[3] as f32 } else if white_bg { 255.0 - l } else { l };
        if invert == Some(true) {
            a = 255.0 - a;
        }
        m[i] = a.clamp(0.0, 255.0) as u8;
    }
    // Une forme doit être vide sur ses bords, sinon chaque tampon fait un carré : on inverse
    if fit {
        let (mut bsum, mut bc) = (0u64, 0u64);
        for x in rx0..=rx1 {
            for y in [ry0 + 1, ry1.saturating_sub(1)] {
                bsum += m[(y * n + x) as usize] as u64;
                bc += 1;
            }
        }
        for y in ry0..=ry1 {
            for x in [rx0 + 1, rx1.saturating_sub(1)] {
                bsum += m[(y * n + x) as usize] as u64;
                bc += 1;
            }
        }
        if bc > 0 && bsum / bc > 128 {
            for y in ry0..=ry1 {
                for x in rx0..=rx1 {
                    let i = (y * n + x) as usize;
                    m[i] = 255 - m[i];
                }
            }
        }
    }
    Some(m)
}

// ---------------- zip ----------------

pub fn read_zip(data: &[u8]) -> Option<HashMap<String, Vec<u8>>> {
    let mut z = zip::ZipArchive::new(std::io::Cursor::new(data)).ok()?;
    let mut out = HashMap::new();
    for i in 0..z.len() {
        let Ok(mut f) = z.by_index(i) else { continue };
        if f.is_dir() {
            continue;
        }
        let name = f.name().to_string();
        let mut buf = Vec::new();
        if f.read_to_end(&mut buf).is_ok() {
            out.insert(name, buf);
        }
    }
    Some(out)
}

// ---------------- pinceaux ----------------

pub struct ImportedBrush {
    pub brush: Brush,
    pub tip: Option<Vec<u8>>,
    pub grain: Option<Vec<u8>>,
    pub dir_name: String,
}

fn curve_of(v: Option<&V>) -> Option<Vec<[f32; 2]>> {
    let pts = v?.get("points")?;
    let V::Arr(a) = pts else { return None };
    let mut out: Vec<[f32; 2]> = a
        .iter()
        .filter_map(|s| {
            let s = s.str()?;
            let nums: Vec<f32> = s.split(|c: char| !(c.is_ascii_digit() || c == '.' || c == '-')).filter(|x| !x.is_empty()).filter_map(|x| x.parse().ok()).collect();
            if nums.len() >= 2 {
                Some([nums[0], nums[1]])
            } else {
                None
            }
        })
        .collect();
    out.sort_by(|a, b| a[0].partial_cmp(&b[0]).unwrap_or(std::cmp::Ordering::Equal));
    if out.len() < 2 {
        return None;
    }
    let linear = out.len() == 2 && out[0] == [0.0, 0.0] && out[1] == [1.0, 1.0];
    if linear {
        None
    } else {
        Some(out)
    }
}

/// Lit un .brush ou .brushset. Renvoie (nom du set, pinceaux).
pub fn import_brushes(data: &[u8], file_name: &str) -> Result<(Option<String>, Vec<ImportedBrush>), String> {
    let zip = read_zip(data).ok_or("fichier illisible (zip)")?;
    let mut res: Vec<ImportedBrush> = Vec::new();
    let mut names: Vec<&String> = zip.keys().collect();
    names.sort();
    for name in names {
        let Some(dir) = name.strip_suffix("Brush.archive") else { continue };
        let segs: Vec<&str> = dir.split('/').filter(|s| !s.is_empty()).collect();
        if segs.contains(&"Reset") || segs.last().is_some_and(|l| l.starts_with("Sub") && l[3..].chars().all(|c| c.is_ascii_digit()) && l.len() > 3) {
            continue;
        }
        let r = parse_bplist(&zip[name]).map(|p| unarchive(&p)).unwrap_or(V::Null);
        let num = |keys: &[&str], d: f32| -> f32 { keys.iter().find_map(|k| r.get(k).and_then(|v| v.num())).map(|x| x as f32).unwrap_or(d) };
        let find_key = |pred: &dyn Fn(&str) -> bool| r.keys().into_iter().find(|k| pred(&k.to_lowercase())).map(|k| r.get(k).map(|v| v.truthy()).unwrap_or(false));
        let shape_inv = find_key(&|k| k.starts_with("shape") && k.contains("invert"));
        let grain_inv = find_key(&|k| (k.starts_with("grain") || k.starts_with("texture")) && k.contains("invert"));
        let grain_on = num(&["grainDepth"], 1.0) > 0.05 && num(&["textureScale"], 1.0) >= 0.05;
        let tip = zip.get(&format!("{dir}Shape.png")).and_then(|d| img_to_mask(d, 256, shape_inv, true));
        let grain = if grain_on { zip.get(&format!("{dir}Grain.png")).and_then(|d| img_to_mask(d, 256, grain_inv, false)) } else { None };
        let pen = |k: &str| {
            let cap = format!("pencil{}{}", k[..1].to_uppercase(), &k[1..]);
            let v = num(&[&cap], 0.0);
            if v != 0.0 {
                v
            } else {
                num(&[k], 0.0)
            }
        };
        let bundled_grain = grain_on && r.get("bundledGrainPath").and_then(|v| v.str()).is_some_and(|p| !p.to_lowercase().contains("blank"));
        let size_p = num(&["dynamicsPressureSize", "pressureSize"], 0.5).abs().min(1.0);
        let op_p = num(&["dynamicsPressureOpacity", "pressureOpacity"], 0.3).abs().min(1.0);
        let dir_name = dir.trim_end_matches('/').rsplit('/').next().unwrap_or("").to_string();
        let mut b = Brush {
            name: r.get("name").and_then(|v| v.str()).filter(|s| !s.is_empty()).map(|s| s.to_string()).unwrap_or_else(|| if dir_name.is_empty() { "Pinceau importé".into() } else { dir_name.clone() }),
            tip: TipSrc::Builtin(crate::brush::Shape::Hard),
            grain: if grain.is_none() && bundled_grain { Some(GrainSrc::Noise) } else { None },
            max_size: (num(&["maxSize"], 0.3) * 530.0).clamp(4.0, 1600.0),
            size_curve: curve_of(r.get("dynamicsPressureSizeCurve")),
            op_curve: curve_of(r.get("dynamicsPressureOpacityCurve")),
            speed_size: num(&["dynamicsSpeedSize"], 0.0).clamp(-1.0, 1.0),
            op_jitter: num(&["dynamicsJitterOpacity"], 0.0).min(1.0),
            def_size: num(&["paintSize"], 0.5).clamp(0.01, 1.0),
            min_size: num(&["minSize"], 0.0).clamp(0.0, 1.0),
            presets: match r.get("savedPaintSizes") {
                Some(V::Arr(a)) => a.iter().filter_map(|x| x.num()).map(|x| x as f32).collect(),
                _ => vec![],
            },
            taper_start: pen("taperStartLength"),
            taper_end: pen("taperEndLength"),
            taper_size: pen("taperSize").max(0.0),
            spacing: num(&["plotSpacing", "spacing"], 0.08).clamp(0.02, 1.5),
            flow: num(&["maxOpacity", "paintOpacity", "plotFlow", "flow"], 0.85).clamp(0.05, 1.0),
            size_p,
            op_p,
            scatter: (num(&["plotJitter", "jitter"], 0.0) * 0.6).clamp(0.0, 1.0),
            count: r.get("shapeCount").and_then(|v| v.num()).map(|c| ((c * 16.0).round() as u32).clamp(1, 8)).unwrap_or(1),
            rot_rand: r.get("shapeRandomise").or(r.get("shapeRandomize")).is_some_and(|v| v.truthy()) || num(&["shapeScatter"], 0.0) > 0.1,
            streamline: num(&["plotSmoothing", "streamLine", "streamline"], 0.3).clamp(0.0, 0.9),
            ..Default::default()
        };
        b.grain_scale = if grain.is_some() { num(&["textureScale", "grainScale"], 1.0).clamp(0.12, 4.0) } else { (num(&["textureScale"], 0.2) * 6.3).clamp(0.7, 3.0) };
        // Forme intégrée à Procreate (absente du fichier) qui suit la direction : pointe plate
        if tip.is_none() && r.get("bundledShapePath").and_then(|v| v.str()).is_some() && num(&["shapeRotation"], 0.0) > 0.3 {
            b.follow = true;
            b.squash = 0.42;
        }
        if b.op_p >= 0.5 {
            b.flow = b.flow.min(0.14);
        } else if r.get("renderingMaxTransfer").is_some_and(|v| v.truthy()) && b.op_p > 0.05 {
            b.op_map = true;
        }
        res.push(ImportedBrush { brush: b, tip, grain, dir_name });
    }
    if res.is_empty() {
        return Err("aucun pinceau trouvé".into());
    }
    // nom et ordre du set
    let mut set_name = None;
    if let Some((_, man)) = zip.iter().find(|(k, _)| k.to_lowercase().ends_with("brushset.plist")) {
        let m = read_plist_any(man);
        set_name = m.get("name").and_then(|v| v.str()).map(|s| s.to_string());
        if let Some(V::Arr(order)) = m.get("brushes") {
            let order: Vec<String> = order.iter().filter_map(|v| v.str().map(|s| s.to_string())).collect();
            res.sort_by_key(|b| order.iter().position(|o| *o == b.dir_name).unwrap_or(usize::MAX));
        }
    }
    if set_name.is_none() {
        let lower = file_name.to_lowercase();
        if lower.ends_with(".brushset") {
            set_name = Some(file_name[..file_name.len() - 9].to_string());
        }
    }
    Ok((set_name, res))
}

// ---------------- palettes ----------------

pub fn import_swatches(data: &[u8], file_name: &str) -> Result<Vec<(String, Vec<[f32; 3]>)>, String> {
    let zip = read_zip(data).ok_or("fichier illisible (zip)")?;
    let json = zip.iter().find(|(k, _)| k.ends_with(".json")).map(|(_, v)| v).ok_or("Swatches.json introuvable")?;
    let v: serde_json::Value = serde_json::from_slice(json).map_err(|e| e.to_string())?;
    let list = if v.is_array() { v.as_array().unwrap().clone() } else { vec![v] };
    let base = file_name.trim_end_matches(".swatches").to_string();
    Ok(list
        .iter()
        .map(|p| {
            let name = p["name"].as_str().map(|s| s.to_string()).unwrap_or_else(|| base.clone());
            let cols = p["swatches"]
                .as_array()
                .map(|a| {
                    a.iter()
                        .filter(|s| !s.is_null())
                        .map(|s| hsv(s["hue"].as_f64().unwrap_or(0.0) as f32, s["saturation"].as_f64().unwrap_or(0.0) as f32, s["brightness"].as_f64().unwrap_or(0.0) as f32))
                        .collect()
                })
                .unwrap_or_default();
            (name, cols)
        })
        .collect())
}

pub fn hsv(h: f32, s: f32, v: f32) -> [f32; 3] {
    let h = (h.rem_euclid(1.0)) * 6.0;
    let c = v * s;
    let x = c * (1.0 - ((h % 2.0) - 1.0).abs());
    let m = v - c;
    let (r, g, b) = match h as u32 {
        0 => (c, x, 0.0),
        1 => (x, c, 0.0),
        2 => (0.0, c, x),
        3 => (0.0, x, c),
        4 => (x, 0.0, c),
        _ => (c, 0.0, x),
    };
    [r + m, g + m, b + m]
}

pub fn rgb_to_hsv(c: [f32; 3]) -> [f32; 3] {
    let (r, g, b) = (c[0], c[1], c[2]);
    let mx = r.max(g).max(b);
    let mn = r.min(g).min(b);
    let d = mx - mn;
    let h = if d < 1e-6 {
        0.0
    } else if mx == r {
        ((g - b) / d).rem_euclid(6.0) / 6.0
    } else if mx == g {
        ((b - r) / d + 2.0) / 6.0
    } else {
        ((r - g) / d + 4.0) / 6.0
    };
    [h, if mx > 0.0 { d / mx } else { 0.0 }, mx]
}

// ---------------- dessins .procreate ----------------

fn lzo1x(src: &[u8], out_len: usize) -> Option<Vec<u8>> {
    let mut out = vec![0u8; out_len];
    let (mut ip, mut op, mut t) = (0usize, 0usize, 0usize);
    let mut mp: usize;
    let g = |i: usize| -> Option<usize> { src.get(i).map(|&x| x as usize) };
    macro_rules! lit {
        ($n:expr) => {{
            let n = $n;
            out.get_mut(op..op + n)?.copy_from_slice(src.get(ip..ip + n)?);
            op += n;
            ip += n;
        }};
    }
    macro_rules! mat {
        ($n:expr) => {{
            let n = $n;
            if mp >= op || op + n > out_len {
                return None;
            }
            for k in 0..n {
                out[op + k] = out[mp + k];
            }
            op += n;
        }};
    }
    let mut state = 0u8;
    if g(0)? > 17 {
        t = g(ip)? - 17;
        ip += 1;
        if t < 4 {
            state = 3;
        } else {
            lit!(t);
            state = 1;
        }
    }
    for _ in 0..100_000_000u64 {
        if state == 0 {
            t = g(ip)?;
            ip += 1;
            if t >= 16 {
                state = 2;
                continue;
            }
            if t == 0 {
                while g(ip)? == 0 {
                    t += 255;
                    ip += 1;
                }
                t += 15 + g(ip)?;
                ip += 1;
            }
            lit!(t + 3);
            state = 1;
            continue;
        }
        if state == 1 {
            t = g(ip)?;
            ip += 1;
            if t >= 16 {
                state = 2;
                continue;
            }
            mp = op.checked_sub(0x801 + (t >> 2) + (g(ip)? << 2))?;
            ip += 1;
            mat!(3);
        } else if state == 3 {
            lit!(t);
            t = g(ip)?;
            ip += 1;
            state = 2;
            continue;
        } else if t >= 64 {
            mp = op.checked_sub(1 + ((t >> 2) & 7) + (g(ip)? << 3))?;
            ip += 1;
            t = (t >> 5) - 1;
            mat!(t + 2);
        } else if t >= 32 {
            t &= 31;
            if t == 0 {
                while g(ip)? == 0 {
                    t += 255;
                    ip += 1;
                }
                t += 31 + g(ip)?;
                ip += 1;
            }
            mp = op.checked_sub(1 + ((g(ip)? >> 2) + (g(ip + 1)? << 6)))?;
            ip += 2;
            mat!(t + 2);
        } else if t >= 16 {
            let mut m = op as isize - (((t & 8) << 11) as isize);
            t &= 7;
            if t == 0 {
                while g(ip)? == 0 {
                    t += 255;
                    ip += 1;
                }
                t += 7 + g(ip)?;
                ip += 1;
            }
            m -= ((g(ip)? >> 2) + (g(ip + 1)? << 6)) as isize;
            ip += 2;
            if m == op as isize {
                break;
            }
            m -= 0x4000;
            if m < 0 {
                return None;
            }
            mp = m as usize;
            mat!(t + 2);
        } else {
            mp = op.checked_sub(1 + (t >> 2) + (g(ip)? << 2))?;
            ip += 1;
            mat!(2);
        }
        t = g(ip.checked_sub(2)?)? & 3;
        if t == 0 {
            state = 0;
            continue;
        }
        state = 3;
    }
    Some(out)
}

fn lz4_block(src: &[u8], out: &mut [u8], mut op: usize) -> Option<usize> {
    let mut ip = 0;
    while ip < src.len() {
        let tok = src[ip] as usize;
        ip += 1;
        let mut lit = tok >> 4;
        if lit == 15 {
            loop {
                let b = *src.get(ip)? as usize;
                ip += 1;
                lit += b;
                if b != 255 {
                    break;
                }
            }
        }
        out.get_mut(op..op + lit)?.copy_from_slice(src.get(ip..ip + lit)?);
        op += lit;
        ip += lit;
        if ip >= src.len() {
            break;
        }
        let off = *src.get(ip)? as usize | ((*src.get(ip + 1)? as usize) << 8);
        ip += 2;
        let mut ml = tok & 15;
        if ml == 15 {
            loop {
                let b = *src.get(ip)? as usize;
                ip += 1;
                ml += b;
                if b != 255 {
                    break;
                }
            }
        }
        ml += 4;
        if off == 0 || off > op || op + ml > out.len() {
            return None;
        }
        for k in 0..ml {
            out[op + k] = out[op - off + k];
        }
        op += ml;
    }
    Some(op)
}

fn lz4(src: &[u8], out_len: usize) -> Option<Vec<u8>> {
    let mut out = vec![0u8; out_len];
    if src.len() >= 4 && &src[..3] == b"bv4" {
        let (mut ip, mut op) = (0usize, 0usize);
        while ip + 8 <= src.len() {
            let tag = &src[ip..ip + 4];
            if tag == b"bv4$" {
                break;
            }
            let dsz = u32::from_le_bytes(src[ip + 4..ip + 8].try_into().ok()?) as usize;
            if tag == b"bv41" {
                let csz = u32::from_le_bytes(src.get(ip + 8..ip + 12)?.try_into().ok()?) as usize;
                lz4_block(src.get(ip + 12..ip + 12 + csz)?, &mut out, op)?;
                op += dsz;
                ip += 12 + csz;
            } else if tag == b"bv4-" {
                out.get_mut(op..op + dsz)?.copy_from_slice(src.get(ip + 8..ip + 8 + dsz)?);
                op += dsz;
                ip += 8 + dsz;
            } else {
                break;
            }
        }
        return Some(out);
    }
    lz4_block(src, &mut out, 0)?;
    Some(out)
}

pub fn decode_chunk_pub(raw: &[u8], len: usize) -> Option<Vec<u8>> {
    decode_chunk(raw, len)
}

fn decode_chunk(raw: &[u8], len: usize) -> Option<Vec<u8>> {
    if raw.len() == len {
        return Some(raw.to_vec());
    }
    if raw.starts_with(b"bv4") {
        return lz4(raw, len);
    }
    lzo1x(raw, len).or_else(|| lz4(raw, len))
}

pub struct ImportedLayer {
    pub name: String,
    pub px: Vec<u8>, // RGBA prémultiplié, w*h
    pub opacity: f32,
    pub visible: bool,
    pub mode: u32,
    pub lock_alpha: bool,
}

pub struct ImportedDoc {
    pub name: String,
    pub w: u32,
    pub h: u32,
    pub bg: [f32; 3],
    pub bg_visible: bool,
    pub layers: Vec<ImportedLayer>,
}

fn pblend(m: i64) -> u32 {
    match m {
        1 => 1,
        2 => 2,
        4 => 5,
        5 => 11,
        6 => 10,
        9 => 6,
        10 => 7,
        11 => 3,
        12 => 8,
        13 => 16,
        14 => 17,
        15 => 14,
        16 => 15,
        17 => 9,
        18 => 4,
        _ => 0,
    }
}

pub fn import_procreate(data: &[u8], file_name: &str) -> Result<ImportedDoc, String> {
    let zip = read_zip(data).ok_or("fichier illisible (zip)")?;
    let arch = zip.get("Document.archive").ok_or("Document.archive introuvable")?;
    let root = unarchive(&parse_bplist(arch).ok_or("archive illisible")?);
    let size = root.get("size").and_then(|v| v.str()).unwrap_or("");
    let nums: Vec<f32> = size.split(|c: char| !(c.is_ascii_digit() || c == '.')).filter(|x| !x.is_empty()).filter_map(|x| x.parse().ok()).collect();
    if nums.len() < 2 {
        return Err("taille du dessin inconnue".into());
    }
    let (w, h) = (nums[0].round() as u32, nums[1].round() as u32);
    let ts = root.get("tileSize").and_then(|v| v.num()).unwrap_or(256.0) as u32;
    let mut bg = [1.0, 1.0, 1.0];
    if let Some(V::Data(d)) = root.get("backgroundColor") {
        if d.len() >= 12 {
            for (k, c) in bg.iter_mut().enumerate() {
                *c = f32::from_le_bytes(d[k * 4..k * 4 + 4].try_into().unwrap()).clamp(0.0, 1.0);
            }
        }
    }
    let mut flat = Vec::new();
    fn walk<'a>(a: &'a V, out: &mut Vec<&'a V>) {
        if let V::Arr(v) = a {
            for l in v {
                match l.get("children") {
                    Some(V::Arr(c)) if !c.is_empty() => walk(l.get("children").unwrap(), out),
                    _ => out.push(l),
                }
            }
        }
    }
    if let Some(l) = root.get("layers") {
        walk(l, &mut flat);
    }
    let cols = w.div_ceil(ts);
    let rows = h.div_ceil(ts);
    let mut layers = Vec::new();
    for l in flat {
        let Some(uuid) = l.get("UUID").and_then(|v| v.str()) else { continue };
        let mut px = vec![0u8; (w * h * 4) as usize];
        let mut any = false;
        for (name, raw) in zip.iter() {
            let Some(rest) = name.strip_prefix(&format!("{uuid}/")) else { continue };
            if !(rest.ends_with(".chunk") || rest.ends_with(".lz4")) {
                continue;
            }
            let stem = rest.split('.').next().unwrap_or("");
            let mut it = stem.split('~');
            let (Some(c), Some(r)) = (it.next().and_then(|x| x.parse::<u32>().ok()), it.next().and_then(|x| x.parse::<u32>().ok())) else { continue };
            let tw = if c == cols - 1 { w - c * ts } else { ts };
            let th = if r == rows - 1 { h - r * ts } else { ts };
            if tw == 0 || th == 0 || c >= cols || r >= rows {
                continue;
            }
            let Some(tile) = decode_chunk(raw, (tw * th * 4) as usize) else { continue };
            for y in 0..th {
                let d = (((r * ts + y) * w + c * ts) * 4) as usize;
                let s = (y * tw * 4) as usize;
                px[d..d + (tw * 4) as usize].copy_from_slice(&tile[s..s + (tw * 4) as usize]);
            }
            any = true;
        }
        if !any && l.get("name").is_none() {
            continue;
        }
        let mode = pblend(l.get("extendedBlend").and_then(|v| v.num()).or(l.get("blend").and_then(|v| v.num())).unwrap_or(0.0) as i64);
        layers.push(ImportedLayer {
            name: l.get("name").and_then(|v| v.str()).unwrap_or("Calque").to_string(),
            px,
            opacity: l.get("opacity").and_then(|v| v.num()).unwrap_or(1.0) as f32,
            visible: !l.get("hidden").is_some_and(|v| v.truthy()),
            mode,
            lock_alpha: l.get("preserve").is_some_and(|v| v.truthy()),
        });
    }
    layers.reverse(); // Procreate liste le calque du haut en premier
    let mut doc = ImportedDoc {
        name: root.get("name").and_then(|v| v.str()).map(|s| s.to_string()).unwrap_or_else(|| file_name.trim_end_matches(".procreate").to_string()),
        w,
        h,
        bg,
        bg_visible: !root.get("backgroundHidden").is_some_and(|v| v.truthy()),
        layers,
    };
    if let Some(t) = zip.get("QuickLook/Thumbnail.png") {
        fix_orientation(&mut doc, t);
    }
    Ok(doc)
}

/// Compare avec la vignette QuickLook pour trouver le bon sens (les tuiles sont stockées tournées).
fn fix_orientation(d: &mut ImportedDoc, thumb_png: &[u8]) {
    let Some((tw, th, tpx)) = crate::doc::decode_png(thumb_png) else { return };
    const S: usize = 48;
    let bg = if d.bg_visible { d.bg } else { [1.0; 3] };
    // composite simplifié (normal) à basse résolution, dans le repère source
    let mut comp = vec![[0f32; 3]; S * S];
    for y in 0..S {
        for x in 0..S {
            comp[y * S + x] = [bg[0] * 255.0, bg[1] * 255.0, bg[2] * 255.0];
        }
    }
    let sample_src = |u: f32, v: f32| -> [f32; 3] {
        let mut c = [bg[0] * 255.0, bg[1] * 255.0, bg[2] * 255.0];
        let sx = ((u * d.w as f32) as u32).min(d.w - 1);
        let sy = ((v * d.h as f32) as u32).min(d.h - 1);
        for l in d.layers.iter().filter(|l| l.visible) {
            let i = ((sy * d.w + sx) * 4) as usize;
            let a = l.px[i + 3] as f32 / 255.0 * l.opacity;
            for k in 0..3 {
                c[k] = l.px[i + k] as f32 * l.opacity + c[k] * (1.0 - a);
            }
        }
        c
    };
    let refp = |x: usize, y: usize| -> [f32; 3] {
        let sx = ((x as f32 + 0.5) / S as f32 * tw as f32) as u32;
        let sy = ((y as f32 + 0.5) / S as f32 * th as f32) as u32;
        let i = ((sy.min(th - 1) * tw + sx.min(tw - 1)) * 4) as usize;
        let a = tpx[i + 3] as f32 / 255.0;
        [tpx[i] as f32 * a + 255.0 * (1.0 - a), tpx[i + 1] as f32 * a + 255.0 * (1.0 - a), tpx[i + 2] as f32 * a + 255.0 * (1.0 - a)]
    };
    // transformations : (u,v) de la vignette -> (u,v) source
    let cands: [(&str, fn(f32, f32) -> (f32, f32)); 8] = [
        ("id", |u, v| (u, v)),
        ("fv", |u, v| (u, 1.0 - v)),
        ("fh", |u, v| (1.0 - u, v)),
        ("r180", |u, v| (1.0 - u, 1.0 - v)),
        ("t", |u, v| (v, u)),
        ("r90", |u, v| (v, 1.0 - u)),
        ("r270", |u, v| (1.0 - v, u)),
        ("at", |u, v| (1.0 - v, 1.0 - u)),
    ];
    let mut best = (0usize, false, f32::MAX);
    for (ci, (_, f)) in cands.iter().enumerate() {
        for swap in [false, true] {
            let mut err = 0.0;
            for y in 0..S {
                for x in 0..S {
                    let (u, v) = f((x as f32 + 0.5) / S as f32, (y as f32 + 0.5) / S as f32);
                    let mut s = sample_src(u, v);
                    if swap {
                        s.swap(0, 2);
                    }
                    let r = refp(x, y);
                    err += (s[0] - r[0]).abs() + (s[1] - r[1]).abs() + (s[2] - r[2]).abs();
                }
            }
            if err < best.2 {
                best = (ci, swap, err);
            }
        }
    }
    let _ = comp;
    let (ci, swap, _) = best;
    if ci == 0 && !swap {
        return;
    }
    let f = cands[ci].1;
    let rotated = ci >= 4;
    let (nw, nh) = if rotated { (d.h, d.w) } else { (d.w, d.h) };
    for l in d.layers.iter_mut() {
        let mut out = vec![0u8; (nw * nh * 4) as usize];
        for y in 0..nh {
            for x in 0..nw {
                let (u, v) = f((x as f32 + 0.5) / nw as f32, (y as f32 + 0.5) / nh as f32);
                let sx = ((u * d.w as f32) as u32).min(d.w - 1);
                let sy = ((v * d.h as f32) as u32).min(d.h - 1);
                let si = ((sy * d.w + sx) * 4) as usize;
                let di = ((y * nw + x) * 4) as usize;
                out[di..di + 4].copy_from_slice(&l.px[si..si + 4]);
                if swap {
                    out.swap(di, di + 2);
                }
            }
        }
        l.px = out;
    }
    d.w = nw;
    d.h = nh;
}
