//! Moteur de rendu sur la carte graphique : calques, tampons de pinceau, composition, annulation.

use bytemuck::{Pod, Zeroable};
use wgpu::util::DeviceExt;

pub const LAYER_FMT: wgpu::TextureFormat = wgpu::TextureFormat::Rgba8Unorm;
pub const VIEW_SRGB: wgpu::TextureFormat = wgpu::TextureFormat::Rgba8UnormSrgb;
const STROKE_FMT: wgpu::TextureFormat = wgpu::TextureFormat::R8Unorm;

#[repr(C)]
#[derive(Clone, Copy, Pod, Zeroable, Debug)]
pub struct Dab {
    pub pos: [f32; 2],
    pub size: f32,
    pub angle: f32,
    pub alpha: f32,
    /// Rapport hauteur / largeur de la forme (1 = normale)
    pub aspect: f32,
}

#[repr(C)]
#[derive(Clone, Copy, Pod, Zeroable)]
struct StampGlobals {
    canvas: [f32; 2],
    pad: [f32; 2],
}

#[repr(C)]
#[derive(Clone, Copy, Pod, Zeroable, Default)]
struct CompU {
    color: [f32; 4],
    opacity: f32,
    mode: u32,
    stroke_mode: u32,
    stroke_opacity: f32,
    lock_alpha: u32,
    has_sel: u32,
    pad: [u32; 2],
}

/// Texture d'un calque (le contenu en pixels vit sur la carte graphique).
pub struct GpuLayer {
    pub tex: wgpu::Texture,
    pub view: wgpu::TextureView,
    /// Vue sRGB pour l'affichage dans l'interface (vignettes)
    pub srgb_view: wgpu::TextureView,
}

pub struct Tip {
    bind: wgpu::BindGroup,
    max_blend: bool,
}

#[repr(C)]
#[derive(Clone, Copy, Pod, Zeroable)]
struct BrushU {
    grain_scale: f32,
    grain_on: f32,
    pad: [f32; 2],
}

/// État du trait en cours, appliqué au calque actif pendant la composition.
#[derive(Clone, Copy)]
pub struct StrokeState {
    pub color: [f32; 3],
    pub opacity: f32,
    pub erase: bool,
}

/// Description d'un calque pour la composition.
#[derive(Clone, Copy)]
pub struct LayerDraw {
    pub index: usize,
    pub visible: bool,
    pub opacity: f32,
    pub mode: u32,
    pub lock_alpha: bool,
}

pub struct UndoRegion {
    pub layer: usize,
    pub x: u32,
    pub y: u32,
    pub w: u32,
    pub h: u32,
    pub tex: wgpu::Texture,
}

pub struct Engine {
    pub device: wgpu::Device,
    pub queue: wgpu::Queue,
    pub w: u32,
    pub h: u32,
    pub layers: Vec<GpuLayer>,
    _stroke: wgpu::Texture,
    stroke_view: wgpu::TextureView,
    ping: [GpuLayer; 2],
    below: GpuLayer,
    pub display: GpuLayer,
    tmp: GpuLayer,
    stamp_pipe: wgpu::RenderPipeline,
    stamp_max_pipe: wgpu::RenderPipeline,
    grain_sampler: wgpu::Sampler,
    stamp_globals: wgpu::Buffer,
    stamp_bgl: wgpu::BindGroupLayout,
    tip_sampler: wgpu::Sampler,
    comp_pipe: wgpu::RenderPipeline,
    commit_pipe: wgpu::RenderPipeline,
    present_pipe: wgpu::RenderPipeline,
    selmix_pipe: wgpu::RenderPipeline,
    /// sélection : masque (R8) à la taille de la toile
    pub sel: Option<(wgpu::Texture, wgpu::TextureView)>,
    sel_none: wgpu::TextureView,
    fx_pipe: wgpu::RenderPipeline,
    fx_bgl: wgpu::BindGroupLayout,
    /// copie du calque avant un ajustement (aperçu en direct, annulable)
    fx_backup: Option<(usize, wgpu::Texture, wgpu::TextureView)>,
    /// matrice inverse (destination -> source) pour la transformation
    pub fx_matrix: [f32; 6],
    comp_bgl: wgpu::BindGroupLayout,
    /// Composition des calques sous le calque actif (mise en cache)
    below_valid: Option<(usize, u64)>,
    pub stroke_bbox: Option<[f32; 4]>,
}

// Les vues sRGB (pour les vignettes) ne sont pas disponibles partout (OpenGL ES)
static SRGB_VIEWS: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);

fn make_layer_tex(device: &wgpu::Device, w: u32, h: u32, label: &str) -> GpuLayer {
    let srgb_ok = SRGB_VIEWS.load(std::sync::atomic::Ordering::Relaxed);
    let tex = device.create_texture(&wgpu::TextureDescriptor {
        label: Some(label),
        size: wgpu::Extent3d { width: w, height: h, depth_or_array_layers: 1 },
        mip_level_count: 1,
        sample_count: 1,
        dimension: wgpu::TextureDimension::D2,
        format: LAYER_FMT,
        usage: wgpu::TextureUsages::RENDER_ATTACHMENT
            | wgpu::TextureUsages::TEXTURE_BINDING
            | wgpu::TextureUsages::COPY_SRC
            | wgpu::TextureUsages::COPY_DST,
        view_formats: if srgb_ok { &[VIEW_SRGB] } else { &[] },
    });
    let view = tex.create_view(&wgpu::TextureViewDescriptor::default());
    let srgb_view = if srgb_ok { tex.create_view(&wgpu::TextureViewDescriptor { format: Some(VIEW_SRGB), ..Default::default() }) } else { view.clone() };
    GpuLayer { tex, view, srgb_view }
}

/// Texture d'affichage en sRGB (lue par l'interface)
fn make_display_tex(device: &wgpu::Device, w: u32, h: u32) -> GpuLayer {
    let tex = device.create_texture(&wgpu::TextureDescriptor {
        label: Some("display"),
        size: wgpu::Extent3d { width: w, height: h, depth_or_array_layers: 1 },
        mip_level_count: 1,
        sample_count: 1,
        dimension: wgpu::TextureDimension::D2,
        format: VIEW_SRGB,
        usage: wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_SRC,
        view_formats: &[],
    });
    let view = tex.create_view(&wgpu::TextureViewDescriptor::default());
    GpuLayer { srgb_view: view.clone(), view, tex }
}

fn clear_pass(enc: &mut wgpu::CommandEncoder, view: &wgpu::TextureView, c: wgpu::Color) {
    enc.begin_render_pass(&wgpu::RenderPassDescriptor {
        label: Some("clear"),
        color_attachments: &[Some(wgpu::RenderPassColorAttachment {
            view,
            depth_slice: None,
            resolve_target: None,
            ops: wgpu::Operations { load: wgpu::LoadOp::Clear(c), store: wgpu::StoreOp::Store },
        })],
        depth_stencil_attachment: None,
        timestamp_writes: None,
        occlusion_query_set: None,
        multiview_mask: None,
    });
}

impl Engine {
    pub fn new(device: wgpu::Device, queue: wgpu::Queue, w: u32, h: u32, srgb_views: bool) -> Self {
        SRGB_VIEWS.store(srgb_views, std::sync::atomic::Ordering::Relaxed);
        let stroke = device.create_texture(&wgpu::TextureDescriptor {
            label: Some("stroke"),
            size: wgpu::Extent3d { width: w, height: h, depth_or_array_layers: 1 },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: STROKE_FMT,
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::TEXTURE_BINDING,
            view_formats: &[],
        });
        let stroke_view = stroke.create_view(&Default::default());

        // --- tampons ---
        let stamp_mod = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("stamp"),
            source: wgpu::ShaderSource::Wgsl(include_str!("shaders/stamp.wgsl").into()),
        });
        let stamp_bgl = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("stamp_bgl"),
            entries: &[
                wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::VERTEX | wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Buffer { ty: wgpu::BufferBindingType::Uniform, has_dynamic_offset: false, min_binding_size: None },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 3,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Texture {
                        sample_type: wgpu::TextureSampleType::Float { filterable: true },
                        view_dimension: wgpu::TextureViewDimension::D2,
                        multisampled: false,
                    },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 4,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 5,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Buffer { ty: wgpu::BufferBindingType::Uniform, has_dynamic_offset: false, min_binding_size: None },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 1,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Texture {
                        sample_type: wgpu::TextureSampleType::Float { filterable: true },
                        view_dimension: wgpu::TextureViewDimension::D2,
                        multisampled: false,
                    },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 2,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                    count: None,
                },
            ],
        });
        let stamp_pl = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("stamp_pl"),
            bind_group_layouts: &[Some(&stamp_bgl)],
            immediate_size: 0,
        });
        let mk_stamp = |op: wgpu::BlendOperation| {
            device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
                label: Some("stamp"),
                layout: Some(&stamp_pl),
                vertex: wgpu::VertexState {
                    module: &stamp_mod,
                    entry_point: Some("vs"),
                    buffers: &[Some(wgpu::VertexBufferLayout {
                        array_stride: std::mem::size_of::<Dab>() as u64,
                        step_mode: wgpu::VertexStepMode::Instance,
                        attributes: &wgpu::vertex_attr_array![0 => Float32x2, 1 => Float32, 2 => Float32, 3 => Float32, 4 => Float32],
                    })],
                    compilation_options: Default::default(),
                },
                primitive: wgpu::PrimitiveState::default(),
                depth_stencil: None,
                multisample: wgpu::MultisampleState::default(),
                fragment: Some(wgpu::FragmentState {
                    module: &stamp_mod,
                    entry_point: Some("fs"),
                    targets: &[Some(wgpu::ColorTargetState {
                        format: STROKE_FMT,
                        blend: Some(wgpu::BlendState {
                            color: if op == wgpu::BlendOperation::Max {
                                wgpu::BlendComponent { src_factor: wgpu::BlendFactor::One, dst_factor: wgpu::BlendFactor::One, operation: op }
                            } else {
                                wgpu::BlendComponent { src_factor: wgpu::BlendFactor::One, dst_factor: wgpu::BlendFactor::OneMinusSrc, operation: op }
                            },
                            alpha: wgpu::BlendComponent::OVER,
                        }),
                        write_mask: wgpu::ColorWrites::ALL,
                    })],
                    compilation_options: Default::default(),
                }),
                multiview_mask: None,
                cache: None,
            })
        };
        let stamp_pipe = mk_stamp(wgpu::BlendOperation::Add);
        let stamp_max_pipe = mk_stamp(wgpu::BlendOperation::Max);
        let grain_sampler = device.create_sampler(&wgpu::SamplerDescriptor {
            label: Some("grain"),
            address_mode_u: wgpu::AddressMode::Repeat,
            address_mode_v: wgpu::AddressMode::Repeat,
            mag_filter: wgpu::FilterMode::Linear,
            min_filter: wgpu::FilterMode::Linear,
            mipmap_filter: wgpu::MipmapFilterMode::Linear,
            ..Default::default()
        });
        let stamp_globals = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("stamp_globals"),
            contents: bytemuck::bytes_of(&StampGlobals { canvas: [w as f32, h as f32], pad: [0.0; 2] }),
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
        });
        let tip_sampler = device.create_sampler(&wgpu::SamplerDescriptor {
            label: Some("tip"),
            address_mode_u: wgpu::AddressMode::ClampToEdge,
            address_mode_v: wgpu::AddressMode::ClampToEdge,
            mag_filter: wgpu::FilterMode::Linear,
            min_filter: wgpu::FilterMode::Linear,
            mipmap_filter: wgpu::MipmapFilterMode::Linear,
            ..Default::default()
        });

        // --- composition ---
        let comp_mod = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("composite"),
            source: wgpu::ShaderSource::Wgsl(include_str!("shaders/composite.wgsl").into()),
        });
        let tex_entry = |binding: u32| wgpu::BindGroupLayoutEntry {
            binding,
            visibility: wgpu::ShaderStages::FRAGMENT,
            ty: wgpu::BindingType::Texture {
                sample_type: wgpu::TextureSampleType::Float { filterable: false },
                view_dimension: wgpu::TextureViewDimension::D2,
                multisampled: false,
            },
            count: None,
        };
        let comp_bgl = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("comp_bgl"),
            entries: &[
                wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Buffer { ty: wgpu::BufferBindingType::Uniform, has_dynamic_offset: false, min_binding_size: None },
                    count: None,
                },
                tex_entry(1),
                tex_entry(2),
                tex_entry(3),
                tex_entry(4),
            ],
        });
        let comp_pl = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("comp_pl"),
            bind_group_layouts: &[Some(&comp_bgl)],
            immediate_size: 0,
        });
        let mk_pipe = |entry: &str, fmt: wgpu::TextureFormat| {
            device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
                label: Some(entry),
                layout: Some(&comp_pl),
                vertex: wgpu::VertexState { module: &comp_mod, entry_point: Some("vs"), buffers: &[], compilation_options: Default::default() },
                primitive: wgpu::PrimitiveState::default(),
                depth_stencil: None,
                multisample: wgpu::MultisampleState::default(),
                fragment: Some(wgpu::FragmentState {
                    module: &comp_mod,
                    entry_point: Some(entry),
                    targets: &[Some(wgpu::ColorTargetState { format: fmt, blend: None, write_mask: wgpu::ColorWrites::ALL })],
                    compilation_options: Default::default(),
                }),
                multiview_mask: None,
                cache: None,
            })
        };
        let comp_pipe = mk_pipe("fs_composite", LAYER_FMT);
        let commit_pipe = mk_pipe("fs_commit", LAYER_FMT);
        let present_pipe = mk_pipe("fs_present", VIEW_SRGB);
        let selmix_pipe = mk_pipe("fs_selmix", LAYER_FMT);

        // --- ajustements ---
        let fx_mod = device.create_shader_module(wgpu::ShaderModuleDescriptor { label: Some("fx"), source: wgpu::ShaderSource::Wgsl(include_str!("shaders/fx.wgsl").into()) });
        let fx_bgl = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("fx_bgl"),
            entries: &[
                wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Buffer { ty: wgpu::BufferBindingType::Uniform, has_dynamic_offset: false, min_binding_size: None },
                    count: None,
                },
                tex_entry(1),
            ],
        });
        let fx_pl = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor { label: Some("fx_pl"), bind_group_layouts: &[Some(&fx_bgl)], immediate_size: 0 });
        let fx_pipe = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("fx"),
            layout: Some(&fx_pl),
            vertex: wgpu::VertexState { module: &fx_mod, entry_point: Some("vs"), buffers: &[], compilation_options: Default::default() },
            primitive: wgpu::PrimitiveState::default(),
            depth_stencil: None,
            multisample: wgpu::MultisampleState::default(),
            fragment: Some(wgpu::FragmentState {
                module: &fx_mod,
                entry_point: Some("fs"),
                targets: &[Some(wgpu::ColorTargetState { format: LAYER_FMT, blend: None, write_mask: wgpu::ColorWrites::ALL })],
                compilation_options: Default::default(),
            }),
            multiview_mask: None,
            cache: None,
        });

        let sel_none = {
            let t = device.create_texture(&wgpu::TextureDescriptor {
                label: Some("sel_none"),
                size: wgpu::Extent3d { width: 1, height: 1, depth_or_array_layers: 1 },
                mip_level_count: 1,
                sample_count: 1,
                dimension: wgpu::TextureDimension::D2,
                format: wgpu::TextureFormat::R8Unorm,
                usage: wgpu::TextureUsages::TEXTURE_BINDING,
                view_formats: &[],
            });
            t.create_view(&Default::default())
        };
        let ping = [make_layer_tex(&device, w, h, "ping0"), make_layer_tex(&device, w, h, "ping1")];
        let below = make_layer_tex(&device, w, h, "below");
        let display = make_display_tex(&device, w, h);
        let tmp = make_layer_tex(&device, w, h, "tmp");

        let e = Engine {
            device,
            queue,
            w,
            h,
            layers: Vec::new(),
            _stroke: stroke,
            stroke_view,
            ping,
            below,
            display,
            tmp,
            stamp_pipe,
            stamp_max_pipe,
            grain_sampler,
            stamp_globals,
            stamp_bgl,
            tip_sampler,
            comp_pipe,
            commit_pipe,
            present_pipe,
            selmix_pipe,
            sel: None,
            sel_none,
            fx_pipe,
            fx_bgl,
            fx_backup: None,
            fx_matrix: [1.0, 0.0, 0.0, 0.0, 1.0, 0.0],
            comp_bgl,
            below_valid: None,
            stroke_bbox: None,
        };
        e.clear_stroke();
        e
    }

    pub fn new_layer(&self) -> GpuLayer {
        let l = make_layer_tex(&self.device, self.w, self.h, "layer");
        let mut enc = self.device.create_command_encoder(&Default::default());
        clear_pass(&mut enc, &l.view, wgpu::Color::TRANSPARENT);
        self.queue.submit([enc.finish()]);
        l
    }

    pub fn invalidate(&mut self) {
        self.below_valid = None;
    }

    fn mask_tex(&self, size: u32, levels: &[Vec<u8>]) -> wgpu::TextureView {
        let tex = self.device.create_texture(&wgpu::TextureDescriptor {
            label: Some("mask"),
            size: wgpu::Extent3d { width: size, height: size, depth_or_array_layers: 1 },
            mip_level_count: levels.len() as u32,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: wgpu::TextureFormat::R8Unorm,
            usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_DST,
            view_formats: &[],
        });
        for (mip, data) in levels.iter().enumerate() {
            let s = (size >> mip).max(1);
            self.queue.write_texture(
                wgpu::TexelCopyTextureInfo { texture: &tex, mip_level: mip as u32, origin: wgpu::Origin3d::ZERO, aspect: wgpu::TextureAspect::All },
                data,
                wgpu::TexelCopyBufferLayout { offset: 0, bytes_per_row: Some(s), rows_per_image: Some(s) },
                wgpu::Extent3d { width: s, height: s, depth_or_array_layers: 1 },
            );
        }
        tex.create_view(&Default::default())
    }

    /// Prépare un pinceau sur la carte graphique : forme, grain (facultatif) et réglages.
    pub fn make_tip(&self, size: u32, tip_levels: &[Vec<u8>], grain: Option<&[Vec<u8>]>, grain_scale: f32, max_blend: bool) -> Tip {
        let view = self.mask_tex(size, tip_levels);
        let white = [vec![255u8]];
        let gview = match grain {
            Some(g) => self.mask_tex(size, g),
            None => self.mask_tex(1, &white),
        };
        let ub = self.device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("brush_u"),
            contents: bytemuck::bytes_of(&BrushU { grain_scale: grain_scale.max(0.05), grain_on: if grain.is_some() { 1.0 } else { 0.0 }, pad: [0.0; 2] }),
            usage: wgpu::BufferUsages::UNIFORM,
        });
        let bind = self.device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("tip_bg"),
            layout: &self.stamp_bgl,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: self.stamp_globals.as_entire_binding() },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::TextureView(&view) },
                wgpu::BindGroupEntry { binding: 2, resource: wgpu::BindingResource::Sampler(&self.tip_sampler) },
                wgpu::BindGroupEntry { binding: 3, resource: wgpu::BindingResource::TextureView(&gview) },
                wgpu::BindGroupEntry { binding: 4, resource: wgpu::BindingResource::Sampler(&self.grain_sampler) },
                wgpu::BindGroupEntry { binding: 5, resource: ub.as_entire_binding() },
            ],
        });
        Tip { bind, max_blend }
    }

    pub fn clear_stroke(&self) {
        let mut enc = self.device.create_command_encoder(&Default::default());
        clear_pass(&mut enc, &self.stroke_view, wgpu::Color::TRANSPARENT);
        self.queue.submit([enc.finish()]);
    }

    pub fn begin_stroke(&mut self) {
        self.clear_stroke();
        self.stroke_bbox = None;
    }

    /// Dessine des tampons dans la texture du trait en cours.
    pub fn stamp(&mut self, tip: &Tip, dabs: &[Dab]) {
        if dabs.is_empty() {
            return;
        }
        for d in dabs {
            let r = d.size * 0.75 + 1.0;
            let b = [d.pos[0] - r, d.pos[1] - r, d.pos[0] + r, d.pos[1] + r];
            self.stroke_bbox = Some(match self.stroke_bbox {
                None => b,
                Some(o) => [o[0].min(b[0]), o[1].min(b[1]), o[2].max(b[2]), o[3].max(b[3])],
            });
        }
        let buf = self.device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("dabs"),
            contents: bytemuck::cast_slice(dabs),
            usage: wgpu::BufferUsages::VERTEX,
        });
        let mut enc = self.device.create_command_encoder(&Default::default());
        {
            let mut rp = enc.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("stamp"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &self.stroke_view,
                    depth_slice: None,
                    resolve_target: None,
                    ops: wgpu::Operations { load: wgpu::LoadOp::Load, store: wgpu::StoreOp::Store },
                })],
                depth_stencil_attachment: None,
                timestamp_writes: None,
                occlusion_query_set: None,
                multiview_mask: None,
            });
            rp.set_pipeline(if tip.max_blend { &self.stamp_max_pipe } else { &self.stamp_pipe });
            rp.set_bind_group(0, &tip.bind, &[]);
            rp.set_vertex_buffer(0, buf.slice(..));
            rp.draw(0..6, 0..dabs.len() as u32);
        }
        self.queue.submit([enc.finish()]);
    }

    fn comp_bind(&self, u: &CompU, back: &wgpu::TextureView, layer: &wgpu::TextureView) -> wgpu::BindGroup {
        let ub = self.device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("comp_u"),
            contents: bytemuck::bytes_of(u),
            usage: wgpu::BufferUsages::UNIFORM,
        });
        self.device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("comp_bg"),
            layout: &self.comp_bgl,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: ub.as_entire_binding() },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::TextureView(back) },
                wgpu::BindGroupEntry { binding: 2, resource: wgpu::BindingResource::TextureView(layer) },
                wgpu::BindGroupEntry { binding: 3, resource: wgpu::BindingResource::TextureView(&self.stroke_view) },
                wgpu::BindGroupEntry { binding: 4, resource: wgpu::BindingResource::TextureView(self.sel.as_ref().map(|s| &s.1).unwrap_or(&self.sel_none)) },
            ],
        })
    }

    fn pass(&self, enc: &mut wgpu::CommandEncoder, pipe: &wgpu::RenderPipeline, target: &wgpu::TextureView, bg: &wgpu::BindGroup) {
        let mut rp = enc.begin_render_pass(&wgpu::RenderPassDescriptor {
            label: Some("comp"),
            color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                view: target,
                depth_slice: None,
                resolve_target: None,
                ops: wgpu::Operations { load: wgpu::LoadOp::Clear(wgpu::Color::TRANSPARENT), store: wgpu::StoreOp::Store },
            })],
            depth_stencil_attachment: None,
            timestamp_writes: None,
            occlusion_query_set: None,
            multiview_mask: None,
        });
        rp.set_pipeline(pipe);
        rp.set_bind_group(0, bg, &[]);
        rp.draw(0..3, 0..1);
    }

    fn layer_u(d: &LayerDraw, stroke: Option<StrokeState>, sel: bool) -> CompU {
        let mut u = CompU { opacity: d.opacity, mode: d.mode, lock_alpha: d.lock_alpha as u32, ..Default::default() };
        u.has_sel = sel as u32;
        if let Some(s) = stroke {
            u.color = [s.color[0], s.color[1], s.color[2], 1.0];
            u.stroke_mode = if s.erase { 2 } else { 1 };
            u.stroke_opacity = s.opacity;
        }
        u
    }

    /// Compose tous les calques dans `display`. `version` change à chaque modification des calques du dessous.
    pub fn compose(&mut self, bg: Option<[f32; 3]>, draws: &[LayerDraw], active: usize, stroke: Option<StrokeState>, below_version: u64) {
        let mut enc = self.device.create_command_encoder(&Default::default());
        let bgc = match bg {
            Some(c) => wgpu::Color { r: c[0] as f64, g: c[1] as f64, b: c[2] as f64, a: 1.0 },
            None => wgpu::Color::TRANSPARENT,
        };
        // 1) calques sous le calque actif (mis en cache)
        if self.below_valid != Some((active, below_version)) {
            clear_pass(&mut enc, &self.ping[0].view, bgc);
            let mut cur = 0usize;
            for d in draws.iter().filter(|d| d.index < active && d.visible) {
                let bgp = self.comp_bind(&Self::layer_u(d, None, false), &self.ping[cur].view, &self.layers[d.index].view);
                self.pass(&mut enc, &self.comp_pipe, &self.ping[1 - cur].view, &bgp);
                cur = 1 - cur;
            }
            enc.copy_texture_to_texture(self.ping[cur].tex.as_image_copy(), self.below.tex.as_image_copy(), self.extent());
            self.below_valid = Some((active, below_version));
        }
        // 2) calque actif (avec le trait en cours) et calques du dessus
        enc.copy_texture_to_texture(self.below.tex.as_image_copy(), self.ping[0].tex.as_image_copy(), self.extent());
        let mut cur = 0usize;
        for d in draws.iter().filter(|d| d.index >= active && d.visible) {
            let st = if d.index == active { stroke } else { None };
            let bgp = self.comp_bind(&Self::layer_u(d, st, self.sel.is_some()), &self.ping[cur].view, &self.layers[d.index].view);
            self.pass(&mut enc, &self.comp_pipe, &self.ping[1 - cur].view, &bgp);
            cur = 1 - cur;
        }
        let bgp = self.comp_bind(&CompU::default(), &self.ping[1 - cur].view, &self.ping[cur].view);
        self.pass(&mut enc, &self.present_pipe, &self.display.view, &bgp);
        self.queue.submit([enc.finish()]);
    }

    fn extent(&self) -> wgpu::Extent3d {
        wgpu::Extent3d { width: self.w, height: self.h, depth_or_array_layers: 1 }
    }

    /// Rectangle (entier, limité à la toile) couvert par le trait en cours.
    pub fn stroke_rect(&self) -> Option<(u32, u32, u32, u32)> {
        let b = self.stroke_bbox?;
        let x0 = (b[0].floor().max(0.0) as u32).min(self.w);
        let y0 = (b[1].floor().max(0.0) as u32).min(self.h);
        let x1 = (b[2].ceil().max(0.0) as u32).min(self.w);
        let y1 = (b[3].ceil().max(0.0) as u32).min(self.h);
        if x1 <= x0 || y1 <= y0 {
            return None;
        }
        Some((x0, y0, x1 - x0, y1 - y0))
    }

    /// Copie une zone d'un calque (pour annuler / rétablir).
    pub fn save_region(&self, layer: usize, rect: (u32, u32, u32, u32)) -> UndoRegion {
        let (x, y, w, h) = rect;
        let tex = self.device.create_texture(&wgpu::TextureDescriptor {
            label: Some("undo"),
            size: wgpu::Extent3d { width: w, height: h, depth_or_array_layers: 1 },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: LAYER_FMT,
            usage: wgpu::TextureUsages::COPY_SRC | wgpu::TextureUsages::COPY_DST,
            view_formats: &[],
        });
        let mut enc = self.device.create_command_encoder(&Default::default());
        enc.copy_texture_to_texture(
            wgpu::TexelCopyTextureInfo { texture: &self.layers[layer].tex, mip_level: 0, origin: wgpu::Origin3d { x, y, z: 0 }, aspect: wgpu::TextureAspect::All },
            tex.as_image_copy(),
            wgpu::Extent3d { width: w, height: h, depth_or_array_layers: 1 },
        );
        self.queue.submit([enc.finish()]);
        UndoRegion { layer, x, y, w, h, tex }
    }

    /// Remet une zone sauvegardée et renvoie l'état d'avant (pour l'opération inverse).
    pub fn swap_region(&mut self, r: UndoRegion) -> UndoRegion {
        let before = self.save_region(r.layer, (r.x, r.y, r.w, r.h));
        let mut enc = self.device.create_command_encoder(&Default::default());
        enc.copy_texture_to_texture(
            r.tex.as_image_copy(),
            wgpu::TexelCopyTextureInfo { texture: &self.layers[r.layer].tex, mip_level: 0, origin: wgpu::Origin3d { x: r.x, y: r.y, z: 0 }, aspect: wgpu::TextureAspect::All },
            wgpu::Extent3d { width: r.w, height: r.h, depth_or_array_layers: 1 },
        );
        self.queue.submit([enc.finish()]);
        self.below_valid = None;
        before
    }

    /// Fusionne le trait en cours dans le calque actif.
    pub fn commit_stroke(&mut self, layer: usize, d: &LayerDraw, stroke: StrokeState) {
        let mut u = Self::layer_u(d, Some(stroke), self.sel.is_some());
        u.opacity = 1.0;
        let bg = self.comp_bind(&u, &self.ping[0].view, &self.layers[layer].view);
        let mut enc = self.device.create_command_encoder(&Default::default());
        self.pass(&mut enc, &self.commit_pipe, &self.tmp.view, &bg);
        enc.copy_texture_to_texture(self.tmp.tex.as_image_copy(), self.layers[layer].tex.as_image_copy(), self.extent());
        self.queue.submit([enc.finish()]);
        self.clear_stroke();
        self.stroke_bbox = None;
        self.below_valid = None;
    }

    pub fn clear_layer(&mut self, layer: usize) {
        let mut enc = self.device.create_command_encoder(&Default::default());
        clear_pass(&mut enc, &self.layers[layer].view, wgpu::Color::TRANSPARENT);
        self.queue.submit([enc.finish()]);
        self.below_valid = None;
    }

    pub fn copy_layer(&mut self, from: usize, to: usize) {
        let mut enc = self.device.create_command_encoder(&Default::default());
        enc.copy_texture_to_texture(self.layers[from].tex.as_image_copy(), self.layers[to].tex.as_image_copy(), self.extent());
        self.queue.submit([enc.finish()]);
        self.below_valid = None;
    }

    /// Fusionne le calque `upper` dans `lower` (avec son opacité et son mode).
    pub fn merge_down(&mut self, upper: &LayerDraw, lower: usize) {
        let u = Self::layer_u(upper, None, false);
        let bg = self.comp_bind(&u, &self.layers[lower].view, &self.layers[upper.index].view);
        let mut enc = self.device.create_command_encoder(&Default::default());
        self.pass(&mut enc, &self.comp_pipe, &self.tmp.view, &bg);
        enc.copy_texture_to_texture(self.tmp.tex.as_image_copy(), self.layers[lower].tex.as_image_copy(), self.extent());
        self.queue.submit([enc.finish()]);
        self.below_valid = None;
    }

    // ---------- Ajustements ----------
    pub fn fx_active(&self) -> bool {
        self.fx_backup.is_some()
    }

    /// Mémorise le calque avant un ajustement.
    pub fn fx_begin(&mut self, layer: usize) {
        if self.fx_backup.is_some() {
            return;
        }
        let tex = self.device.create_texture(&wgpu::TextureDescriptor {
            label: Some("fx_backup"),
            size: self.extent(),
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: LAYER_FMT,
            usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_SRC | wgpu::TextureUsages::COPY_DST,
            view_formats: &[],
        });
        let mut enc = self.device.create_command_encoder(&Default::default());
        enc.copy_texture_to_texture(self.layers[layer].tex.as_image_copy(), tex.as_image_copy(), self.extent());
        self.queue.submit([enc.finish()]);
        let view = tex.create_view(&Default::default());
        self.fx_backup = Some((layer, tex, view));
    }

    fn fx_pass(&self, enc: &mut wgpu::CommandEncoder, kind: u32, p: [f32; 3], dir: [f32; 2], src: &wgpu::TextureView, dst: &wgpu::TextureView) {
        #[repr(C)]
        #[derive(Clone, Copy, Pod, Zeroable)]
        struct FxU {
            kind: u32,
            p: [f32; 3],
            dir: [f32; 2],
            size: [f32; 2],
            m0: [f32; 4],
            m1: [f32; 2],
            pad: [f32; 2],
        }
        let m = self.fx_matrix;
        let ub = self.device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("fx_u"),
            contents: bytemuck::bytes_of(&FxU { kind, p, dir, size: [self.w as f32, self.h as f32], m0: [m[0], m[1], m[2], m[3]], m1: [m[4], m[5]], pad: [0.0; 2] }),
            usage: wgpu::BufferUsages::UNIFORM,
        });
        let bg = self.device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("fx_bg"),
            layout: &self.fx_bgl,
            entries: &[wgpu::BindGroupEntry { binding: 0, resource: ub.as_entire_binding() }, wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::TextureView(src) }],
        });
        self.pass(enc, &self.fx_pipe, dst, &bg);
    }

    /// Recalcule l'aperçu de l'ajustement à partir du calque d'origine.
    pub fn fx_update(&mut self, kind: u32, p: [f32; 3]) {
        let Some((layer, _, bview)) = &self.fx_backup else { return };
        let layer = *layer;
        let mut enc = self.device.create_command_encoder(&Default::default());
        if kind == 1 {
            // flou : horizontal vers tmp, puis vertical vers le calque
            self.fx_pass(&mut enc, 1, p, [1.0, 0.0], bview, &self.tmp.view);
            self.fx_pass(&mut enc, 1, p, [0.0, 1.0], &self.tmp.view, &self.layers[layer].view);
        } else {
            self.fx_pass(&mut enc, kind, p, [0.0, 0.0], bview, &self.layers[layer].view);
        }
        if self.sel.is_some() {
            // seulement dans la sélection : mélange avec le calque d'origine
            enc.copy_texture_to_texture(self.layers[layer].tex.as_image_copy(), self.tmp.tex.as_image_copy(), self.extent());
            let mut u = CompU::default();
            u.has_sel = 1;
            let bgp = self.comp_bind(&u, bview, &self.tmp.view);
            self.pass(&mut enc, &self.selmix_pipe, &self.layers[layer].view, &bgp);
        }
        self.queue.submit([enc.finish()]);
        self.below_valid = None;
    }

    /// Efface le contenu du calque dans la sélection.
    pub fn clear_in_selection(&mut self, layer: usize) {
        if self.sel.is_none() {
            return;
        }
        let mut enc = self.device.create_command_encoder(&Default::default());
        enc.copy_texture_to_texture(self.layers[layer].tex.as_image_copy(), self.tmp.tex.as_image_copy(), self.extent());
        clear_pass(&mut enc, &self.ping[0].view, wgpu::Color::TRANSPARENT);
        let mut u = CompU::default();
        u.has_sel = 1;
        let bgp = self.comp_bind(&u, &self.tmp.view, &self.ping[0].view);
        self.pass(&mut enc, &self.selmix_pipe, &self.layers[layer].view, &bgp);
        self.queue.submit([enc.finish()]);
        self.below_valid = None;
    }

    /// Définit la sélection (masque 0..255 à la taille de la toile) ou l'enlève.
    pub fn set_selection(&mut self, mask: Option<&[u8]>) {
        self.sel = mask.map(|m| {
            let t = self.device.create_texture(&wgpu::TextureDescriptor {
                label: Some("selection"),
                size: self.extent(),
                mip_level_count: 1,
                sample_count: 1,
                dimension: wgpu::TextureDimension::D2,
                format: wgpu::TextureFormat::R8Unorm,
                usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_DST,
                view_formats: &[],
            });
            self.queue.write_texture(
                t.as_image_copy(),
                m,
                wgpu::TexelCopyBufferLayout { offset: 0, bytes_per_row: Some(self.w), rows_per_image: Some(self.h) },
                self.extent(),
            );
            let v = t.create_view(&Default::default());
            (t, v)
        });
        self.below_valid = None;
    }

    /// Annule l'ajustement en cours.
    pub fn fx_cancel(&mut self) {
        if let Some((layer, tex, _)) = self.fx_backup.take() {
            let mut enc = self.device.create_command_encoder(&Default::default());
            enc.copy_texture_to_texture(tex.as_image_copy(), self.layers[layer].tex.as_image_copy(), self.extent());
            self.queue.submit([enc.finish()]);
            self.below_valid = None;
        }
    }

    /// Valide l'ajustement : renvoie la zone d'annulation (le calque d'avant).
    pub fn fx_commit(&mut self) -> Option<UndoRegion> {
        let (layer, tex, _) = self.fx_backup.take()?;
        Some(UndoRegion { layer, x: 0, y: 0, w: self.w, h: self.h, tex })
    }

    /// Lit les pixels d'une texture (RGBA prémultiplié) — pour l'enregistrement.
    pub fn read_texture(&self, tex: &wgpu::Texture) -> Vec<u8> {
        let row = self.w * 4;
        let padded = row.div_ceil(256) * 256;
        let buf = self.device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("readback"),
            size: (padded * self.h) as u64,
            usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::MAP_READ,
            mapped_at_creation: false,
        });
        let mut enc = self.device.create_command_encoder(&Default::default());
        enc.copy_texture_to_buffer(
            tex.as_image_copy(),
            wgpu::TexelCopyBufferInfo { buffer: &buf, layout: wgpu::TexelCopyBufferLayout { offset: 0, bytes_per_row: Some(padded), rows_per_image: Some(self.h) } },
            self.extent(),
        );
        self.queue.submit([enc.finish()]);
        let slice = buf.slice(..);
        slice.map_async(wgpu::MapMode::Read, |_| {});
        let _ = self.device.poll(wgpu::PollType::wait_indefinitely());
        let data = slice.get_mapped_range().expect("map");
        let mut out = Vec::with_capacity((row * self.h) as usize);
        for y in 0..self.h {
            let o = (y * padded) as usize;
            out.extend_from_slice(&data[o..o + row as usize]);
        }
        drop(data);
        buf.unmap();
        out
    }

    pub fn read_layer(&self, i: usize) -> Vec<u8> {
        self.read_texture(&self.layers[i].tex)
    }

    pub fn read_display(&self) -> Vec<u8> {
        self.read_texture(&self.display.tex)
    }

    pub fn write_layer(&mut self, i: usize, rgba_premul: &[u8]) {
        self.queue.write_texture(
            self.layers[i].tex.as_image_copy(),
            rgba_premul,
            wgpu::TexelCopyBufferLayout { offset: 0, bytes_per_row: Some(self.w * 4), rows_per_image: Some(self.h) },
            self.extent(),
        );
        self.below_valid = None;
    }
}
