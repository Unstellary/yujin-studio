//! Yujin Studio — appli de dessin native (Rust + wgpu + egui).

pub mod app;
pub mod brush;
pub mod canvas;
pub mod doc;
pub mod fs;
pub mod gpu;
pub mod library;
pub mod procreate;
pub mod preview;
pub mod psd;
pub mod platform;
pub mod ui;
pub mod updater;

#[cfg(not(any(target_os = "android", target_arch = "wasm32")))]
pub fn run_desktop() {
    let _ = env_logger::try_init();
    let el = winit::event_loop::EventLoop::new().expect("event loop");
    app::run(el);
}

#[cfg(target_os = "android")]
#[no_mangle]
fn android_main(android_app: winit::platform::android::activity::AndroidApp) {
    use winit::platform::android::EventLoopBuilderExtAndroid;
    android_logger::init_once(android_logger::Config::default().with_max_level(log::LevelFilter::Info).with_tag("YujinStudio"));
    if let Some(p) = android_app.internal_data_path() {
        doc::set_data_dir(p);
    }
    let el = winit::event_loop::EventLoop::builder().with_android_app(android_app).build().expect("event loop");
    app::run(el);
}

/// Affiche une erreur dans la page (version navigateur).
#[cfg(target_arch = "wasm32")]
pub fn web_error(msg: &str) {
    let Some(doc) = web_sys::window().and_then(|w| w.document()) else { return };
    let el = match doc.get_element_by_id("chargement") {
        Some(e) => e,
        None => {
            let Ok(e) = doc.create_element("div") else { return };
            e.set_id("chargement");
            if let Some(b) = doc.body() {
                let _ = b.append_child(&e);
            }
            e
        }
    };
    el.set_inner_html(&format!("<p>Oups&nbsp;: {}</p>", msg.replace('<', "&lt;")));
    let _ = el.set_attribute("style", "display:flex;z-index:10;background:#111113");
}

/// Point d'entrée de la version navigateur (iPad…).
#[cfg(target_arch = "wasm32")]
#[wasm_bindgen::prelude::wasm_bindgen(start)]
pub fn web_start() {
    std::panic::set_hook(Box::new(|info| {
        console_error_panic_hook::hook(info);
        web_error(&info.to_string());
    }));
    let _ = console_log::init_with_level(log::Level::Info);
    doc::set_data_dir(std::path::PathBuf::from("/yujin"));
    wasm_bindgen_futures::spawn_local(async {
        fs::init().await;
        if let Some(el) = web_sys::window().and_then(|w| w.document()).and_then(|d| d.get_element_by_id("chargement")) {
            el.remove();
        }
        let el = winit::event_loop::EventLoop::new().expect("event loop");
        app::run(el);
    });
}
