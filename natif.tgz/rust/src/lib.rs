//! Yujin Studio — appli de dessin native (Rust + wgpu + egui).

pub mod app;
pub mod brush;
pub mod canvas;
pub mod doc;
pub mod gpu;
pub mod library;
pub mod procreate;
pub mod preview;
pub mod psd;
pub mod platform;
pub mod ui;
pub mod updater;

#[cfg(not(target_os = "android"))]
pub fn run_desktop() {
    let _ = env_logger::try_init();
    let el = winit::event_loop::EventLoop::new().expect("event loop");
    app::run(el);
}

#[cfg(target_os = "android")]
#[no_mangle]
fn android_main(android_app: winit::platform::android::activity::AndroidApp) {
    use winit::platform::android::EventLoopBuilderExtAndroid;
    android_logger::init_once(android_logger::Config::default().with_max_level(log::LevelFilter::Info).with_tag("YujinStudio"));
    if let Some(p) = android_app.internal_data_path() {
        doc::set_data_dir(p);
    }
    let el = winit::event_loop::EventLoop::builder().with_android_app(android_app).build().expect("event loop");
    app::run(el);
}
