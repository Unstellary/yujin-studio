//! Document : liste des calques (réglages), enregistrement et ouverture (.yujin = zip de PNG + JSON).

use serde::{Deserialize, Serialize};
use std::io::{Read, Write};
use std::path::{Path, PathBuf};

pub const BLENDS: &[(&str, u32)] = &[
    ("Normal", 0),
    ("Produit", 1),
    ("Écran", 2),
    ("Incrustation", 3),
    ("Obscurcir", 4),
    ("Éclaircir", 5),
    ("Densité couleur −", 7),
    ("Densité couleur +", 6),
    ("Densité linéaire −", 18),
    ("Ajout", 12),
    ("Lumière crue", 8),
    ("Lumière tamisée", 9),
    ("Différence", 10),
    ("Exclusion", 11),
    ("Soustraction", 13),
    ("Teinte", 14),
    ("Saturation", 15),
    ("Couleur", 16),
    ("Luminosité", 17),
];

pub fn blend_name(m: u32) -> &'static str {
    BLENDS.iter().find(|b| b.1 == m).map(|b| b.0).unwrap_or("Normal")
}

#[derive(Clone, Serialize, Deserialize, Debug)]
pub struct LayerInfo {
    pub name: String,
    pub visible: bool,
    pub opacity: f32,
    pub mode: u32,
    #[serde(default)]
    pub lock_alpha: bool,
}

impl LayerInfo {
    pub fn new(name: &str) -> Self {
        LayerInfo { name: name.to_string(), visible: true, opacity: 1.0, mode: 0, lock_alpha: false }
    }
}

#[derive(Clone, Serialize, Deserialize, Debug)]
pub struct DocInfo {
    pub name: String,
    pub w: u32,
    pub h: u32,
    pub bg: [f32; 3],
    pub bg_visible: bool,
    pub layers: Vec<LayerInfo>,
    pub active: usize,
    #[serde(default)]
    pub counter: u32,
}

impl DocInfo {
    pub fn new(w: u32, h: u32) -> Self {
        DocInfo { name: "Sans titre".into(), w, h, bg: [1.0, 1.0, 1.0], bg_visible: true, layers: vec![LayerInfo::new("Calque 1")], active: 0, counter: 1 }
    }
}

/// Dossier des données de l'appli (fixé au démarrage).
static DATA_DIR: std::sync::OnceLock<PathBuf> = std::sync::OnceLock::new();

pub fn set_data_dir(p: PathBuf) {
    let _ = DATA_DIR.set(p);
}

pub fn data_dir() -> PathBuf {
    if let Some(p) = DATA_DIR.get() {
        return p.clone();
    }
    #[cfg(target_os = "windows")]
    {
        if let Ok(p) = std::env::var("LOCALAPPDATA") {
            return PathBuf::from(p).join("YujinStudio");
        }
    }
    if let Ok(h) = std::env::var("HOME") {
        return PathBuf::from(h).join(".local/share/yujin-studio");
    }
    PathBuf::from(".")
}

pub fn drawings_dir() -> PathBuf {
    let d = data_dir().join("dessins");
    let _ = std::fs::create_dir_all(&d);
    d
}

pub fn unpremultiply(px: &mut [u8]) {
    for p in px.chunks_exact_mut(4) {
        let a = p[3] as u32;
        if a > 0 && a < 255 {
            for c in &mut p[..3] {
                *c = ((*c as u32 * 255 + a / 2) / a).min(255) as u8;
            }
        }
    }
}

pub fn premultiply(px: &mut [u8]) {
    for p in px.chunks_exact_mut(4) {
        let a = p[3] as u32;
        if a < 255 {
            for c in &mut p[..3] {
                *c = ((*c as u32 * a + 127) / 255) as u8;
            }
        }
    }
}

pub fn encode_png(w: u32, h: u32, rgba: &[u8]) -> Vec<u8> {
    let mut out = Vec::new();
    {
        let mut enc = png::Encoder::new(&mut out, w, h);
        enc.set_color(png::ColorType::Rgba);
        enc.set_depth(png::BitDepth::Eight);
        enc.set_compression(png::Compression::Fast);
        let mut wr = enc.write_header().expect("png");
        wr.write_image_data(rgba).expect("png");
    }
    out
}

pub fn decode_png(data: &[u8]) -> Option<(u32, u32, Vec<u8>)> {
    let mut dec = png::Decoder::new(std::io::Cursor::new(data));
    dec.set_transformations(png::Transformations::EXPAND | png::Transformations::STRIP_16);
    let mut r = dec.read_info().ok()?;
    let mut buf = vec![0; r.output_buffer_size()];
    let info = r.next_frame(&mut buf).ok()?;
    let (w, h) = (info.width, info.height);
    buf.truncate(info.buffer_size());
    let rgba = match info.color_type {
        png::ColorType::Rgba => buf,
        png::ColorType::Rgb => buf.chunks_exact(3).flat_map(|c| [c[0], c[1], c[2], 255]).collect(),
        png::ColorType::GrayscaleAlpha => buf.chunks_exact(2).flat_map(|c| [c[0], c[0], c[0], c[1]]).collect(),
        png::ColorType::Grayscale => buf.iter().flat_map(|&g| [g, g, g, 255]).collect(),
        _ => return None,
    };
    Some((w, h, rgba))
}

/// Enregistre le document : `layers_px` = pixels prémultipliés de chaque calque.
pub fn save(path: &Path, info: &DocInfo, layers_px: Vec<Vec<u8>>, thumb_png: Option<Vec<u8>>) -> std::io::Result<()> {
    let tmp = path.with_extension("tmp");
    {
        let f = std::fs::File::create(&tmp)?;
        let mut z = zip::ZipWriter::new(f);
        let opt: zip::write::SimpleFileOptions = zip::write::SimpleFileOptions::default().compression_method(zip::CompressionMethod::Stored);
        z.start_file("document.json", opt)?;
        z.write_all(serde_json::to_string_pretty(info).unwrap().as_bytes())?;
        for (i, mut px) in layers_px.into_iter().enumerate() {
            unpremultiply(&mut px);
            z.start_file(format!("calques/{i}.png"), opt)?;
            z.write_all(&encode_png(info.w, info.h, &px))?;
        }
        if let Some(t) = thumb_png {
            z.start_file("apercu.png", opt)?;
            z.write_all(&t)?;
        }
        z.finish()?;
    }
    std::fs::rename(&tmp, path)
}

/// Ouvre un document : renvoie ses réglages et les pixels prémultipliés de chaque calque.
pub fn load(path: &Path) -> Option<(DocInfo, Vec<Vec<u8>>)> {
    let f = std::fs::File::open(path).ok()?;
    let mut z = zip::ZipArchive::new(f).ok()?;
    let mut s = String::new();
    z.by_name("document.json").ok()?.read_to_string(&mut s).ok()?;
    let info: DocInfo = serde_json::from_str(&s).ok()?;
    let mut layers = Vec::new();
    for i in 0..info.layers.len() {
        let mut data = Vec::new();
        z.by_name(&format!("calques/{i}.png")).ok()?.read_to_end(&mut data).ok()?;
        let (w, h, mut px) = decode_png(&data)?;
        if w != info.w || h != info.h {
            return None;
        }
        premultiply(&mut px);
        layers.push(px);
    }
    Some((info, layers))
}
