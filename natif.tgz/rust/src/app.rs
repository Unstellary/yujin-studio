//! Boucle de l'appli : fenêtre, carte graphique, interface, stylet et gestes.

use crate::brush::{self, Point};
use crate::canvas::{Canvas, Tool};
use crate::doc::{self, DocInfo};
use crate::gpu::Engine;
use crate::ui::{self, UiState};
use egui::{Pos2, ViewportId};
use std::collections::HashMap;
use std::sync::Arc;
use std::time::Duration;
use web_time::Instant;
use winit::application::ApplicationHandler;
use winit::event::{ElementState, Force, MouseButton, MouseScrollDelta, TouchPhase, WindowEvent};
use winit::event_loop::{ActiveEventLoop, ControlFlow, EventLoop};
use winit::window::{Window, WindowId};

#[derive(Clone, Copy)]
struct Finger {
    pos: Pos2,
    start: Pos2,
}

enum Gesture {
    Idle,
    /// Un doigt posé : on attend un peu pour savoir si c'est un geste à plusieurs doigts
    Pending { id: u64, pts: Vec<Point>, t0: Instant },
    DrawFinger { id: u64 },
    Transform { a: u64, b: u64, pa: Pos2, pb: Pos2, view: crate::canvas::View },
    Blocked,
}

pub struct App {
    window: Option<Arc<Window>>,
    painter: Option<egui_wgpu::winit::Painter>,
    /// navigateur : le moteur graphique se prépare en arrière-plan
    #[cfg(target_arch = "wasm32")]
    pending_painter: std::rc::Rc<std::cell::RefCell<Option<egui_wgpu::winit::Painter>>>,
    #[cfg(target_arch = "wasm32")]
    painter_requested: bool,
    egui_ctx: egui::Context,
    egui_state: Option<egui_winit::State>,
    pub canvas: Option<Canvas>,
    pub ui: UiState,
    pub brushes: Vec<brush::Brush>,
    stroke_t0: Instant,
    // Entrées
    ui_touches: std::collections::HashSet<u64>,
    fingers: HashMap<u64, Finger>,
    pen: Option<u64>,
    gesture: Gesture,
    seq_t0: Instant,
    seq_max: usize,
    seq_moved: bool,
    /// séquence de doigts suspecte (paume posée pendant/près d'un trait au stylet)
    seq_palm: bool,
    /// dernier événement du stylet
    pen_last: Instant,
    mouse_pos: Pos2,
    mouse_drawing: bool,
    mouse_pan: Option<Pos2>,
    last_touch: Instant,
    last_save: Instant,
    display_ids: Option<(egui::TextureId, egui::TextureId)>,
    needs_fit: bool,
    next_repaint: Option<Instant>,
    update: crate::updater::Shared,
    update_started: bool,
    xf_ref: Option<(f32, f32, f32, f32)>,
    qs_time: Instant,
    qs_pos: Pos2,
    lasso: Option<Vec<(f32, f32)>>,
    /// fichier du dessin ouvert
    cur_path: Option<std::path::PathBuf>,
    /// écran d'accueil (galerie) affiché
    pub in_gallery: bool,
    previews: crate::preview::Previews,
}

impl App {
    pub fn new() -> Self {
        let egui_ctx = egui::Context::default();
        ui::setup_style(&egui_ctx);
        App {
            window: None,
            painter: None,
            #[cfg(target_arch = "wasm32")]
            pending_painter: Default::default(),
            #[cfg(target_arch = "wasm32")]
            painter_requested: false,
            egui_ctx,
            egui_state: None,
            canvas: None,
            ui: UiState::load(),
            brushes: crate::library::load(),
            ui_touches: Default::default(),
            stroke_t0: Instant::now(),
            fingers: HashMap::new(),
            pen: None,
            gesture: Gesture::Idle,
            seq_t0: Instant::now(),
            seq_max: 0,
            seq_moved: false,
            seq_palm: false,
            pen_last: Instant::now() - Duration::from_secs(10),
            mouse_pos: Pos2::ZERO,
            mouse_drawing: false,
            mouse_pan: None,
            last_touch: Instant::now() - Duration::from_secs(10),
            last_save: Instant::now(),
            display_ids: None,
            needs_fit: true,
            next_repaint: None,
            update: Default::default(),
            update_started: false,
            xf_ref: None,
            qs_time: Instant::now(),
            qs_pos: Pos2::ZERO,
            lasso: None,
            cur_path: None,
            in_gallery: true,
            previews: crate::preview::Previews::new(),
        }
    }

    fn ppp(&self) -> f32 {
        self.window.as_ref().map(|w| w.scale_factor() as f32).unwrap_or(1.0)
    }

    fn screen_rect(&self) -> egui::Rect {
        let w = self.window.as_ref().unwrap();
        let s = w.inner_size();
        egui::Rect::from_min_size(Pos2::ZERO, egui::vec2(s.width as f32, s.height as f32) / self.ppp())
    }

    fn current_path(&self) -> std::path::PathBuf {
        self.cur_path.clone().unwrap_or_else(|| doc::drawings_dir().join("courant.yujin"))
    }

    fn max_side(&self) -> u32 {
        self.painter.as_ref().and_then(|p| p.render_state()).map(|rs| rs.device.limits().max_texture_dimension_2d).unwrap_or(4096).min(8192)
    }

    /// Ouvre un nouveau dessin (fichier neuf) et quitte la galerie.
    fn open_new(&mut self, info: DocInfo, px: Option<Vec<Vec<u8>>>) {
        self.save_now();
        let max = self.max_side();
        if info.w > max || info.h > max {
            self.ui.toast(format!("Toile trop grande pour cet appareil (max {max} px)"));
            return;
        }
        self.cur_path = Some(doc::new_drawing_path());
        self.new_canvas_from(info, px);
        if let Some(c) = self.canvas.as_mut() {
            c.unsaved = true;
            c.last_change = Instant::now() - Duration::from_secs(10);
        }
        self.in_gallery = false;
        self.ui.panel = None;
    }

    /// Ouvre un dessin existant de la galerie.
    fn open_path(&mut self, path: &std::path::Path) {
        self.save_now();
        match doc::load(path) {
            Some((info, px)) if info.w <= self.max_side() && info.h <= self.max_side() => {
                self.cur_path = Some(path.to_path_buf());
                self.new_canvas_from(info, Some(px));
                self.in_gallery = false;
                self.ui.panel = None;
            }
            Some(_) => self.ui.toast("Dessin trop grand pour cet appareil".into()),
            None => self.ui.toast("Impossible d'ouvrir ce dessin".into()),
        }
    }

    /// Retour à la galerie : enregistre puis libère la toile.
    fn go_gallery(&mut self) {
        if let Some(c) = self.canvas.as_mut() {
            c.fx_cancel();
            c.transform_cancel();
        }
        self.ui.fx = None;
        self.save_now();
        if let Some(old) = self.canvas.take() {
            if let Some(rs) = self.painter.as_ref().and_then(|p| p.render_state()) {
                let mut r = rs.renderer.write();
                for t in old.thumbs.iter().flatten() {
                    r.free_texture(t);
                }
                if let Some((a, b)) = self.display_ids.take() {
                    r.free_texture(&a);
                    r.free_texture(&b);
                }
            }
        }
        self.ui.panel = None;
        self.ui.invalidate_gallery();
        self.in_gallery = true;
    }

    pub fn new_canvas_from(&mut self, info: DocInfo, px: Option<Vec<Vec<u8>>>) {
        let painter = self.painter.as_ref().unwrap();
        let rs = painter.render_state().expect("render state");
        // libère les anciennes textures de l'interface
        if let Some(old) = self.canvas.take() {
            let mut r = rs.renderer.write();
            for t in old.thumbs.iter().flatten() {
                r.free_texture(t);
            }
            if let Some((a, b)) = self.display_ids.take() {
                r.free_texture(&a);
                r.free_texture(&b);
            }
        }
        let srgb = rs.adapter.get_downlevel_capabilities().flags.contains(wgpu::DownlevelFlags::VIEW_FORMATS);
        let engine = Engine::new(rs.device.clone(), rs.queue.clone(), info.w, info.h, srgb);
        let canvas = Canvas::new(engine, info, px);
        {
            let mut r = rs.renderer.write();
            let lin = r.register_native_texture(&rs.device, &canvas.engine.display.srgb_view, wgpu::FilterMode::Linear);
            let near = r.register_native_texture(&rs.device, &canvas.engine.display.srgb_view, wgpu::FilterMode::Nearest);
            self.display_ids = Some((lin, near));
        }
        self.canvas = Some(canvas);
        self.needs_fit = true;
    }

    pub fn save_now(&mut self) {
        if let Some(c) = self.canvas.as_mut() {
            if c.unsaved {
                c.save(&self.cur_path.clone().unwrap_or_else(|| doc::drawings_dir().join("courant.yujin")), false);
            }
        }
        self.ui.save();
        self.last_save = Instant::now();
    }

    // ---------- Trait ----------
    fn begin_stroke(&mut self, pos: Pos2, p: f32) {
        let ui = &self.ui;
        let tool = ui.tool;
        let (bid, size, op) = match tool {
            Tool::Brush => (ui.brush.clone(), ui.size_brush, ui.op_brush),
            Tool::Eraser => (ui.eraser_brush.clone(), ui.size_eraser, ui.op_eraser),
            Tool::Smudge => (ui.smudge_brush.clone(), ui.size_smudge, ui.op_smudge),
        };
        let b = self.brushes.iter().find(|b| b.id == bid).unwrap_or(&self.brushes[0]).clone();
        let px = ui::slider_to_px(size, b.max_size);
        let color = ui.color;
        let curve = ui.pressure_curve;
        self.stroke_t0 = Instant::now();
        self.qs_time = Instant::now();
        self.qs_pos = pos;
        if let Some(c) = self.canvas.as_mut() {
            let cp = c.view.to_canvas(pos);
            c.begin_stroke(&b, px, op, color, tool, curve, Point { x: cp.x, y: cp.y, p, t: 0.0 });
        }
    }

    fn stroke_point(&mut self, pos: Pos2, p: f32) {
        if (pos - self.qs_pos).length() > 6.0 {
            self.qs_pos = pos;
            self.qs_time = Instant::now();
        }
        if let Some(c) = self.canvas.as_mut() {
            let cp = c.view.to_canvas(pos);
            c.add_point(Point { x: cp.x, y: cp.y, p, t: self.stroke_t0.elapsed().as_secs_f32() });
        }
    }

    fn end_stroke(&mut self) {
        if let Some(c) = self.canvas.as_mut() {
            c.end_stroke();
        }
    }

    fn is_ui(&self, pos: Pos2) -> bool {
        self.ui.is_over_ui(&self.egui_ctx, pos)
    }

    // ---------- Toucher / stylet ----------
    fn on_touch(&mut self, t: &winit::event::Touch) -> bool {
        if self.in_gallery {
            return false;
        }
        let ppp = self.ppp();
        let pos = Pos2::new(t.location.x as f32 / ppp, t.location.y as f32 / ppp);
        let is_pen = matches!(t.force, Some(Force::Calibrated { .. }));
        let pressure = t.force.map(|f| match f {
            Force::Calibrated { force, max_possible_force, .. } => (force / max_possible_force.max(1e-6)) as f32,
            Force::Normalized(v) => v as f32,
        });
        self.last_touch = Instant::now();

        // Les contacts commencés sur l'interface restent à l'interface
        if t.phase == TouchPhase::Started && self.is_ui(pos) {
            self.ui_touches.insert(t.id);
            return false;
        }
        if self.ui_touches.contains(&t.id) {
            if matches!(t.phase, TouchPhase::Ended | TouchPhase::Cancelled) {
                self.ui_touches.remove(&t.id);
            }
            return false;
        }
        if self.ui.panel.is_some() && t.phase == TouchPhase::Started && self.ui.fx.is_none() && self.ui.panel != Some(ui::Panel::Select) && !self.canvas.as_ref().is_some_and(|c| c.xform.is_some()) {
            // toucher la toile ferme le panneau ouvert (sauf pendant un ajustement)
            self.ui.panel = None;
        }

        if self.canvas.as_ref().is_some_and(|c| c.xform.is_some()) {
            self.transform_touch(t.id, t.phase, pos);
            return true;
        }
        if self.ui.panel == Some(ui::Panel::Select) && (is_pen || self.fingers.is_empty() || self.lasso.is_some()) {
            self.lasso_input(t.phase, pos);
            return true;
        }

        if is_pen {
            self.ui.pen_seen = true;
            self.pen_last = Instant::now();
            // rejet de la paume : tout ce que font les doigts pendant le trait est ignoré
            if !self.fingers.is_empty() {
                self.seq_palm = true;
            }
            let p = pressure.unwrap_or(1.0).clamp(0.0, 1.0);
            match t.phase {
                TouchPhase::Started => {
                    // le stylet prend la main sur un trait au doigt
                    if let Gesture::DrawFinger { .. } | Gesture::Pending { .. } = self.gesture {
                        if let Some(c) = self.canvas.as_mut() {
                            c.cancel_stroke();
                        }
                        self.gesture = Gesture::Blocked;
                    }
                    // une paume posée avant le stylet ne doit ni zoomer ni déplacer la toile
                    if let Gesture::Transform { view, .. } = self.gesture {
                        if let Some(c) = self.canvas.as_mut() {
                            c.view = view;
                        }
                        self.gesture = Gesture::Blocked;
                    }
                    self.pen = Some(t.id);
                    if self.ui.eyedropper {
                        self.pick_color(pos);
                    } else {
                        self.begin_stroke(pos, p);
                    }
                }
                TouchPhase::Moved => {
                    if self.pen == Some(t.id) {
                        if self.ui.eyedropper {
                            self.pick_color(pos);
                        } else {
                            self.stroke_point(pos, p);
                        }
                    }
                }
                TouchPhase::Ended | TouchPhase::Cancelled => {
                    if self.pen == Some(t.id) {
                        if self.ui.eyedropper {
                            self.ui.eyedropper = false;
                        } else if t.phase == TouchPhase::Cancelled {
                            if let Some(c) = self.canvas.as_mut() {
                                c.cancel_stroke();
                            }
                        } else {
                            self.end_stroke();
                        }
                        self.pen = None;
                    }
                }
            }
            return true;
        }

        // ---- Doigts ----
        let finger_draw = !self.ui.pen_seen || self.ui.finger_draw;
        match t.phase {
            TouchPhase::Started => {
                if self.fingers.is_empty() {
                    self.seq_t0 = Instant::now();
                    self.seq_max = 0;
                    self.seq_moved = false;
                    self.seq_palm = false;
                }
                // contact posé pendant un trait au stylet ou juste après : c'est la paume
                if self.pen.is_some() || (self.ui.pen_seen && self.pen_last.elapsed() < Duration::from_millis(500)) {
                    self.seq_palm = true;
                }
                self.fingers.insert(t.id, Finger { pos, start: pos });
                self.seq_max = self.seq_max.max(self.fingers.len());
                let n = self.fingers.len();
                if n == 1 {
                    if self.pen.is_none() && finger_draw && !self.ui.eyedropper {
                        self.gesture = Gesture::Pending { id: t.id, pts: vec![Point { x: pos.x, y: pos.y, p: 0.5, t: 0.0 }], t0: Instant::now() };
                    } else if self.ui.eyedropper {
                        self.pick_color(pos);
                        self.gesture = Gesture::Blocked;
                    } else {
                        self.gesture = Gesture::Blocked;
                    }
                } else if n == 2 && self.seq_palm {
                    self.gesture = Gesture::Blocked;
                } else if n == 2 {
                    let early = self.seq_t0.elapsed() < Duration::from_millis(300);
                    match self.gesture {
                        Gesture::DrawFinger { .. } if early => {
                            if let Some(c) = self.canvas.as_mut() {
                                c.cancel_stroke();
                            }
                        }
                        Gesture::DrawFinger { .. } => return true,
                        _ => {}
                    }
                    let ids: Vec<u64> = self.fingers.keys().copied().collect();
                    let (a, b) = (ids[0], ids[1]);
                    if let Some(c) = self.canvas.as_ref() {
                        self.gesture = Gesture::Transform { a, b, pa: self.fingers[&a].pos, pb: self.fingers[&b].pos, view: c.view };
                    }
                } else {
                    if let Gesture::DrawFinger { .. } = self.gesture {
                    } else {
                        self.gesture = Gesture::Blocked;
                    }
                }
            }
            TouchPhase::Moved => {
                if let Some(f) = self.fingers.get_mut(&t.id) {
                    f.pos = pos;
                    if f.pos.distance(f.start) > 12.0 {
                        self.seq_moved = true;
                    }
                }
                match &mut self.gesture {
                    Gesture::Pending { id, pts, t0 } if *id == t.id => {
                        pts.push(Point { x: pos.x, y: pos.y, p: 0.5, t: 0.0 });
                        if t0.elapsed() > Duration::from_millis(70) || self.seq_moved {
                            let id = *id;
                            let pts = std::mem::take(pts);
                            self.gesture = Gesture::DrawFinger { id };
                            let first = pts[0];
                            self.begin_stroke(Pos2::new(first.x, first.y), 0.5);
                            for q in &pts[1..] {
                                self.stroke_point(Pos2::new(q.x, q.y), 0.5);
                            }
                        }
                    }
                    Gesture::DrawFinger { id } if *id == t.id => {
                        self.stroke_point(pos, 0.5);
                    }
                    Gesture::Transform { a, b, pa, pb, view } => {
                        let (a, b, pa, pb, v0) = (*a, *b, *pa, *pb, *view);
                        if let (Some(fa), Some(fb)) = (self.fingers.get(&a), self.fingers.get(&b)) {
                            let (na, nb) = (fa.pos, fb.pos);
                            if let Some(c) = self.canvas.as_mut() {
                                let c0 = pa + (pb - pa) / 2.0;
                                let c1 = na + (nb - na) / 2.0;
                                let d0 = (pb - pa).length().max(1.0);
                                let d1 = (nb - na).length().max(1.0);
                                let ang = (nb - na).angle() - (pb - pa).angle();
                                let k = v0.to_canvas(c0);
                                let mut v = v0;
                                v.scale = (v0.scale * d1 / d0).clamp(0.02, 64.0);
                                v.rot = v0.rot + ang;
                                // aimante la rotation sur les angles droits
                                let q = std::f32::consts::FRAC_PI_2;
                                let near = (v.rot / q).round() * q;
                                if (v.rot - near).abs() < 0.06 {
                                    v.rot = near;
                                }
                                let p = v.to_screen(k);
                                v.offset += c1 - p;
                                c.view = v;
                            }
                        }
                    }
                    _ => {}
                }
            }
            TouchPhase::Ended | TouchPhase::Cancelled => {
                self.fingers.remove(&t.id);
                // Android annule les contacts qu'il reconnaît comme une paume
                if t.phase == TouchPhase::Cancelled {
                    self.seq_palm = true;
                }
                match &mut self.gesture {
                    Gesture::Pending { id, pts, .. } if *id == t.id => {
                        // toucher rapide avec un doigt : un point
                        let pts = std::mem::take(pts);
                        if self.seq_max == 1 && t.phase == TouchPhase::Ended {
                            let first = pts[0];
                            self.begin_stroke(Pos2::new(first.x, first.y), 0.5);
                            for q in &pts[1..] {
                                self.stroke_point(Pos2::new(q.x, q.y), 0.5);
                            }
                            self.end_stroke();
                        }
                        self.gesture = Gesture::Idle;
                    }
                    Gesture::DrawFinger { id } if *id == t.id => {
                        if t.phase == TouchPhase::Cancelled {
                            if let Some(c) = self.canvas.as_mut() {
                                c.cancel_stroke();
                            }
                        } else {
                            self.end_stroke();
                        }
                        self.gesture = Gesture::Blocked;
                    }
                    _ => {}
                }
                if self.fingers.is_empty() {
                    let quick = self.seq_t0.elapsed() < Duration::from_millis(350) && !self.seq_moved && !self.seq_palm && self.pen.is_none();
                    if quick {
                        match self.seq_max {
                            2 => {
                                if let Some(c) = self.canvas.as_mut() {
                                    c.undo();
                                }
                            }
                            3 => {
                                if let Some(c) = self.canvas.as_mut() {
                                    c.redo();
                                }
                            }
                            4 => self.ui.hide_ui = !self.ui.hide_ui,
                            _ => {}
                        }
                    }
                    self.gesture = Gesture::Idle;
                } else if let Gesture::Transform { a, b, .. } = self.gesture {
                    if !self.fingers.contains_key(&a) || !self.fingers.contains_key(&b) {
                        self.gesture = Gesture::Blocked;
                    }
                }
            }
        }
        true
    }

    /// Mode Transformer : un contact déplace le calque, deux contacts l'agrandissent et le tournent.
    fn transform_touch(&mut self, id: u64, phase: TouchPhase, pos: Pos2) {
        match phase {
            TouchPhase::Started => {
                self.fingers.insert(id, Finger { pos, start: pos });
                self.xf_ref = None;
            }
            TouchPhase::Moved => {
                let Some(prev) = self.fingers.get(&id).map(|f| f.pos) else { return };
                if let Some(f) = self.fingers.get_mut(&id) {
                    f.pos = pos;
                }
                let Some(c) = self.canvas.as_mut() else { return };
                let Some(mut x) = c.xform else { return };
                if self.fingers.len() == 1 {
                    let (sn, cs) = (-c.view.rot).sin_cos();
                    let d = (pos - prev) / c.view.scale;
                    x.tx += d.x * cs - d.y * sn;
                    x.ty += d.x * sn + d.y * cs;
                } else if self.fingers.len() >= 2 {
                    let mut it = self.fingers.values();
                    let (a, b) = (it.next().unwrap().pos, it.next().unwrap().pos);
                    let (d, ang) = ((b - a).length().max(1.0), (b - a).angle());
                    match self.xf_ref {
                        None => self.xf_ref = Some((d, ang, x.scale, x.rot)),
                        Some((d0, a0, s0, r0)) => {
                            x.scale = (s0 * d / d0).clamp(0.02, 20.0);
                            x.rot = r0 + ang - a0;
                        }
                    }
                }
                c.xform = Some(x);
                c.transform_update();
            }
            TouchPhase::Ended | TouchPhase::Cancelled => {
                self.fingers.remove(&id);
                self.xf_ref = None;
            }
        }
    }

    fn lasso_input(&mut self, phase: TouchPhase, pos: Pos2) {
        let Some(c) = self.canvas.as_mut() else { return };
        let cp = c.view.to_canvas(pos);
        match phase {
            TouchPhase::Started => self.lasso = Some(vec![(cp.x, cp.y)]),
            TouchPhase::Moved => {
                if let Some(l) = self.lasso.as_mut() {
                    let last = *l.last().unwrap();
                    if (last.0 - cp.x).abs() + (last.1 - cp.y).abs() > 1.5 / c.view.scale.max(0.01) {
                        l.push((cp.x, cp.y));
                    }
                }
            }
            TouchPhase::Ended | TouchPhase::Cancelled => {
                if let Some(l) = self.lasso.take() {
                    if l.len() >= 3 && phase == TouchPhase::Ended {
                        c.set_selection(Some(l), false);
                    } else {
                        c.set_selection(None, false);
                    }
                }
            }
        }
    }

    fn pick_color(&mut self, pos: Pos2) {
        if let Some(c) = self.canvas.as_mut() {
            let cp = c.view.to_canvas(pos);
            if cp.x >= 0.0 && cp.y >= 0.0 && (cp.x as u32) < c.info.w && (cp.y as u32) < c.info.h {
                let px = c.flatten_rgba();
                let i = ((cp.y as u32 * c.info.w + cp.x as u32) * 4) as usize;
                if px[i + 3] > 0 {
                    self.ui.color = [px[i] as f32 / 255.0, px[i + 1] as f32 / 255.0, px[i + 2] as f32 / 255.0];
                    self.ui.push_recent();
                }
            }
        }
    }

    // ---------- Souris (ordinateur) ----------
    fn on_mouse(&mut self, ev: &WindowEvent) -> bool {
        if self.in_gallery {
            if let WindowEvent::CursorMoved { position, .. } = ev {
                let ppp = self.ppp();
                self.mouse_pos = Pos2::new(position.x as f32 / ppp, position.y as f32 / ppp);
            }
            return false;
        }
        let touch_recent = self.last_touch.elapsed() < Duration::from_millis(600);
        let over_ui = self.is_ui(self.mouse_pos) || self.egui_ctx.egui_wants_pointer_input();
        match ev {
            WindowEvent::CursorMoved { position, .. } => {
                let ppp = self.ppp();
                self.mouse_pos = Pos2::new(position.x as f32 / ppp, position.y as f32 / ppp);
                if self.lasso.is_some() && self.mouse_drawing {
                    let p = self.mouse_pos;
                    self.lasso_input(TouchPhase::Moved, p);
                } else if self.mouse_drawing && self.canvas.as_ref().is_some_and(|c| c.xform.is_some()) {
                    let pos = self.mouse_pos;
                    self.transform_touch(u64::MAX, TouchPhase::Moved, pos);
                } else if self.mouse_drawing {
                    let p = self.mouse_pos;
                    if self.ui.eyedropper {
                        self.pick_color(p);
                    } else {
                        self.stroke_point(p, 1.0);
                    }
                }
                if let Some(last) = self.mouse_pan {
                    let d = self.mouse_pos - last;
                    if let Some(c) = self.canvas.as_mut() {
                        c.view.offset += d;
                    }
                    self.mouse_pan = Some(self.mouse_pos);
                }
                false
            }
            WindowEvent::MouseInput { state, button, .. } => {
                match (button, state) {
                    (MouseButton::Left, ElementState::Pressed) if !over_ui && !touch_recent => {
                        if self.ui.fx.is_some() {
                            return true;
                        }
                        if self.canvas.as_ref().is_some_and(|c| c.xform.is_some()) {
                            self.mouse_drawing = true;
                            let p = self.mouse_pos;
                            self.transform_touch(u64::MAX, TouchPhase::Started, p);
                            return true;
                        }
                        if self.ui.panel == Some(ui::Panel::Select) {
                            self.mouse_drawing = true;
                            let p = self.mouse_pos;
                            self.lasso_input(TouchPhase::Started, p);
                            return true;
                        }
                        self.ui.panel = None;
                        self.mouse_drawing = true;
                        let p = self.mouse_pos;
                        if self.ui.eyedropper {
                            self.pick_color(p);
                        } else {
                            self.begin_stroke(p, 1.0);
                        }
                        return true;
                    }
                    (MouseButton::Left, ElementState::Released) if self.mouse_drawing => {
                        self.mouse_drawing = false;
                        if self.lasso.is_some() {
                            let p = self.mouse_pos;
                            self.lasso_input(TouchPhase::Ended, p);
                            return true;
                        }
                        if self.canvas.as_ref().is_some_and(|c| c.xform.is_some()) {
                            let p = self.mouse_pos;
                            self.transform_touch(u64::MAX, TouchPhase::Ended, p);
                            return true;
                        }
                        if self.ui.eyedropper {
                            self.ui.eyedropper = false;
                        } else {
                            self.end_stroke();
                        }
                        return true;
                    }
                    (MouseButton::Middle | MouseButton::Right, ElementState::Pressed) if !over_ui => {
                        self.mouse_pan = Some(self.mouse_pos);
                        return true;
                    }
                    (MouseButton::Middle | MouseButton::Right, ElementState::Released) => {
                        self.mouse_pan = None;
                    }
                    _ => {}
                }
                false
            }
            WindowEvent::MouseWheel { delta, .. } if !over_ui => {
                let dy = match delta {
                    MouseScrollDelta::LineDelta(_, y) => *y,
                    MouseScrollDelta::PixelDelta(p) => p.y as f32 / 60.0,
                };
                let m = self.mouse_pos;
                if let Some(c) = self.canvas.as_mut() {
                    let k = c.view.to_canvas(m);
                    c.view.scale = (c.view.scale * 1.15f32.powf(dy)).clamp(0.02, 64.0);
                    let p = c.view.to_screen(k);
                    c.view.offset += m - p;
                }
                true
            }
            _ => false,
        }
    }

    fn on_key(&mut self, ev: &winit::event::KeyEvent) {
        use winit::keyboard::{Key, NamedKey};
        if ev.state != ElementState::Pressed || self.egui_ctx.egui_wants_keyboard_input() {
            return;
        }
        let m = self.egui_ctx.input(|i| i.modifiers);
        match &ev.logical_key {
            Key::Character(s) => match s.to_lowercase().as_str() {
                "z" if m.command && m.shift => {
                    self.canvas.as_mut().map(|c| c.redo());
                }
                "z" if m.command => {
                    self.canvas.as_mut().map(|c| c.undo());
                }
                "y" if m.command => {
                    self.canvas.as_mut().map(|c| c.redo());
                }
                "s" if m.command => self.save_now(),
                "b" => self.ui.tool = Tool::Brush,
                "e" => self.ui.tool = Tool::Eraser,
                "s" => self.ui.tool = Tool::Smudge,
                "[" => self.ui.bump_size(-0.04),
                "]" => self.ui.bump_size(0.04),
                "0" if m.command => self.needs_fit = true,
                _ => {}
            },
            Key::Named(NamedKey::Escape) | Key::Named(NamedKey::GoBack) | Key::Named(NamedKey::BrowserBack) => {
                if self.ui.panel.is_some() {
                    self.ui.panel = None;
                } else if !self.in_gallery {
                    self.go_gallery();
                }
            }
            _ => {}
        }
    }

    /// Rend quelques aperçus de pinceaux manquants (catégorie affichée) à chaque image.
    fn render_previews(&mut self) {
        if self.in_gallery || self.ui.panel != Some(ui::Panel::Brushes) {
            return;
        }
        let Some(rs) = self.painter.as_ref().and_then(|p| p.render_state()) else { return };
        let srgb = rs.adapter.get_downlevel_capabilities().flags.contains(wgpu::DownlevelFlags::VIEW_FORMATS);
        let cat = self.ui.brush_cat.clone();
        let todo: Vec<usize> = self
            .brushes
            .iter()
            .enumerate()
            .filter(|(_, b)| (cat.is_empty() || b.cat == cat) && !self.ui.previews.contains_key(&b.id))
            .map(|(i, _)| i)
            .collect();
        if todo.is_empty() {
            return;
        }
        let t0 = Instant::now();
        for i in todo.iter().copied() {
            let b = &self.brushes[i];
            let px = self.previews.render(&rs.device, &rs.queue, srgb, b);
            let img = egui::ColorImage::from_rgba_premultiplied([crate::preview::W as usize, crate::preview::H as usize], &px);
            let h = self.egui_ctx.load_texture(format!("apercu-{}", b.id), img, egui::TextureOptions::LINEAR);
            self.ui.previews.insert(b.id.clone(), h);
            if t0.elapsed() > Duration::from_millis(30) {
                break;
            }
        }
        if let Some(w) = &self.window {
            w.request_redraw();
        }
    }

    fn redraw(&mut self) {
        let Some(window) = self.window.clone() else { return };
        if self.painter.as_ref().and_then(|p| p.render_state()).is_none() {
            return;
        }
        if self.canvas.is_none() && !self.in_gallery {
            self.in_gallery = true;
        }
        let picked = crate::platform::take_picked();
        if !picked.is_empty() {
            log::info!("fichiers reçus : {picked:?}");
        }
        for path in picked {
            self.import_file(&path);
        }
        let screen = self.screen_rect();
        if self.needs_fit {
            if let Some(c) = self.canvas.as_mut() {
                c.fit(screen);
            }
            self.needs_fit = false;
        }
        // QuickShape : trait maintenu immobile -> forme parfaite
        let drawing = self.pen.is_some() || self.mouse_drawing || matches!(self.gesture, Gesture::DrawFinger { .. });
        if let Some(c) = self.canvas.as_mut() {
            if c.stroke_active() && drawing && self.ui.quickshape {
                if self.qs_time.elapsed() > Duration::from_millis(600) {
                    if c.quickshape() {
                        self.ui.toast("Forme rapide".into());
                    }
                } else {
                    let t = self.qs_time + Duration::from_millis(620);
                    self.next_repaint = Some(self.next_repaint.map_or(t, |n| n.min(t)));
                }
            }
            c.render();
        }

        self.render_previews();
        let raw = self.egui_state.as_mut().unwrap().take_egui_input(&window);
        let ctx = self.egui_ctx.clone();
        let mut actions = Vec::new();
        let full = ctx.run_ui(raw, |ui_root| {
            let ctx = ui_root.ctx().clone();
            let upd = self.update.lock().unwrap().clone();
            if self.in_gallery {
                actions = ui::gallery_screen(&ctx, &mut self.ui, upd.as_ref());
            } else {
                if let (Some(c), Some(ids)) = (self.canvas.as_ref(), self.display_ids) {
                    ui::paint_canvas(&ctx, c, ids);
                    if let Some(l) = &self.lasso {
                        ui::paint_lasso(&ctx, c, l);
                    }
                }
                actions = ui::build(&ctx, &mut self.ui, self.canvas.as_mut(), &self.brushes, upd.as_ref());
            }
        });
        for a in actions {
            self.do_action(a);
        }
        self.egui_state.as_mut().unwrap().handle_platform_output(&window, full.platform_output);
        let prims = ctx.tessellate(full.shapes, full.pixels_per_point);
        let mut tex = full.textures_delta;
        // vignettes des calques : enregistre les nouvelles textures
        self.sync_thumbs();
        let clear = [0.17, 0.17, 0.18, 1.0];
        if let Some(p) = self.painter.as_mut() {
            p.paint_and_update_textures(ViewportId::ROOT, full.pixels_per_point, clear, &prims, &mut tex, vec![], &window);
        }
        let repaint = full.viewport_output.get(&ViewportId::ROOT).map(|v| v.repaint_delay).unwrap_or(Duration::MAX);
        if repaint.is_zero() {
            window.request_redraw();
        } else if repaint < Duration::from_secs(3600) {
            self.next_repaint = Some(Instant::now() + repaint);
        }
        // enregistrement automatique, 3 s après la dernière modification
        if let Some(c) = self.canvas.as_mut() {
            if c.unsaved && !c.stroke_active() {
                if c.last_change.elapsed() > Duration::from_secs(3) {
                    c.save(&self.cur_path.clone().unwrap_or_else(|| doc::drawings_dir().join("courant.yujin")), true);
                    self.ui.save();
                    self.last_save = Instant::now();
                } else {
                    let t = c.last_change + Duration::from_millis(3200);
                    self.next_repaint = Some(self.next_repaint.map_or(t, |n| n.min(t)));
                }
            }
        }
    }

    /// Ouvre un fichier choisi ou partagé avec l'appli (pinceaux, palettes, dessins, images).
    pub fn import_file(&mut self, path: &std::path::Path) {
        let name = path.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_default();
        let lower = name.to_lowercase();
        let Ok(data) = crate::fs::read(path) else {
            self.ui.toast(format!("Impossible de lire {name}"));
            return;
        };
        if lower.ends_with(".brush") || lower.ends_with(".brushset") {
            match crate::library::import(&mut self.brushes, &data, &name) {
                Ok((cat, n)) => {
                    self.ui.toast(format!("{n} pinceau(x) importé(s) dans « {cat} »"));
                    self.ui.brush_cat_set(&cat);
                }
                Err(e) => self.ui.toast(format!("Import des pinceaux impossible : {e}")),
            }
        } else if lower.ends_with(".swatches") {
            match crate::procreate::import_swatches(&data, &name) {
                Ok(p) => {
                    let n = p.len();
                    self.ui.palettes.extend(p);
                    self.ui.save();
                    self.ui.toast(format!("{n} palette(s) importée(s)"));
                }
                Err(e) => self.ui.toast(format!("Import de la palette impossible : {e}")),
            }
        } else if lower.ends_with(".procreate") {
            match crate::procreate::import_procreate(&data, &name) {
                Ok(d) => {
                    let mut info = DocInfo::new(d.w, d.h);
                    info.name = d.name.clone();
                    info.bg = d.bg;
                    info.bg_visible = d.bg_visible;
                    info.layers = d.layers.iter().map(|l| doc::LayerInfo { name: l.name.clone(), visible: l.visible, opacity: l.opacity, mode: l.mode, lock_alpha: l.lock_alpha }).collect();
                    info.counter = info.layers.len() as u32;
                    info.active = info.layers.len().saturating_sub(1);
                    let px: Vec<Vec<u8>> = d.layers.into_iter().map(|l| l.px).collect();
                    if info.layers.is_empty() {
                        info.layers.push(doc::LayerInfo::new("Calque 1"));
                    }
                    let px = if px.is_empty() { None } else { Some(px) };
                    self.open_new(info, px);
                    self.ui.toast(format!("« {} » importé", d.name));
                }
                Err(e) => self.ui.toast(format!("Import du dessin impossible : {e}")),
            }
        } else if let Some((w, h, mut px)) = doc::decode_image(&data) {
            doc::premultiply(&mut px);
            if self.canvas.is_none() || self.in_gallery {
                // depuis la galerie : nouvelle toile à la taille de la photo
                let max = self.max_side().min(4096) as f32;
                let k = (max / w.max(h) as f32).min(1.0);
                let mut info = DocInfo::new(((w as f32 * k) as u32).max(16), ((h as f32 * k) as u32).max(16));
                info.name = name.rsplit_once('.').map(|(a, _)| a.to_string()).unwrap_or(name.clone());
                self.open_new(info, None);
            }
            // image : nouveau calque, centrée et réduite si besoin
            if let Some(c) = self.canvas.as_mut() {
                c.add_image_layer(&name, w, h, &px);
                self.ui.toast("Image ajoutée dans un nouveau calque".into());
            }
        } else {
            self.ui.toast(format!("Format non pris en charge : {name}"));
        }
    }

    fn sync_thumbs(&mut self) {
        let Some(rs) = self.painter.as_ref().and_then(|p| p.render_state()) else { return };
        let Some(c) = self.canvas.as_mut() else { return };
        let mut r = rs.renderer.write();
        for (i, t) in c.thumbs.iter_mut().enumerate() {
            if t.is_none() {
                *t = Some(r.register_native_texture(&rs.device, &c.engine.layers[i].srgb_view, wgpu::FilterMode::Linear));
            }
        }
    }

    fn do_action(&mut self, a: ui::Action) {
        match a {
            ui::Action::NewCanvas(w, h) => self.open_new(DocInfo::new(w, h), None),
            ui::Action::Open(path) => self.open_path(&path),
            ui::Action::Gallery => self.go_gallery(),
            ui::Action::DeleteDrawings(paths) => {
                for p in paths {
                    let _ = crate::fs::remove(&p);
                }
                self.ui.invalidate_gallery();
            }
            ui::Action::DuplicateDrawings(paths) => {
                for p in paths {
                    if let Some((mut info, px)) = doc::load(&p) {
                        info.name = format!("{} copie", info.name);
                        let thumb = doc::read_thumb(&p);
                        let _ = doc::save(&doc::new_drawing_path(), &info, px, thumb);
                    }
                }
                self.ui.invalidate_gallery();
            }
            ui::Action::Rename(path, name) => {
                if let Some((mut info, px)) = doc::load(&path) {
                    info.name = name;
                    let thumb = doc::read_thumb(&path);
                    let _ = doc::save(&path, &info, px, thumb);
                }
                self.ui.invalidate_gallery();
            }
            ui::Action::Fit => self.needs_fit = true,
            ui::Action::OpenUrl(u) => crate::platform::open_url(&u),
            ui::Action::Restart => {
                self.save_now();
                crate::updater::restart();
            }
            ui::Action::DismissUpdate => *self.update.lock().unwrap() = None,
            ui::Action::PickFiles => {
                if let Err(e) = crate::platform::pick_files() {
                    self.ui.toast(format!("Impossible d'ouvrir le sélecteur de fichiers : {e}"));
                }
            }
            ui::Action::DeleteBrush(id) => crate::library::delete(&mut self.brushes, &id),
            ui::Action::Save => self.save_now(),
            ui::Action::Export(kind) => {
                if let Some(c) = self.canvas.as_mut() {
                    let (w, h) = (c.info.w, c.info.h);
                    let flat = c.flatten_rgba();
                    let res: Result<(Vec<u8>, &str, &str), String> = match kind {
                        "jpeg" => {
                            let rgb: Vec<u8> = flat
                                .chunks_exact(4)
                                .flat_map(|p| {
                                    let a = p[3] as f32 / 255.0;
                                    [0, 1, 2].map(|k| (p[k] as f32 * a + 255.0 * (1.0 - a)).round() as u8)
                                })
                                .collect();
                            let mut out = Vec::new();
                            image::codecs::jpeg::JpegEncoder::new_with_quality(&mut out, 93)
                                .encode(&rgb, w, h, image::ExtendedColorType::Rgb8)
                                .map(|_| (out, "jpg", "image/jpeg"))
                                .map_err(|e| e.to_string())
                        }
                        "psd" => {
                            let layers: Vec<Vec<u8>> = (0..c.info.layers.len())
                                .map(|i| {
                                    let mut px = c.engine.read_layer(i);
                                    doc::unpremultiply(&mut px);
                                    px
                                })
                                .collect();
                            Ok((crate::psd::write(&c.info, &layers, &flat), "psd", "image/vnd.adobe.photoshop"))
                        }
                        _ => Ok((doc::encode_png(w, h, &flat), "png", "image/png")),
                    };
                    match res {
                        Ok((data, ext, mime)) => {
                            let name = format!("{}.{ext}", c.info.name);
                            match crate::platform::save_export(&name, mime, &data) {
                                Ok(where_) => self.ui.toast(format!("Enregistré : {where_}")),
                                Err(e) => self.ui.toast(format!("Échec de l'export : {e}")),
                            }
                        }
                        Err(e) => self.ui.toast(format!("Échec de l'export : {e}")),
                    }
                }
            }
            ui::Action::Fullscreen => {
                if let Some(w) = &self.window {
                    let on = w.fullscreen().is_some();
                    w.set_fullscreen(if on { None } else { Some(winit::window::Fullscreen::Borderless(None)) });
                }
            }
        }
    }
}

impl App {
    /// Termine la préparation une fois le moteur graphique prêt.
    fn finish_setup(&mut self) {
        #[cfg(target_arch = "wasm32")]
        if self.painter.is_none() {
            if let Some(p) = self.pending_painter.borrow_mut().take() {
                self.painter = Some(p);
                self.needs_fit = true;
            }
        }
        let (Some(window), Some(painter)) = (self.window.clone(), self.painter.as_ref()) else { return };
        if self.egui_state.is_none() {
            let max = painter.max_texture_side();
            self.egui_state = Some(egui_winit::State::new(self.egui_ctx.clone(), ViewportId::ROOT, &window, Some(window.scale_factor() as f32), None, max));
        }
        if !self.update_started {
            self.update_started = true;
            let w = window.clone();
            crate::updater::start(self.update.clone(), move || w.request_redraw());
            let w2 = window.clone();
            crate::platform::set_wake(move || w2.request_redraw());
        }
    }
}

impl ApplicationHandler for App {
    fn resumed(&mut self, el: &ActiveEventLoop) {
        if self.window.is_none() {
            let (ww, wh) = std::env::var("YS_WINDOW").ok().and_then(|v| v.split_once('x').and_then(|(a, b)| Some((a.parse().ok()?, b.parse().ok()?)))).unwrap_or((1280.0, 820.0));
            #[allow(unused_mut)]
            let mut attrs = Window::default_attributes().with_title("Yujin Studio").with_inner_size(winit::dpi::LogicalSize::new(ww, wh));
            #[cfg(not(target_arch = "wasm32"))]
            if let Some((w, h, px)) = doc::decode_png(include_bytes!("../assets/icon.png")) {
                attrs = attrs.with_window_icon(winit::window::Icon::from_rgba(px, w, h).ok());
            }
            #[cfg(target_arch = "wasm32")]
            {
                use winit::platform::web::WindowAttributesExtWebSys;
                attrs = attrs.with_append(true).with_prevent_default(true).with_focusable(true);
            }
            let window = Arc::new(el.create_window(attrs).expect("fenêtre"));
            self.window = Some(window.clone());
        }
        let window = self.window.clone().unwrap();
        #[cfg(not(target_arch = "wasm32"))]
        {
            if self.painter.is_none() {
                let mut cfg = egui_wgpu::WgpuConfiguration::default();
                if let egui_wgpu::WgpuSetup::CreateNew(cn) = &mut cfg.wgpu_setup {
                    cn.display_handle = Some(Box::new(el.owned_display_handle()));
                }
                let painter = pollster::block_on(egui_wgpu::winit::Painter::new(self.egui_ctx.clone(), cfg, false, egui_wgpu::RendererOptions::default()));
                self.painter = Some(painter);
            }
            if let Err(e) = pollster::block_on(self.painter.as_mut().unwrap().set_window(ViewportId::ROOT, Some(window.clone()))) {
                log::error!("set_window : {e}");
            }
            self.finish_setup();
        }
        #[cfg(target_arch = "wasm32")]
        {
            if !self.painter_requested {
                self.painter_requested = true;
                let mut cfg = egui_wgpu::WgpuConfiguration::default();
                if let egui_wgpu::WgpuSetup::CreateNew(cn) = &mut cfg.wgpu_setup {
                    cn.display_handle = Some(Box::new(el.owned_display_handle()));
                    // WebGL2 : la lecture des pixels reste synchrone (enregistrement, aperçus)
                    cn.instance_descriptor.backends = wgpu::Backends::GL;
                }
                let ctx = self.egui_ctx.clone();
                let slot = self.pending_painter.clone();
                let w = window.clone();
                wasm_bindgen_futures::spawn_local(async move {
                    let mut p = egui_wgpu::winit::Painter::new(ctx, cfg, false, egui_wgpu::RendererOptions::default()).await;
                    if let Err(e) = p.set_window(ViewportId::ROOT, Some(w.clone())).await {
                        log::error!("set_window : {e}");
                        crate::web_error(&format!("Le moteur graphique (WebGL2) n'a pas pu démarrer : {e}"));
                    }
                    *slot.borrow_mut() = Some(p);
                    w.request_redraw();
                });
            }
        }
        window.request_redraw();
    }

    fn about_to_wait(&mut self, el: &ActiveEventLoop) {
        match self.next_repaint {
            Some(t) if t <= Instant::now() => {
                self.next_repaint = None;
                if let Some(w) = &self.window {
                    w.request_redraw();
                }
                el.set_control_flow(ControlFlow::Wait);
            }
            Some(t) => el.set_control_flow(ControlFlow::WaitUntil(t)),
            None => el.set_control_flow(ControlFlow::Wait),
        }
    }

    fn suspended(&mut self, _el: &ActiveEventLoop) {
        self.save_now();
        #[cfg(not(target_arch = "wasm32"))]
        if let Some(p) = self.painter.as_mut() {
            let _ = pollster::block_on(p.set_window(ViewportId::ROOT, None));
        }
    }

    fn window_event(&mut self, el: &ActiveEventLoop, _id: WindowId, event: WindowEvent) {
        let Some(window) = self.window.clone() else { return };
        #[cfg(target_arch = "wasm32")]
        if self.egui_state.is_none() {
            self.finish_setup();
            if self.egui_state.is_none() {
                return;
            }
        }
        let mut forward = true;
        match &event {
            WindowEvent::CloseRequested => {
                self.save_now();
                el.exit();
                return;
            }
            WindowEvent::Resized(s) => {
                if let (Some(p), Some(w), Some(h)) = (self.painter.as_mut(), std::num::NonZeroU32::new(s.width), std::num::NonZeroU32::new(s.height)) {
                    p.on_window_resized(ViewportId::ROOT, w, h);
                }
            }
            WindowEvent::Touch(t) => {
                if self.on_touch(t) {
                    forward = false;
                }
            }
            WindowEvent::CursorMoved { .. } | WindowEvent::MouseInput { .. } | WindowEvent::MouseWheel { .. } => {
                if self.on_mouse(&event) {
                    forward = false;
                }
            }
            WindowEvent::KeyboardInput { event: k, .. } => self.on_key(k),
            WindowEvent::RedrawRequested => {
                self.redraw();
                return;
            }
            _ => {}
        }
        if forward {
            if let Some(s) = self.egui_state.as_mut() {
                let _ = s.on_window_event(&window, &event);
            }
        }
        window.request_redraw();
    }
}

pub fn run(event_loop: EventLoop<()>) {
    event_loop.set_control_flow(ControlFlow::Wait);
    #[cfg(target_arch = "wasm32")]
    {
        use winit::platform::web::EventLoopExtWebSys;
        event_loop.spawn_app(App::new());
    }
    #[cfg(not(target_arch = "wasm32"))]
    {
        let mut app = App::new();
        if let Err(e) = event_loop.run_app(&mut app) {
            log::error!("boucle : {e}");
        }
    }
}
