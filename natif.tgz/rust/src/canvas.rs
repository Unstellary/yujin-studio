//! Toile : document + moteur GPU + annulation + trait en cours + vue (zoom, rotation).

use crate::brush::{self, Brush, Point, StrokeBuilder};
use crate::doc::{self, DocInfo, LayerInfo};
use crate::gpu::{Engine, GpuLayer, LayerDraw, StrokeState, Tip, UndoRegion};
use egui::{Pos2, Vec2};

pub enum UndoOp {
    Region(UndoRegion),
    Add { index: usize },
    Delete { index: usize, info: LayerInfo, gpu: GpuLayer },
    Move { from: usize, to: usize },
    Props { index: usize, info: LayerInfo },
    Group(Vec<UndoOp>),
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Tool {
    Brush,
    Eraser,
}

#[derive(Clone, Copy, Debug)]
pub struct View {
    pub offset: Vec2,
    pub scale: f32,
    pub rot: f32,
}

impl View {
    pub fn to_screen(&self, c: Pos2) -> Pos2 {
        let (s, co) = self.rot.sin_cos();
        let x = c.x * self.scale;
        let y = c.y * self.scale;
        Pos2::new(self.offset.x + x * co - y * s, self.offset.y + x * s + y * co)
    }
    pub fn to_canvas(&self, p: Pos2) -> Pos2 {
        let (s, co) = self.rot.sin_cos();
        let x = p.x - self.offset.x;
        let y = p.y - self.offset.y;
        Pos2::new((x * co + y * s) / self.scale, (-x * s + y * co) / self.scale)
    }
}

pub struct Canvas {
    pub engine: Engine,
    pub info: DocInfo,
    pub thumbs: Vec<Option<egui::TextureId>>,
    pub undo: Vec<UndoOp>,
    pub redo: Vec<UndoOp>,
    pub version: u64,
    pub dirty: bool,
    pub unsaved: bool,
    pub view: View,
    pub last_change: std::time::Instant,
    tips: Vec<Tip>,
    stroke: Option<(StrokeBuilder, StrokeState, usize, Point)>,
}

const MAX_UNDO: usize = 60;

impl Canvas {
    pub fn new(engine: Engine, info: DocInfo, layers_px: Option<Vec<Vec<u8>>>) -> Self {
        let mut c = Canvas {
            engine,
            info,
            thumbs: Vec::new(),
            undo: Vec::new(),
            redo: Vec::new(),
            version: 1,
            dirty: true,
            unsaved: false,
            view: View { offset: Vec2::ZERO, scale: 1.0, rot: 0.0 },
            last_change: std::time::Instant::now(),
            tips: Vec::new(),
            stroke: None,
        };
        for _ in 0..c.info.layers.len() {
            let l = c.engine.new_layer();
            c.engine.layers.push(l);
            c.thumbs.push(None);
        }
        if let Some(px) = layers_px {
            for (i, p) in px.iter().enumerate() {
                c.engine.write_layer(i, p);
            }
        }
        for shape in [brush::Shape::Hard, brush::Shape::Soft, brush::Shape::Pencil, brush::Shape::Chalk] {
            let levels = brush::make_tip(shape);
            c.tips.push(c.engine.make_tip(brush::TIP, &levels));
        }
        c.info.active = c.info.active.min(c.info.layers.len().saturating_sub(1));
        c
    }

    fn tip_index(shape: brush::Shape) -> usize {
        match shape {
            brush::Shape::Hard => 0,
            brush::Shape::Soft => 1,
            brush::Shape::Pencil => 2,
            brush::Shape::Chalk => 3,
        }
    }

    pub fn fit(&mut self, screen: egui::Rect) {
        // laisse la place à la barre du haut et à la barre latérale
        let screen = egui::Rect::from_min_max(screen.min + Vec2::new(90.0, 56.0), screen.max - Vec2::new(10.0, 6.0));
        let m = 10.0;
        let s = ((screen.width() - 2.0 * m) / self.info.w as f32).min((screen.height() - 2.0 * m) / self.info.h as f32);
        self.view.scale = s.max(0.01);
        self.view.rot = 0.0;
        let size = Vec2::new(self.info.w as f32, self.info.h as f32) * self.view.scale;
        self.view.offset = (screen.center() - size / 2.0).to_vec2();
    }

    fn draws(&self) -> Vec<LayerDraw> {
        self.info
            .layers
            .iter()
            .enumerate()
            .map(|(i, l)| LayerDraw { index: i, visible: l.visible, opacity: l.opacity, mode: l.mode, lock_alpha: l.lock_alpha })
            .collect()
    }

    pub fn changed(&mut self) {
        self.last_change = std::time::Instant::now();
        self.version += 1;
        self.dirty = true;
        self.unsaved = true;
    }

    /// Met à jour l'image affichée si besoin.
    pub fn render(&mut self) {
        if !self.dirty || self.info.layers.is_empty() {
            return;
        }
        let draws = self.draws();
        let st = self.stroke.as_ref().map(|s| s.1);
        let bg = if self.info.bg_visible { Some(self.info.bg) } else { None };
        self.engine.compose(bg, &draws, self.info.active, st, self.version);
        self.dirty = false;
    }

    // ---------- Trait ----------
    pub fn stroke_active(&self) -> bool {
        self.stroke.is_some()
    }

    pub fn begin_stroke(&mut self, b: &Brush, size: f32, opacity: f32, color: [f32; 3], tool: Tool, curve: f32, p: Point) {
        if self.info.layers.is_empty() || !self.info.layers[self.info.active].visible {
            return;
        }
        self.engine.begin_stroke();
        let st = StrokeState { color, opacity, erase: tool == Tool::Eraser };
        let mut sb = StrokeBuilder::new(b.clone(), size, curve);
        let dabs = sb.add(p);
        let tip = &self.tips[Self::tip_index(b.shape)];
        self.engine.stamp(tip, &dabs);
        self.stroke = Some((sb, st, Self::tip_index(b.shape), p));
        self.dirty = true;
    }

    pub fn add_point(&mut self, p: Point) {
        if let Some((sb, _, ti, last)) = self.stroke.as_mut() {
            let dabs = sb.add(p);
            *last = p;
            let ti = *ti;
            self.engine.stamp(&self.tips[ti], &dabs);
            self.dirty = true;
        }
    }

    pub fn cancel_stroke(&mut self) {
        if self.stroke.take().is_some() {
            self.engine.clear_stroke();
            self.engine.stroke_bbox = None;
            self.dirty = true;
        }
    }

    pub fn end_stroke(&mut self) {
        let Some((mut sb, st, ti, last)) = self.stroke.take() else { return };
        let dabs = sb.finish(last);
        self.engine.stamp(&self.tips[ti], &dabs);
        let a = self.info.active;
        if let Some(rect) = self.engine.stroke_rect() {
            let before = self.engine.save_region(a, rect);
            let d = self.draws()[a];
            self.engine.commit_stroke(a, &d, st);
            self.push_undo(UndoOp::Region(before));
            self.changed();
        } else {
            self.engine.clear_stroke();
            self.dirty = true;
        }
    }

    // ---------- Annuler / rétablir ----------
    pub fn push_undo(&mut self, op: UndoOp) {
        self.undo.push(op);
        if self.undo.len() > MAX_UNDO {
            self.undo.remove(0);
        }
        self.redo.clear();
    }

    fn apply(&mut self, op: UndoOp) -> UndoOp {
        match op {
            UndoOp::Region(r) => UndoOp::Region(self.engine.swap_region(r)),
            UndoOp::Add { index } => {
                let gpu = self.engine.layers.remove(index);
                let info = self.info.layers.remove(index);
                self.thumbs.remove(index);
                if self.info.active >= self.info.layers.len() {
                    self.info.active = self.info.layers.len().saturating_sub(1);
                }
                UndoOp::Delete { index, info, gpu }
            }
            UndoOp::Delete { index, info, gpu } => {
                self.engine.layers.insert(index, gpu);
                self.info.layers.insert(index, info);
                self.thumbs.insert(index, None);
                self.info.active = index;
                UndoOp::Add { index }
            }
            UndoOp::Move { from, to } => {
                self.move_layer_raw(from, to);
                UndoOp::Move { from: to, to: from }
            }
            UndoOp::Props { index, info } => {
                let old = std::mem::replace(&mut self.info.layers[index], info);
                UndoOp::Props { index, info: old }
            }
            UndoOp::Group(v) => {
                // les opérations d'un groupe s'appliquent de la dernière à la première
                let inv: Vec<UndoOp> = v.into_iter().rev().map(|o| self.apply(o)).collect();
                UndoOp::Group(inv)
            }
        }
    }

    pub fn undo(&mut self) -> bool {
        if self.stroke.is_some() {
            return false;
        }
        if let Some(op) = self.undo.pop() {
            let inv = self.apply(op);
            self.redo.push(inv);
            self.engine.invalidate();
            self.changed();
            true
        } else {
            false
        }
    }

    pub fn redo(&mut self) -> bool {
        if self.stroke.is_some() {
            return false;
        }
        if let Some(op) = self.redo.pop() {
            let inv = self.apply(op);
            self.undo.push(inv);
            self.engine.invalidate();
            self.changed();
            true
        } else {
            false
        }
    }

    // ---------- Calques ----------
    fn move_layer_raw(&mut self, from: usize, to: usize) {
        let g = self.engine.layers.remove(from);
        self.engine.layers.insert(to, g);
        let i = self.info.layers.remove(from);
        self.info.layers.insert(to, i);
        let t = self.thumbs.remove(from);
        self.thumbs.insert(to, t);
        let a = self.info.active;
        self.info.active = if a == from {
            to
        } else if from < a && to >= a {
            a - 1
        } else if from > a && to <= a {
            a + 1
        } else {
            a
        };
    }

    pub fn add_layer(&mut self) {
        self.info.counter += 1;
        let name = format!("Calque {}", self.info.counter);
        let index = (self.info.active + 1).min(self.info.layers.len());
        let g = self.engine.new_layer();
        self.engine.layers.insert(index, g);
        self.info.layers.insert(index, LayerInfo::new(&name));
        self.thumbs.insert(index, None);
        self.info.active = index;
        self.push_undo(UndoOp::Add { index });
        self.engine.invalidate();
        self.changed();
    }

    pub fn delete_layer(&mut self, index: usize) {
        if self.info.layers.len() <= 1 {
            self.engine.clear_layer(0);
            self.changed();
            return;
        }
        let op = self.apply(UndoOp::Add { index });
        self.push_undo(op);
        self.engine.invalidate();
        self.changed();
    }

    pub fn duplicate_layer(&mut self, index: usize) {
        let g = self.engine.new_layer();
        self.engine.layers.insert(index + 1, g);
        let mut info = self.info.layers[index].clone();
        info.name = format!("{} copie", info.name);
        self.info.layers.insert(index + 1, info);
        self.thumbs.insert(index + 1, None);
        self.engine.copy_layer(index, index + 1);
        self.info.active = index + 1;
        self.push_undo(UndoOp::Add { index: index + 1 });
        self.changed();
    }

    pub fn move_layer(&mut self, from: usize, to: usize) {
        if from == to || to >= self.info.layers.len() {
            return;
        }
        self.move_layer_raw(from, to);
        self.push_undo(UndoOp::Move { from: to, to: from });
        self.engine.invalidate();
        self.changed();
    }

    /// Modifie les réglages d'un calque (avec annulation).
    pub fn set_props(&mut self, index: usize, f: impl FnOnce(&mut LayerInfo)) {
        let old = self.info.layers[index].clone();
        f(&mut self.info.layers[index]);
        // regroupe les réglages successifs du même calque (ex. glisser l'opacité)
        let merge = matches!(self.undo.last(), Some(UndoOp::Props { index: i, .. }) if *i == index);
        if !merge {
            self.push_undo(UndoOp::Props { index, info: old });
        }
        self.engine.invalidate();
        self.changed();
    }

    pub fn merge_down(&mut self, index: usize) {
        if index == 0 {
            return;
        }
        let lower = index - 1;
        let region = self.engine.save_region(lower, (0, 0, self.info.w, self.info.h));
        let d = self.draws()[index];
        self.engine.merge_down(&d, lower);
        // supprime le calque du dessus (annulable)
        let del = self.apply(UndoOp::Add { index });
        self.info.active = lower;
        self.push_undo(UndoOp::Group(vec![UndoOp::Region(region), del]));
        self.engine.invalidate();
        self.changed();
    }

    pub fn clear_active(&mut self) {
        let a = self.info.active;
        let region = self.engine.save_region(a, (0, 0, self.info.w, self.info.h));
        self.engine.clear_layer(a);
        self.push_undo(UndoOp::Region(region));
        self.changed();
    }

    // ---------- Enregistrement ----------
    /// Lit les pixels sur la carte graphique puis écrit le fichier (en arrière-plan si `background`).
    pub fn save(&mut self, path: &std::path::Path, background: bool) {
        let px: Vec<Vec<u8>> = (0..self.info.layers.len()).map(|i| self.engine.read_layer(i)).collect();
        self.dirty = true;
        self.render();
        let disp = self.engine.read_display();
        let info = self.info.clone();
        let path = path.to_path_buf();
        self.unsaved = false;
        let job = move || {
            let mut disp = disp;
            doc::unpremultiply(&mut disp);
            let thumb = thumb_png(info.w, info.h, &disp, 512);
            if let Err(e) = doc::save(&path, &info, px, Some(thumb)) {
                log::error!("enregistrement impossible : {e}");
            }
        };
        static LOCK: std::sync::Mutex<()> = std::sync::Mutex::new(());
        if background {
            std::thread::spawn(move || {
                let _g = LOCK.lock();
                job();
            });
        } else {
            let _g = LOCK.lock();
            job();
        }
    }

    /// Image finale (non prémultipliée) pour l'export.
    pub fn flatten_rgba(&mut self) -> Vec<u8> {
        self.dirty = true;
        self.render();
        let mut px = self.engine.read_display();
        doc::unpremultiply(&mut px);
        px
    }
}

fn thumb_png(w: u32, h: u32, rgba: &[u8], max: u32) -> Vec<u8> {
    let s = (max as f32 / w.max(h) as f32).min(1.0);
    let tw = ((w as f32 * s) as u32).max(1);
    let th = ((h as f32 * s) as u32).max(1);
    let mut out = vec![0u8; (tw * th * 4) as usize];
    for y in 0..th {
        for x in 0..tw {
            let sx = ((x as f32 + 0.5) / s) as u32;
            let sy = ((y as f32 + 0.5) / s) as u32;
            let si = ((sy.min(h - 1) * w + sx.min(w - 1)) * 4) as usize;
            let di = ((y * tw + x) * 4) as usize;
            out[di..di + 4].copy_from_slice(&rgba[si..si + 4]);
        }
    }
    doc::encode_png(tw, th, &out)
}
