//! Toile : document + moteur GPU + annulation + trait en cours + vue (zoom, rotation).

use crate::brush::{Brush, Point, StrokeBuilder};
use crate::doc::{self, DocInfo, LayerInfo};
use crate::gpu::{Engine, GpuLayer, LayerDraw, StrokeState, Tip, UndoRegion};
use egui::{Pos2, Vec2};

pub enum UndoOp {
    Region(UndoRegion),
    Add { index: usize },
    Delete { index: usize, info: LayerInfo, gpu: GpuLayer },
    Move { from: usize, to: usize },
    Props { index: usize, info: LayerInfo },
    Group(Vec<UndoOp>),
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Tool {
    Brush,
    Smudge,
    Eraser,
}

#[derive(Clone, Copy, Debug)]
pub struct View {
    pub offset: Vec2,
    pub scale: f32,
    pub rot: f32,
}

impl View {
    pub fn to_screen(&self, c: Pos2) -> Pos2 {
        let (s, co) = self.rot.sin_cos();
        let x = c.x * self.scale;
        let y = c.y * self.scale;
        Pos2::new(self.offset.x + x * co - y * s, self.offset.y + x * s + y * co)
    }
    pub fn to_canvas(&self, p: Pos2) -> Pos2 {
        let (s, co) = self.rot.sin_cos();
        let x = p.x - self.offset.x;
        let y = p.y - self.offset.y;
        Pos2::new((x * co + y * s) / self.scale, (-x * s + y * co) / self.scale)
    }
}

/// Transformation en cours du calque actif (autour du centre de la toile).
#[derive(Clone, Copy, Debug)]
pub struct Xform {
    pub tx: f32,
    pub ty: f32,
    pub scale: f32,
    pub rot: f32,
    pub flip_h: bool,
    pub flip_v: bool,
}

impl Default for Xform {
    fn default() -> Self {
        Xform { tx: 0.0, ty: 0.0, scale: 1.0, rot: 0.0, flip_h: false, flip_v: false }
    }
}

pub struct Canvas {
    pub engine: Engine,
    pub info: DocInfo,
    pub thumbs: Vec<Option<egui::TextureId>>,
    pub undo: Vec<UndoOp>,
    pub redo: Vec<UndoOp>,
    pub version: u64,
    pub dirty: bool,
    pub unsaved: bool,
    pub view: View,
    pub last_change: std::time::Instant,
    pub xform: Option<Xform>,
    /// contour de la sélection (coordonnées de la toile) et inversion
    pub selection: Option<(Vec<(f32, f32)>, bool)>,
    tips: std::collections::HashMap<String, Tip>,
    stroke: Option<(StrokeBuilder, StrokeState, String, Point)>,
    /// estompe en cours : (constructeur, clé du pinceau, force, dernier tampon, zone d'annulation)
    smudge: Option<(StrokeBuilder, String, f32, Option<[f32; 2]>, UndoRegion)>,
}

const MAX_UNDO: usize = 60;

impl Canvas {
    pub fn new(engine: Engine, info: DocInfo, layers_px: Option<Vec<Vec<u8>>>) -> Self {
        let mut c = Canvas {
            engine,
            info,
            thumbs: Vec::new(),
            undo: Vec::new(),
            redo: Vec::new(),
            version: 1,
            dirty: true,
            unsaved: false,
            view: View { offset: Vec2::ZERO, scale: 1.0, rot: 0.0 },
            last_change: std::time::Instant::now(),
            xform: None,
            selection: None,
            tips: Default::default(),
            stroke: None,
            smudge: None,
        };
        for _ in 0..c.info.layers.len() {
            let l = c.engine.new_layer();
            c.engine.layers.push(l);
            c.thumbs.push(None);
        }
        if let Some(px) = layers_px {
            for (i, p) in px.iter().enumerate() {
                c.engine.write_layer(i, p);
            }
        }
        c.info.active = c.info.active.min(c.info.layers.len().saturating_sub(1));
        c
    }

    /// Pinceau préparé sur la carte graphique (créé à la première utilisation).
    fn ensure_tip(&mut self, b: &Brush) {
        let key = crate::library::tip_key(b);
        if !self.tips.contains_key(&key) {
            let (tip, grain) = crate::library::masks(b);
            let t = self.engine.make_tip(crate::brush::TIP, &tip, grain.as_deref(), b.grain_scale, b.op_map);
            self.tips.insert(key, t);
        }
    }

    pub fn fit(&mut self, screen: egui::Rect) {
        // laisse la place à la barre du haut et à la barre latérale
        let screen = egui::Rect::from_min_max(screen.min + Vec2::new(90.0, 56.0), screen.max - Vec2::new(10.0, 6.0));
        let m = 10.0;
        let s = ((screen.width() - 2.0 * m) / self.info.w as f32).min((screen.height() - 2.0 * m) / self.info.h as f32);
        self.view.scale = s.max(0.01);
        self.view.rot = 0.0;
        let size = Vec2::new(self.info.w as f32, self.info.h as f32) * self.view.scale;
        self.view.offset = (screen.center() - size / 2.0).to_vec2();
    }

    fn draws(&self) -> Vec<LayerDraw> {
        self.info
            .layers
            .iter()
            .enumerate()
            .map(|(i, l)| LayerDraw { index: i, visible: l.visible, opacity: l.opacity, mode: l.mode, lock_alpha: l.lock_alpha })
            .collect()
    }

    pub fn changed(&mut self) {
        self.last_change = std::time::Instant::now();
        self.version += 1;
        self.dirty = true;
        self.unsaved = true;
    }

    /// Met à jour l'image affichée si besoin.
    pub fn render(&mut self) {
        if !self.dirty || self.info.layers.is_empty() {
            return;
        }
        let draws = self.draws();
        let st = self.stroke.as_ref().map(|s| s.1);
        let bg = if self.info.bg_visible { Some(self.info.bg) } else { None };
        self.engine.compose(bg, &draws, self.info.active, st, self.version);
        self.dirty = false;
    }

    // ---------- Trait ----------
    pub fn stroke_active(&self) -> bool {
        self.stroke.is_some() || self.smudge.is_some()
    }

    fn smudge_apply(&mut self, dabs: Vec<crate::gpu::Dab>) {
        let a = self.info.active;
        let Some((_, key, strength, last, _)) = self.smudge.as_mut() else { return };
        let key = key.clone();
        let strength = *strength;
        let mut prev = *last;
        for d in &dabs {
            let from = prev.unwrap_or(d.pos);
            self.engine.smudge_dab(a, &self.tips[&key], from, d.pos, d.size, strength * d.alpha.max(0.2).min(1.0));
            prev = Some(d.pos);
        }
        if let Some(s) = self.smudge.as_mut() {
            s.3 = prev;
        }
        self.dirty = true;
    }

    pub fn begin_stroke(&mut self, b: &Brush, size: f32, opacity: f32, color: [f32; 3], tool: Tool, curve: f32, p: Point) {
        if self.info.layers.is_empty() || !self.info.layers[self.info.active].visible || self.engine.fx_active() {
            return;
        }
        if tool == Tool::Smudge {
            self.ensure_tip(b);
            let key = crate::library::tip_key(b);
            let a = self.info.active;
            let undo = self.engine.save_region(a, (0, 0, self.info.w, self.info.h));
            let mut bb = b.clone();
            bb.spacing = bb.spacing.max(0.1);
            let mut sb = StrokeBuilder::new(bb, size.min(512.0), curve);
            let dabs = sb.add(p);
            self.smudge = Some((sb, key, opacity, None, undo));
            self.smudge_apply(dabs);
            return;
        }
        self.engine.begin_stroke();
        let st = StrokeState { color, opacity, erase: tool == Tool::Eraser, glow: b.glow && tool == Tool::Brush };
        self.ensure_tip(b);
        let key = crate::library::tip_key(b);
        let mut sb = StrokeBuilder::new(b.clone(), size, curve);
        let dabs = sb.add(p);
        self.engine.stamp(&self.tips[&key], &dabs);
        self.stroke = Some((sb, st, key, p));
        self.dirty = true;
    }

    /// Remplace le trait en cours par une forme nette (ligne, ellipse, polygone).
    pub fn quickshape(&mut self) -> bool {
        if self.smudge.is_some() {
            return false;
        }
        let Some((sb, _, key, _)) = self.stroke.as_mut() else { return false };
        if sb.shaped {
            return false;
        }
        let Some((shape, _kind)) = crate::brush::quick_shape(&sb.points) else { return false };
        let pavg = sb.points.iter().map(|p| p.p).sum::<f32>() / sb.points.len() as f32;
        let mut nb = StrokeBuilder::new(sb.brush.clone(), sb.size, sb.pressure_curve);
        nb.brush.streamline = 0.0;
        nb.brush.taper_size = 0.0;
        let mut dabs = Vec::new();
        for w in shape.windows(2) {
            let (a, b) = (w[0], w[1]);
            let len = ((b.0 - a.0).powi(2) + (b.1 - a.1).powi(2)).sqrt();
            let n = (len / 2.0).ceil().max(1.0) as usize;
            for i in 0..n {
                let f = i as f32 / n as f32;
                dabs.extend(nb.add(Point { x: a.0 + (b.0 - a.0) * f, y: a.1 + (b.1 - a.1) * f, p: pavg, t: 0.0 }));
            }
        }
        if let Some(&l) = shape.last() {
            dabs.extend(nb.add(Point { x: l.0, y: l.1, p: pavg, t: 0.0 }));
        }
        nb.shaped = true;
        let key = key.clone();
        self.engine.clear_stroke();
        self.engine.stroke_bbox = None;
        self.engine.stamp(&self.tips[&key], &dabs);
        if let Some(s) = self.stroke.as_mut() {
            s.0 = nb;
        }
        self.dirty = true;
        true
    }

    pub fn add_point(&mut self, p: Point) {
        if let Some(sm) = self.smudge.as_mut() {
            let dabs = sm.0.add(p);
            self.smudge_apply(dabs);
            return;
        }
        if self.stroke.as_ref().is_some_and(|s| s.0.shaped) {
            return;
        }
        if let Some((sb, _, key, last)) = self.stroke.as_mut() {
            let dabs = sb.add(p);
            *last = p;
            self.engine.stamp(&self.tips[key.as_str()], &dabs);
            self.dirty = true;
        }
    }

    pub fn cancel_stroke(&mut self) {
        if let Some((_, _, _, _, undo)) = self.smudge.take() {
            let _ = self.engine.swap_region(undo);
            self.dirty = true;
        }
        if self.stroke.take().is_some() {
            self.engine.clear_stroke();
            self.engine.stroke_bbox = None;
            self.dirty = true;
        }
    }

    pub fn end_stroke(&mut self) {
        if let Some((_, _, _, _, undo)) = self.smudge.take() {
            self.push_undo(UndoOp::Region(undo));
            self.changed();
            return;
        }
        let Some((mut sb, st, key, last)) = self.stroke.take() else { return };
        if !sb.shaped {
            let dabs = sb.finish(last);
            self.engine.stamp(&self.tips[&key], &dabs);
        }
        if !sb.shaped && sb.needs_replay() {
            // effilement de fin : on redessine le trait en connaissant sa longueur
            self.engine.clear_stroke();
            self.engine.stroke_bbox = None;
            let dabs = sb.replay();
            self.engine.stamp(&self.tips[&key], &dabs);
        }
        let a = self.info.active;
        if let Some(rect) = self.engine.stroke_rect() {
            let before = self.engine.save_region(a, rect);
            let d = self.draws()[a];
            self.engine.commit_stroke(a, &d, st);
            self.push_undo(UndoOp::Region(before));
            self.changed();
        } else {
            self.engine.clear_stroke();
            self.dirty = true;
        }
    }

    // ---------- Annuler / rétablir ----------
    pub fn push_undo(&mut self, op: UndoOp) {
        self.undo.push(op);
        if self.undo.len() > MAX_UNDO {
            self.undo.remove(0);
        }
        self.redo.clear();
    }

    fn apply(&mut self, op: UndoOp) -> UndoOp {
        match op {
            UndoOp::Region(r) => UndoOp::Region(self.engine.swap_region(r)),
            UndoOp::Add { index } => {
                let gpu = self.engine.layers.remove(index);
                let info = self.info.layers.remove(index);
                self.thumbs.remove(index);
                if self.info.active >= self.info.layers.len() {
                    self.info.active = self.info.layers.len().saturating_sub(1);
                }
                UndoOp::Delete { index, info, gpu }
            }
            UndoOp::Delete { index, info, gpu } => {
                self.engine.layers.insert(index, gpu);
                self.info.layers.insert(index, info);
                self.thumbs.insert(index, None);
                self.info.active = index;
                UndoOp::Add { index }
            }
            UndoOp::Move { from, to } => {
                self.move_layer_raw(from, to);
                UndoOp::Move { from: to, to: from }
            }
            UndoOp::Props { index, info } => {
                let old = std::mem::replace(&mut self.info.layers[index], info);
                UndoOp::Props { index, info: old }
            }
            UndoOp::Group(v) => {
                // les opérations d'un groupe s'appliquent de la dernière à la première
                let inv: Vec<UndoOp> = v.into_iter().rev().map(|o| self.apply(o)).collect();
                UndoOp::Group(inv)
            }
        }
    }

    pub fn undo(&mut self) -> bool {
        if self.stroke.is_some() {
            return false;
        }
        if let Some(op) = self.undo.pop() {
            let inv = self.apply(op);
            self.redo.push(inv);
            self.engine.invalidate();
            self.changed();
            true
        } else {
            false
        }
    }

    pub fn redo(&mut self) -> bool {
        if self.stroke.is_some() {
            return false;
        }
        if let Some(op) = self.redo.pop() {
            let inv = self.apply(op);
            self.undo.push(inv);
            self.engine.invalidate();
            self.changed();
            true
        } else {
            false
        }
    }

    // ---------- Calques ----------
    fn move_layer_raw(&mut self, from: usize, to: usize) {
        let g = self.engine.layers.remove(from);
        self.engine.layers.insert(to, g);
        let i = self.info.layers.remove(from);
        self.info.layers.insert(to, i);
        let t = self.thumbs.remove(from);
        self.thumbs.insert(to, t);
        let a = self.info.active;
        self.info.active = if a == from {
            to
        } else if from < a && to >= a {
            a - 1
        } else if from > a && to <= a {
            a + 1
        } else {
            a
        };
    }

    pub fn add_layer(&mut self) {
        self.info.counter += 1;
        let name = format!("Calque {}", self.info.counter);
        let index = (self.info.active + 1).min(self.info.layers.len());
        let g = self.engine.new_layer();
        self.engine.layers.insert(index, g);
        self.info.layers.insert(index, LayerInfo::new(&name));
        self.thumbs.insert(index, None);
        self.info.active = index;
        self.push_undo(UndoOp::Add { index });
        self.engine.invalidate();
        self.changed();
    }

    pub fn delete_layer(&mut self, index: usize) {
        if self.info.layers.len() <= 1 {
            self.engine.clear_layer(0);
            self.changed();
            return;
        }
        let op = self.apply(UndoOp::Add { index });
        self.push_undo(op);
        self.engine.invalidate();
        self.changed();
    }

    pub fn duplicate_layer(&mut self, index: usize) {
        let g = self.engine.new_layer();
        self.engine.layers.insert(index + 1, g);
        let mut info = self.info.layers[index].clone();
        info.name = format!("{} copie", info.name);
        self.info.layers.insert(index + 1, info);
        self.thumbs.insert(index + 1, None);
        self.engine.copy_layer(index, index + 1);
        self.info.active = index + 1;
        self.push_undo(UndoOp::Add { index: index + 1 });
        self.changed();
    }

    pub fn move_layer(&mut self, from: usize, to: usize) {
        if from == to || to >= self.info.layers.len() {
            return;
        }
        self.move_layer_raw(from, to);
        self.push_undo(UndoOp::Move { from: to, to: from });
        self.engine.invalidate();
        self.changed();
    }

    /// Modifie les réglages d'un calque (avec annulation).
    pub fn set_props(&mut self, index: usize, f: impl FnOnce(&mut LayerInfo)) {
        let old = self.info.layers[index].clone();
        f(&mut self.info.layers[index]);
        // regroupe les réglages successifs du même calque (ex. glisser l'opacité)
        let merge = matches!(self.undo.last(), Some(UndoOp::Props { index: i, .. }) if *i == index);
        if !merge {
            self.push_undo(UndoOp::Props { index, info: old });
        }
        self.engine.invalidate();
        self.changed();
    }

    pub fn merge_down(&mut self, index: usize) {
        if index == 0 {
            return;
        }
        let lower = index - 1;
        let region = self.engine.save_region(lower, (0, 0, self.info.w, self.info.h));
        let d = self.draws()[index];
        self.engine.merge_down(&d, lower);
        // supprime le calque du dessus (annulable)
        let del = self.apply(UndoOp::Add { index });
        self.info.active = lower;
        self.push_undo(UndoOp::Group(vec![UndoOp::Region(region), del]));
        self.engine.invalidate();
        self.changed();
    }

    /// Ajoute une image (RGBA prémultiplié) dans un nouveau calque, centrée et réduite si besoin.
    pub fn add_image_layer(&mut self, name: &str, w: u32, h: u32, px: &[u8]) {
        let (cw, ch) = (self.info.w, self.info.h);
        let s = (cw as f32 / w as f32).min(ch as f32 / h as f32).min(1.0);
        let tw = ((w as f32 * s) as u32).max(1);
        let th = ((h as f32 * s) as u32).max(1);
        let ox = (cw - tw.min(cw)) / 2;
        let oy = (ch - th.min(ch)) / 2;
        let mut buf = vec![0u8; (cw * ch * 4) as usize];
        for y in 0..th.min(ch) {
            let sy = ((y as f32 + 0.5) / s) as u32;
            for x in 0..tw.min(cw) {
                let sx = ((x as f32 + 0.5) / s) as u32;
                let si = ((sy.min(h - 1) * w + sx.min(w - 1)) * 4) as usize;
                let di = (((oy + y) * cw + ox + x) * 4) as usize;
                buf[di..di + 4].copy_from_slice(&px[si..si + 4]);
            }
        }
        self.add_layer();
        let a = self.info.active;
        let stem = name.rsplit_once('.').map(|(a, _)| a).unwrap_or(name);
        self.info.layers[a].name = stem.chars().take(30).collect();
        self.engine.write_layer(a, &buf);
        self.changed();
    }

    pub fn clear_active(&mut self) {
        let a = self.info.active;
        let region = self.engine.save_region(a, (0, 0, self.info.w, self.info.h));
        self.engine.clear_layer(a);
        self.push_undo(UndoOp::Region(region));
        self.changed();
    }

    // ---------- Sélection ----------
    pub fn set_selection(&mut self, poly: Option<Vec<(f32, f32)>>, inverted: bool) {
        match poly {
            Some(p) if p.len() >= 3 => {
                let mask = rasterize(&p, self.info.w, self.info.h, inverted);
                self.engine.set_selection(Some(&mask));
                self.selection = Some((p, inverted));
            }
            _ => {
                self.engine.set_selection(None);
                self.selection = None;
            }
        }
        self.dirty = true;
    }

    pub fn invert_selection(&mut self) {
        if let Some((p, inv)) = self.selection.clone() {
            self.set_selection(Some(p), !inv);
        }
    }

    pub fn clear_selection_content(&mut self) {
        if self.selection.is_none() {
            return;
        }
        let a = self.info.active;
        let region = self.engine.save_region(a, (0, 0, self.info.w, self.info.h));
        self.engine.clear_in_selection(a);
        self.push_undo(UndoOp::Region(region));
        self.changed();
    }

    // ---------- Transformation ----------
    pub fn transform_start(&mut self) {
        if self.xform.is_none() && !self.engine.fx_active() {
            self.xform = Some(Xform::default());
            self.transform_update();
        }
    }

    pub fn transform_update(&mut self) {
        let Some(x) = self.xform else { return };
        let (cx, cy) = (self.info.w as f32 / 2.0, self.info.h as f32 / 2.0);
        let sx = x.scale.max(0.01) * if x.flip_h { -1.0 } else { 1.0 };
        let sy = x.scale.max(0.01) * if x.flip_v { -1.0 } else { 1.0 };
        let (sn, cs) = x.rot.sin_cos();
        // inverse : p = C + S⁻¹ R⁻¹ (p' - C - T)
        let a = cs / sx;
        let b = sn / sx;
        let c = -sn / sy;
        let d = cs / sy;
        let ox = cx + x.tx;
        let oy = cy + x.ty;
        self.engine.fx_matrix = [a, b, cx - a * ox - b * oy, c, d, cy - c * ox - d * oy];
        let l = self.info.active;
        self.engine.fx_begin(l);
        self.engine.fx_update(7, [0.0; 3]);
        self.dirty = true;
    }

    pub fn transform_apply(&mut self) {
        if self.xform.take().is_some() {
            self.fx_apply();
        }
    }

    pub fn transform_cancel(&mut self) {
        if self.xform.take().is_some() {
            self.fx_cancel();
        }
    }

    // ---------- Ajustements ----------
    pub fn fx_preview(&mut self, kind: u32, p: [f32; 3]) {
        let a = self.info.active;
        self.engine.fx_begin(a);
        self.engine.fx_update(kind, p);
        self.dirty = true;
    }

    pub fn fx_apply(&mut self) {
        if let Some(r) = self.engine.fx_commit() {
            self.push_undo(UndoOp::Region(r));
            self.changed();
        }
    }

    pub fn fx_cancel(&mut self) {
        self.engine.fx_cancel();
        self.dirty = true;
    }

    // ---------- Enregistrement ----------
    /// Lit les pixels sur la carte graphique puis écrit le fichier (en arrière-plan si `background`).
    pub fn save(&mut self, path: &std::path::Path, background: bool) {
        let px: Vec<Vec<u8>> = (0..self.info.layers.len()).map(|i| self.engine.read_layer(i)).collect();
        self.dirty = true;
        self.render();
        let disp = self.engine.read_display();
        let info = self.info.clone();
        let path = path.to_path_buf();
        self.unsaved = false;
        let job = move || {
            let mut disp = disp;
            doc::unpremultiply(&mut disp);
            let thumb = thumb_png(info.w, info.h, &disp, 512);
            if let Err(e) = doc::save(&path, &info, px, Some(thumb)) {
                log::error!("enregistrement impossible : {e}");
            }
        };
        static LOCK: std::sync::Mutex<()> = std::sync::Mutex::new(());
        if background {
            std::thread::spawn(move || {
                let _g = LOCK.lock();
                job();
            });
        } else {
            let _g = LOCK.lock();
            job();
        }
    }

    /// Image finale (non prémultipliée) pour l'export.
    pub fn flatten_rgba(&mut self) -> Vec<u8> {
        self.dirty = true;
        self.render();
        let mut px = self.engine.read_display();
        doc::unpremultiply(&mut px);
        px
    }
}

fn thumb_png(w: u32, h: u32, rgba: &[u8], max: u32) -> Vec<u8> {
    let s = (max as f32 / w.max(h) as f32).min(1.0);
    let tw = ((w as f32 * s) as u32).max(1);
    let th = ((h as f32 * s) as u32).max(1);
    let mut out = vec![0u8; (tw * th * 4) as usize];
    for y in 0..th {
        for x in 0..tw {
            let sx = ((x as f32 + 0.5) / s) as u32;
            let sy = ((y as f32 + 0.5) / s) as u32;
            let si = ((sy.min(h - 1) * w + sx.min(w - 1)) * 4) as usize;
            let di = ((y * tw + x) * 4) as usize;
            out[di..di + 4].copy_from_slice(&rgba[si..si + 4]);
        }
    }
    doc::encode_png(tw, th, &out)
}

/// Remplit un polygone (règle pair-impair) en masque 0..255, avec un léger anticrénelage vertical.
pub fn rasterize(poly: &[(f32, f32)], w: u32, h: u32, inverted: bool) -> Vec<u8> {
    let mut m = vec![0u8; (w * h) as usize];
    const SUB: usize = 4;
    let n = poly.len();
    let mut xs: Vec<f32> = Vec::new();
    let mut acc = vec![0u16; w as usize];
    for y in 0..h as usize {
        acc.iter_mut().for_each(|a| *a = 0);
        for sub in 0..SUB {
            let sy = y as f32 + (sub as f32 + 0.5) / SUB as f32;
            xs.clear();
            for i in 0..n {
                let (a, b) = (poly[i], poly[(i + 1) % n]);
                if (a.1 <= sy && b.1 > sy) || (b.1 <= sy && a.1 > sy) {
                    xs.push(a.0 + (sy - a.1) / (b.1 - a.1) * (b.0 - a.0));
                }
            }
            xs.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
            for pair in xs.chunks_exact(2) {
                let x0 = pair[0].max(0.0).round() as usize;
                let x1 = (pair[1].min(w as f32)).round() as usize;
                for a in acc.iter_mut().take(x1).skip(x0) {
                    *a += 1;
                }
            }
        }
        for x in 0..w as usize {
            let v = (acc[x] as u32 * 255 / SUB as u32) as u8;
            m[y * w as usize + x] = if inverted { 255 - v } else { v };
        }
    }
    m
}
