//! Mise à jour automatique : cherche une version « natif-* » plus récente sur GitHub.
//! Windows : télécharge et remplace l'exe (prêt au prochain démarrage).
//! Android : propose de télécharger le nouvel APK (l'installation demande l'accord d'Android).

use std::sync::{Arc, Mutex};
use std::time::Duration;

const RELEASES: &str = "https://api.github.com/repos/Unstellary/yujin-studio/releases?per_page=15";

/// Numéro de compilation (fixé par GitHub Actions).
pub fn build_number() -> u32 {
    option_env!("YS_BUILD").and_then(|s| s.parse().ok()).unwrap_or(0)
}

#[derive(Clone, Debug)]
pub enum Status {
    /// Une version plus récente existe (numéro, lien de téléchargement)
    Available { build: u32, url: String },
    /// Windows : la nouvelle version est installée, il suffit de relancer
    Installed { build: u32 },
}

pub type Shared = Arc<Mutex<Option<Status>>>;

fn http() -> ureq::Agent {
    ureq::Agent::config_builder().timeout_global(Some(Duration::from_secs(120))).build().into()
}

fn latest() -> Result<Option<(u32, String)>, String> {
    let body = http()
        .get(RELEASES)
        .header("Accept", "application/vnd.github+json")
        .header("User-Agent", "YujinStudio")
        .call()
        .map_err(|e| e.to_string())?
        .body_mut()
        .read_to_string()
        .map_err(|e| e.to_string())?;
    let v: serde_json::Value = serde_json::from_str(&body).map_err(|e| e.to_string())?;
    let want = if cfg!(target_os = "android") { "Yujin-Studio-Natif.apk" } else { "Yujin-Studio-Natif-Windows.zip" };
    let mut best: Option<(u32, String)> = None;
    for r in v.as_array().into_iter().flatten() {
        let tag = r["tag_name"].as_str().unwrap_or("");
        if !tag.starts_with("natif-") || r["draft"].as_bool() == Some(true) {
            continue;
        }
        let Some(n) = tag.rsplit('.').next().and_then(|s| s.parse::<u32>().ok()) else { continue };
        let url = r["assets"].as_array().into_iter().flatten().find(|a| a["name"].as_str() == Some(want)).and_then(|a| a["browser_download_url"].as_str());
        if let Some(url) = url {
            if best.as_ref().is_none_or(|b| n > b.0) {
                best = Some((n, url.to_string()));
            }
        }
    }
    Ok(best)
}

#[cfg(target_os = "windows")]
fn install_windows(url: &str) -> Result<(), String> {
    use std::io::Read;
    let mut data = Vec::new();
    http().get(url).header("User-Agent", "YujinStudio").call().map_err(|e| e.to_string())?.body_mut().with_config().limit(200 << 20).reader().read_to_end(&mut data).map_err(|e| e.to_string())?;
    let mut z = zip::ZipArchive::new(std::io::Cursor::new(data)).map_err(|e| e.to_string())?;
    let mut exe = Vec::new();
    for i in 0..z.len() {
        let mut f = z.by_index(i).map_err(|e| e.to_string())?;
        if f.name().to_lowercase().ends_with(".exe") {
            f.read_to_end(&mut exe).map_err(|e| e.to_string())?;
            break;
        }
    }
    if exe.len() < 1_000_000 {
        return Err("exe introuvable dans la mise à jour".into());
    }
    let cur = std::env::current_exe().map_err(|e| e.to_string())?;
    let new = cur.with_extension("new");
    let old = cur.with_extension("old");
    std::fs::write(&new, &exe).map_err(|e| e.to_string())?;
    let _ = std::fs::remove_file(&old);
    // Windows permet de renommer un exe en cours d'exécution
    std::fs::rename(&cur, &old).map_err(|e| e.to_string())?;
    if let Err(e) = std::fs::rename(&new, &cur) {
        let _ = std::fs::rename(&old, &cur);
        return Err(e.to_string());
    }
    Ok(())
}

/// Relance l'appli (Windows, après une mise à jour).
pub fn restart() {
    if let Ok(cur) = std::env::current_exe() {
        let _ = std::process::Command::new(cur).spawn();
    }
    std::process::exit(0);
}

/// Supprime l'ancien exe laissé par une mise à jour précédente.
pub fn cleanup() {
    if let Ok(cur) = std::env::current_exe() {
        let _ = std::fs::remove_file(cur.with_extension("old"));
    }
}

fn check(shared: &Shared) {
    let mine = build_number();
    if mine == 0 {
        return; // compilation locale : pas de mise à jour
    }
    match latest() {
        Ok(Some((n, url))) if n > mine => {
            if matches!(*shared.lock().unwrap(), Some(Status::Installed { build }) if build >= n) {
                return;
            }
            #[cfg(target_os = "windows")]
            {
                match install_windows(&url) {
                    Ok(()) => *shared.lock().unwrap() = Some(Status::Installed { build: n }),
                    Err(e) => {
                        log::warn!("mise à jour : {e}");
                        *shared.lock().unwrap() = Some(Status::Available { build: n, url });
                    }
                }
            }
            #[cfg(not(target_os = "windows"))]
            {
                *shared.lock().unwrap() = Some(Status::Available { build: n, url });
            }
        }
        Ok(_) => {}
        Err(e) => log::info!("vérification des mises à jour impossible : {e}"),
    }
}

/// Lance la vérification au démarrage puis toutes les 3 heures.
pub fn start(shared: Shared, wake: impl Fn() + Send + 'static) {
    cleanup();
    std::thread::spawn(move || {
        std::thread::sleep(Duration::from_secs(4));
        loop {
            check(&shared);
            if shared.lock().unwrap().is_some() {
                wake();
            }
            std::thread::sleep(Duration::from_secs(3 * 3600));
        }
    });
}
