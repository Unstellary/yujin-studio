//! Interface façon Procreate (egui) : barre du haut, barre latérale, panneaux.

use crate::brush::Brush;
use crate::canvas::{Canvas, Tool};
use crate::doc;
use egui::{Align2, Color32, CornerRadius, Pos2, Rect, RichText, Sense, Stroke, Vec2};
use serde::{Deserialize, Serialize};
use std::path::PathBuf;
use std::time::Instant;

pub const ACCENT: Color32 = Color32::from_rgb(139, 92, 246);
const BAR: Color32 = Color32::from_rgba_premultiplied(24, 24, 27, 235);
const PANEL: Color32 = Color32::from_rgb(30, 30, 34);

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Panel {
    Gallery,
    Adjust,
    Transform,
    Actions,
    Brushes,
    Layers,
    Color,
}

pub enum Action {
    NewCanvas(u32, u32),
    Open(PathBuf),
    Fit,
    Save,
    Export(&'static str),
    Fullscreen,
    OpenUrl(String),
    Restart,
    DismissUpdate,
    PickFiles,
    DeleteBrush(String),
}

#[derive(Serialize, Deserialize)]
#[serde(default)]
pub struct UiState {
    #[serde(skip, default = "default_tool")]
    pub tool: Tool,
    pub brush: String,
    pub eraser_brush: String,
    pub palettes: Vec<(String, Vec<[f32; 3]>)>,
    pub color_mode: u8,
    pub size_brush: f32,
    pub op_brush: f32,
    pub size_eraser: f32,
    pub op_eraser: f32,
    pub color: [f32; 3],
    pub recent: Vec<[f32; 3]>,
    pub pressure_curve: f32,
    pub quickshape: bool,
    pub finger_draw: bool,
    pub pen_seen: bool,
    #[serde(skip)]
    pub panel: Option<Panel>,
    #[serde(skip)]
    pub hide_ui: bool,
    #[serde(skip)]
    pub eyedropper: bool,
    #[serde(skip)]
    toast: Option<(String, Instant)>,
    #[serde(skip)]
    gallery: Option<Vec<(PathBuf, String, Option<egui::TextureHandle>)>>,
    #[serde(skip)]
    brush_cat: String,
    /// ajustement en cours : (type, réglages)
    #[serde(skip)]
    pub fx: Option<(u32, [f32; 3])>,
}

fn default_tool() -> Tool {
    Tool::Brush
}

impl Default for UiState {
    fn default() -> Self {
        UiState {
            tool: Tool::Brush,
            brush: "encre-tech".into(),
            eraser_brush: "aero-doux".into(),
            palettes: Vec::new(),
            color_mode: 0,
            size_brush: 0.25,
            op_brush: 1.0,
            size_eraser: 0.35,
            op_eraser: 1.0,
            color: [0.12, 0.1, 0.16],
            recent: Vec::new(),
            pressure_curve: 1.0,
            quickshape: true,
            finger_draw: false,
            pen_seen: false,
            panel: None,
            hide_ui: false,
            eyedropper: false,
            toast: None,
            gallery: None,
            brush_cat: String::new(),
            fx: None,
        }
    }
}

pub fn slider_to_px(v: f32, max: f32) -> f32 {
    1.0 + (max - 1.0) * v.clamp(0.0, 1.0).powi(2)
}

impl UiState {
    fn path() -> PathBuf {
        doc::data_dir().join("reglages.json")
    }
    pub fn load() -> Self {
        std::fs::read_to_string(Self::path()).ok().and_then(|s| serde_json::from_str(&s).ok()).unwrap_or_default()
    }
    pub fn save(&self) {
        let _ = std::fs::create_dir_all(doc::data_dir());
        if let Ok(s) = serde_json::to_string_pretty(self) {
            let _ = std::fs::write(Self::path(), s);
        }
    }
    pub fn toast(&mut self, s: String) {
        self.toast = Some((s, Instant::now()));
    }
    pub fn push_recent(&mut self) {
        let c = self.color;
        self.recent.retain(|r| r.iter().zip(c.iter()).map(|(a, b)| (a - b).abs()).sum::<f32>() > 0.01);
        self.recent.insert(0, c);
        self.recent.truncate(10);
    }
    pub fn brush_cat_set(&mut self, c: &str) {
        self.brush_cat = c.to_string();
        self.panel = Some(Panel::Brushes);
    }
    pub fn bump_size(&mut self, d: f32) {
        match self.tool {
            Tool::Brush => self.size_brush = (self.size_brush + d).clamp(0.0, 1.0),
            Tool::Eraser => self.size_eraser = (self.size_eraser + d).clamp(0.0, 1.0),
        }
    }
    pub fn is_over_ui(&self, ctx: &egui::Context, pos: Pos2) -> bool {
        ctx.layer_id_at(pos).is_some_and(|l| l.order != egui::Order::Background)
    }
}

fn c32(c: [f32; 3]) -> Color32 {
    Color32::from_rgb((c[0] * 255.0).round() as u8, (c[1] * 255.0).round() as u8, (c[2] * 255.0).round() as u8)
}

pub fn setup_style(ctx: &egui::Context) {
    let mut v = egui::Visuals::dark();
    v.selection.bg_fill = ACCENT;
    v.widgets.hovered.bg_fill = Color32::from_rgb(55, 55, 62);
    v.widgets.inactive.bg_fill = Color32::from_rgb(44, 44, 50);
    v.window_fill = PANEL;
    v.panel_fill = PANEL;
    ctx.set_visuals(v);
    ctx.all_styles_mut(|s| {
        s.spacing.item_spacing = Vec2::new(8.0, 8.0);
        s.spacing.button_padding = Vec2::new(10.0, 6.0);
        s.spacing.interact_size.y = 34.0;
        s.spacing.slider_width = 180.0;
        for (_, f) in s.text_styles.iter_mut() {
            f.size *= 1.15;
        }
    });
}

/// Dessine la toile (texture GPU) avec la vue courante.
pub fn paint_canvas(ctx: &egui::Context, c: &Canvas, ids: (egui::TextureId, egui::TextureId)) {
    let p = ctx.layer_painter(egui::LayerId::background());
    let v = &c.view;
    let (w, h) = (c.info.w as f32, c.info.h as f32);
    let corners = [Pos2::new(0.0, 0.0), Pos2::new(w, 0.0), Pos2::new(w, h), Pos2::new(0.0, h)];
    let uvs = [Pos2::new(0.0, 0.0), Pos2::new(1.0, 0.0), Pos2::new(1.0, 1.0), Pos2::new(0.0, 1.0)];
    let tex = if v.scale * ctx.pixels_per_point() >= 2.0 { ids.1 } else { ids.0 };
    // ombre
    let mut sh = egui::Mesh::default();
    for k in corners {
        sh.colored_vertex(v.to_screen(k) + Vec2::new(0.0, 3.0), Color32::from_black_alpha(90));
    }
    sh.add_triangle(0, 1, 2);
    sh.add_triangle(0, 2, 3);
    p.add(sh);
    if !c.info.bg_visible {
        // damier sous un fond transparent
        let r = Rect::from_points(&corners.map(|k| v.to_screen(k)));
        p.rect_filled(r, 0.0, Color32::from_gray(200));
    }
    let mut m = egui::Mesh::with_texture(tex);
    for (k, uv) in corners.iter().zip(uvs) {
        m.vertices.push(egui::epaint::Vertex { pos: v.to_screen(*k), uv, color: Color32::WHITE });
    }
    m.add_triangle(0, 1, 2);
    m.add_triangle(0, 2, 3);
    p.add(m);
}

#[derive(Clone, Copy)]
enum Icon {
    Undo,
    Redo,
    Picker,
}

/// Bouton avec une icône dessinée (pas de dépendance aux polices d'icônes).
fn icon_button(ui: &mut egui::Ui, icon: Icon, on: bool, enabled: bool) -> egui::Response {
    let (r, resp) = ui.allocate_exact_size(Vec2::splat(40.0), if enabled { Sense::click() } else { Sense::hover() });
    let p = ui.painter();
    let bg = if on { ACCENT } else if resp.hovered() && enabled { Color32::from_rgb(60, 60, 68) } else { Color32::from_rgb(44, 44, 50) };
    p.rect_filled(r, 10.0, bg);
    let col = if enabled { Color32::from_gray(235) } else { Color32::from_gray(110) };
    let st = Stroke::new(2.2, col);
    let c = r.center();
    match icon {
        Icon::Undo | Icon::Redo => {
            let s = if matches!(icon, Icon::Undo) { 1.0 } else { -1.0 };
            // arc
            let pts: Vec<Pos2> = (0..=16)
                .map(|i| {
                    let a = std::f32::consts::PI * (0.15 + 1.1 * i as f32 / 16.0);
                    Pos2::new(c.x + s * 8.0 * a.cos(), c.y + 2.0 - 8.0 * a.sin())
                })
                .collect();
            p.add(egui::Shape::line(pts.clone(), st));
            let tip = pts[16];
            p.line_segment([tip, tip + Vec2::new(s * 5.0, -4.0)], st);
            p.line_segment([tip, tip + Vec2::new(s * 6.0, 4.0)], st);
        }
        Icon::Picker => {
            p.line_segment([c + Vec2::new(-8.0, 8.0), c + Vec2::new(4.0, -4.0)], Stroke::new(3.0, col));
            p.circle_filled(c + Vec2::new(6.0, -6.0), 4.5, col);
        }
    }
    resp
}

fn bar_button(ui: &mut egui::Ui, label: &str, on: bool) -> egui::Response {
    let t = RichText::new(label).size(16.0).color(if on { ACCENT } else { Color32::from_gray(230) });
    ui.add(egui::Button::new(t).frame(false).min_size(Vec2::new(44.0, 40.0)))
}

fn panel_frame() -> egui::Frame {
    egui::Frame::new().fill(PANEL).corner_radius(CornerRadius::same(14)).inner_margin(14.0).stroke(Stroke::new(1.0, Color32::from_gray(55)))
}

fn toggle_panel(ui: &mut UiState, p: Panel) {
    ui.panel = if ui.panel == Some(p) { None } else { Some(p) };
    if p == Panel::Gallery {
        ui.gallery = None;
    }
}

/// Construit l'interface et renvoie les actions à exécuter.
pub fn build(ctx: &egui::Context, st: &mut UiState, mut canvas: Option<&mut Canvas>, brushes: &[Brush], update: Option<&crate::updater::Status>) -> Vec<Action> {
    let mut actions = Vec::new();
    let screen = ctx.content_rect();
    if let Some(u) = update {
        egui::Area::new(egui::Id::unique("update")).anchor(Align2::CENTER_BOTTOM, Vec2::new(0.0, -24.0)).order(egui::Order::Foreground).show(ctx, |ui| {
            egui::Frame::new().fill(Color32::from_rgb(42, 37, 51)).corner_radius(CornerRadius::same(14)).inner_margin(12.0).show(ui, |ui| {
                ui.horizontal(|ui| match u {
                    crate::updater::Status::Available { build, url } => {
                        ui.label(RichText::new(format!("Nouvelle version disponible (0.1.{build})")).color(Color32::WHITE));
                        if ui.add(egui::Button::new(RichText::new("Télécharger").color(Color32::WHITE)).fill(ACCENT)).clicked() {
                            actions.push(Action::OpenUrl(url.clone()));
                            actions.push(Action::DismissUpdate);
                        }
                        if ui.button("Plus tard").clicked() {
                            actions.push(Action::DismissUpdate);
                        }
                    }
                    crate::updater::Status::Installed { build } => {
                        ui.label(RichText::new(format!("Mise à jour 0.1.{build} installée")).color(Color32::WHITE));
                        if ui.add(egui::Button::new(RichText::new("Redémarrer").color(Color32::WHITE)).fill(ACCENT)).clicked() {
                            actions.push(Action::Restart);
                        }
                        if ui.button("Plus tard").clicked() {
                            actions.push(Action::DismissUpdate);
                        }
                    }
                });
            });
        });
    }
    if st.hide_ui {
        egui::Area::new(egui::Id::unique("show_ui")).anchor(Align2::RIGHT_TOP, Vec2::new(-8.0, 8.0)).show(ctx, |ui| {
            if ui.button("Afficher l'interface").clicked() {
                st.hide_ui = false;
            }
        });
        return actions;
    }

    // ---- Barre du haut ----
    egui::Area::new(egui::Id::unique("topbar")).fixed_pos(Pos2::ZERO).order(egui::Order::Middle).show(ctx, |ui| {
        egui::Frame::new().fill(BAR).inner_margin(egui::Margin::symmetric(10, 4)).show(ui, |ui| {
            ui.set_width(screen.width() - 20.0);
            ui.horizontal(|ui| {
                if bar_button(ui, "Galerie", st.panel == Some(Panel::Gallery)).clicked() {
                    toggle_panel(st, Panel::Gallery);
                }
                if bar_button(ui, "Actions", st.panel == Some(Panel::Actions)).clicked() {
                    toggle_panel(st, Panel::Actions);
                }
                if bar_button(ui, "Ajustements", st.panel == Some(Panel::Adjust)).clicked() {
                    toggle_panel(st, Panel::Adjust);
                }
                if bar_button(ui, "Transformer", st.panel == Some(Panel::Transform)).clicked() {
                    if st.panel == Some(Panel::Transform) {
                        if let Some(c) = canvas.as_deref_mut() {
                            c.transform_apply();
                        }
                        st.panel = None;
                    } else if st.fx.is_none() {
                        st.panel = Some(Panel::Transform);
                        if let Some(c) = canvas.as_deref_mut() {
                            c.transform_start();
                        }
                    }
                }
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    // pastille de couleur
                    let (r, resp) = ui.allocate_exact_size(Vec2::splat(34.0), Sense::click());
                    ui.painter().circle_filled(r.center(), 15.0, c32(st.color));
                    ui.painter().circle_stroke(r.center(), 15.0, Stroke::new(2.0, Color32::from_gray(220)));
                    if resp.clicked() {
                        toggle_panel(st, Panel::Color);
                    }
                    if bar_button(ui, "Calques", st.panel == Some(Panel::Layers)).clicked() {
                        toggle_panel(st, Panel::Layers);
                    }
                    if bar_button(ui, "Gomme", st.tool == Tool::Eraser).clicked() {
                        if st.tool == Tool::Eraser {
                            toggle_panel(st, Panel::Brushes);
                        } else {
                            st.tool = Tool::Eraser;
                        }
                    }
                    if bar_button(ui, "Pinceau", st.tool == Tool::Brush).clicked() {
                        if st.tool == Tool::Brush {
                            toggle_panel(st, Panel::Brushes);
                        } else {
                            st.tool = Tool::Brush;
                        }
                    }
                });
            });
        });
    });

    // ---- Barre latérale ----
    egui::Area::new(egui::Id::unique("sidebar")).anchor(Align2::LEFT_CENTER, Vec2::new(8.0, 0.0)).order(egui::Order::Middle).show(ctx, |ui| {
        egui::Frame::new().fill(BAR).corner_radius(CornerRadius::same(14)).inner_margin(8.0).show(ui, |ui| {
            ui.spacing_mut().slider_width = 170.0;
            ui.vertical_centered(|ui| {
                let (size, op) = match st.tool {
                    Tool::Brush => (&mut st.size_brush, &mut st.op_brush),
                    Tool::Eraser => (&mut st.size_eraser, &mut st.op_eraser),
                };
                ui.label(RichText::new("Taille").size(11.0).color(Color32::GRAY));
                ui.add(egui::Slider::new(size, 0.0..=1.0).vertical().show_value(false));
                ui.add_space(6.0);
                if icon_button(ui, Icon::Picker, st.eyedropper, true).on_hover_text("Pipette").clicked() {
                    st.eyedropper = !st.eyedropper;
                }
                ui.add_space(6.0);
                ui.add(egui::Slider::new(op, 0.0..=1.0).vertical().show_value(false));
                ui.label(RichText::new("Opacité").size(11.0).color(Color32::GRAY));
                ui.add_space(8.0);
                let (can_undo, can_redo) = canvas.as_ref().map(|c| (!c.undo.is_empty(), !c.redo.is_empty())).unwrap_or((false, false));
                if icon_button(ui, Icon::Undo, false, can_undo).on_hover_text("Annuler").clicked() {
                    if let Some(c) = canvas.as_deref_mut() {
                        c.undo();
                    }
                }
                if icon_button(ui, Icon::Redo, false, can_redo).on_hover_text("Rétablir").clicked() {
                    if let Some(c) = canvas.as_deref_mut() {
                        c.redo();
                    }
                }
            });
        });
    });

    // ---- Panneaux ----
    if let Some(p) = st.panel {
        let (anchor, off) = match p {
            Panel::Gallery | Panel::Actions | Panel::Adjust => (Align2::LEFT_TOP, Vec2::new(60.0, 52.0)),
            Panel::Transform => (Align2::CENTER_BOTTOM, Vec2::new(0.0, -16.0)),
            _ => (Align2::RIGHT_TOP, Vec2::new(-10.0, 52.0)),
        };
        egui::Area::new(egui::Id::unique("panel")).anchor(anchor, off).order(egui::Order::Foreground).show(ctx, |ui| {
            panel_frame().show(ui, |ui| {
                ui.set_width(360.0);
                ui.set_max_height(screen.height() - 90.0);
                egui::ScrollArea::vertical().show(ui, |ui| match p {
                    Panel::Brushes => brushes_panel(ui, st, brushes, &mut actions),
                    Panel::Layers => {
                        if let Some(c) = canvas.as_deref_mut() {
                            layers_panel(ui, c);
                        }
                    }
                    Panel::Color => color_panel(ui, st, &mut actions),
                    Panel::Actions => actions_panel(ui, st, canvas.as_deref_mut(), &mut actions),
                    Panel::Gallery => gallery_panel(ui, st, &mut actions),
                    Panel::Transform => {
                        if let Some(c) = canvas.as_deref_mut() {
                            transform_panel(ui, st, c);
                        }
                    }
                    Panel::Adjust => {
                        if let Some(c) = canvas.as_deref_mut() {
                            adjust_panel(ui, st, c);
                        }
                    }
                });
            });
        });
    }

    // ---- Message ----
    if let Some((msg, t)) = &st.toast {
        if t.elapsed().as_secs_f32() < 3.0 {
            egui::Area::new(egui::Id::unique("toast")).anchor(Align2::CENTER_BOTTOM, Vec2::new(0.0, -30.0)).order(egui::Order::Tooltip).show(ctx, |ui| {
                egui::Frame::new().fill(Color32::from_rgb(42, 37, 51)).corner_radius(CornerRadius::same(12)).inner_margin(12.0).show(ui, |ui| {
                    ui.label(RichText::new(msg.as_str()).color(Color32::WHITE));
                });
            });
            ctx.request_repaint_after(std::time::Duration::from_millis(250));
        } else {
            st.toast = None;
        }
    }
    actions
}

fn brushes_panel(ui: &mut egui::Ui, st: &mut UiState, brushes: &[Brush], actions: &mut Vec<Action>) {
    ui.horizontal(|ui| {
        ui.heading(if st.tool == Tool::Eraser { "Gomme" } else { "Bibliothèque de pinceaux" });
        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            if ui.button(RichText::new("Importer").size(14.0)).on_hover_text("Pinceaux Procreate (.brush, .brushset)").clicked() {
                actions.push(Action::PickFiles);
            }
        });
    });
    let cats = crate::library::categories(brushes);
    if !cats.contains(&st.brush_cat) {
        st.brush_cat = cats.first().cloned().unwrap_or_default();
    }
    ui.horizontal_wrapped(|ui| {
        for c in &cats {
            if ui.selectable_label(st.brush_cat == *c, c.as_str()).clicked() {
                st.brush_cat = c.clone();
            }
        }
    });
    ui.separator();
    let eraser = st.tool == Tool::Eraser;
    let mut picked: Option<&Brush> = None;
    for b in brushes.iter().filter(|b| b.cat == st.brush_cat) {
        let (r, resp) = ui.allocate_exact_size(Vec2::new(ui.available_width(), 52.0), Sense::click());
        let on = if eraser { st.eraser_brush == b.id } else { st.brush == b.id };
        ui.painter().rect_filled(r, 10.0, if on { Color32::from_rgb(58, 45, 90) } else { Color32::from_rgb(38, 38, 44) });
        // aperçu : courbe en S de largeur variable
        let pts: Vec<Pos2> = (0..40)
            .map(|k| {
                let t = k as f32 / 39.0;
                Pos2::new(r.left() + 14.0 + t * 150.0, r.center().y + (t * std::f32::consts::TAU).sin() * 10.0)
            })
            .collect();
        for (k, w) in pts.windows(2).enumerate() {
            let t = k as f32 / 39.0;
            let p = (t * std::f32::consts::PI).sin();
            let wdt = 1.0 + 7.0 * (b.min_size + (1.0 - b.min_size) * (1.0 - b.size_p + b.size_p * p));
            let a = (255.0 * (1.0 - b.op_p + b.op_p * p).clamp(0.15, 1.0)) as u8;
            ui.painter().line_segment([w[0], w[1]], Stroke::new(wdt, Color32::from_white_alpha(a)));
        }
        ui.painter().text(Pos2::new(r.left() + 180.0, r.center().y), Align2::LEFT_CENTER, &b.name, egui::FontId::proportional(15.0), Color32::WHITE);
        if resp.clicked() {
            picked = Some(b);
        }
        if on && !crate::library::is_builtin(b) {
            let del = Rect::from_center_size(Pos2::new(r.right() - 22.0, r.center().y), Vec2::splat(28.0));
            if ui.put(del, egui::Button::new("✕")).on_hover_text("Supprimer ce pinceau").clicked() {
                actions.push(Action::DeleteBrush(b.id.clone()));
            }
        }
    }
    if let Some(b) = picked {
        // taille par défaut du pinceau importé
        let v = if crate::library::is_builtin(b) { None } else { Some(b.def_size.clamp(0.01, 1.0).sqrt()) };
        if eraser {
            st.eraser_brush = b.id.clone();
            if let Some(v) = v {
                st.size_eraser = v;
            }
        } else {
            st.brush = b.id.clone();
            if let Some(v) = v {
                st.size_brush = v;
            }
        }
    }
}

fn layers_panel(ui: &mut egui::Ui, c: &mut Canvas) {
    ui.horizontal(|ui| {
        ui.heading("Calques");
        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            if ui.button(RichText::new("+").size(20.0)).on_hover_text("Nouveau calque").clicked() {
                c.add_layer();
            }
        });
    });
    let n = c.info.layers.len();
    let aspect = c.info.h as f32 / c.info.w as f32;
    let mut select = None;
    let mut toggle_vis = None;
    for i in (0..n).rev() {
        let on = c.info.active == i;
        let l = &c.info.layers[i];
        let (r, resp) = ui.allocate_exact_size(Vec2::new(ui.available_width(), 58.0), Sense::click());
        ui.painter().rect_filled(r, 10.0, if on { Color32::from_rgb(58, 45, 90) } else { Color32::from_rgb(38, 38, 44) });
        let tw = 46.0f32;
        let th = (tw * aspect).min(46.0);
        let tr = Rect::from_center_size(Pos2::new(r.left() + 34.0, r.center().y), Vec2::new(tw.min(46.0 / aspect), th));
        ui.painter().rect_filled(tr, 3.0, Color32::from_gray(235));
        if let Some(Some(t)) = c.thumbs.get(i) {
            ui.painter().image(*t, tr, Rect::from_min_max(Pos2::ZERO, Pos2::new(1.0, 1.0)), Color32::WHITE);
        }
        ui.painter().text(Pos2::new(r.left() + 66.0, r.center().y - 8.0), Align2::LEFT_CENTER, &l.name, egui::FontId::proportional(15.0), Color32::WHITE);
        ui.painter().text(
            Pos2::new(r.left() + 66.0, r.center().y + 11.0),
            Align2::LEFT_CENTER,
            format!("{} · {} %", doc::blend_name(l.mode), (l.opacity * 100.0).round()),
            egui::FontId::proportional(12.0),
            Color32::GRAY,
        );
        // case de visibilité
        let cb = Rect::from_center_size(Pos2::new(r.right() - 24.0, r.center().y), Vec2::splat(26.0));
        ui.painter().rect_stroke(cb, 6.0, Stroke::new(2.0, Color32::from_gray(200)), egui::StrokeKind::Inside);
        if l.visible {
            ui.painter().rect_filled(cb.shrink(5.0), 3.0, ACCENT);
        }
        if resp.clicked() {
            if let Some(pos) = resp.interact_pointer_pos() {
                if cb.expand(8.0).contains(pos) {
                    toggle_vis = Some(i);
                } else {
                    select = Some(i);
                }
            }
        }
    }
    if let Some(i) = toggle_vis {
        c.set_props(i, |l| l.visible = !l.visible);
    }
    if let Some(i) = select {
        c.info.active = i;
        c.engine.invalidate();
        c.dirty = true;
    }
    ui.separator();
    // réglages du calque actif
    let a = c.info.active;
    let mut op = c.info.layers[a].opacity;
    ui.horizontal(|ui| {
        ui.label("Opacité");
        if ui.add(egui::Slider::new(&mut op, 0.0..=1.0).show_value(false)).changed() {
            c.set_props(a, |l| l.opacity = op);
        }
    });
    let mut mode = c.info.layers[a].mode;
    egui::ComboBox::from_label("Mode de fusion").selected_text(doc::blend_name(mode)).show_ui(ui, |ui| {
        for (name, m) in doc::BLENDS {
            ui.selectable_value(&mut mode, *m, *name);
        }
    });
    if mode != c.info.layers[a].mode {
        c.set_props(a, |l| l.mode = mode);
    }
    let mut lock = c.info.layers[a].lock_alpha;
    if ui.checkbox(&mut lock, "Verrouiller la transparence").changed() {
        c.set_props(a, |l| l.lock_alpha = lock);
    }
    ui.horizontal_wrapped(|ui| {
        if ui.button("Dupliquer").clicked() {
            c.duplicate_layer(a);
        }
        if ui.add_enabled(a > 0, egui::Button::new("Fusionner vers le bas")).clicked() {
            c.merge_down(a);
        }
        if ui.add_enabled(a + 1 < n, egui::Button::new("Monter")).clicked() {
            c.move_layer(a, a + 1);
        }
        if ui.add_enabled(a > 0, egui::Button::new("Descendre")).clicked() {
            c.move_layer(a, a - 1);
        }
        if ui.button("Effacer").clicked() {
            c.clear_active();
        }
        if ui.button("Supprimer").clicked() {
            c.delete_layer(a);
        }
    });
    ui.separator();
    ui.horizontal(|ui| {
        let mut vis = c.info.bg_visible;
        if ui.checkbox(&mut vis, "Fond").changed() {
            c.info.bg_visible = vis;
            c.changed();
            c.engine.invalidate();
        }
        let mut col = c32(c.info.bg);
        if ui.color_edit_button_srgba(&mut col).changed() {
            c.info.bg = [col.r() as f32 / 255.0, col.g() as f32 / 255.0, col.b() as f32 / 255.0];
            c.changed();
            c.engine.invalidate();
        }
    });
}

/// Disque de couleur façon Procreate : anneau de teinte + carré saturation/luminosité.
fn color_disc(ui: &mut egui::Ui, st: &mut UiState) {
    let size = 300.0f32;
    let (r, resp) = ui.allocate_exact_size(Vec2::splat(size), Sense::click_and_drag());
    let c = r.center();
    let r_out = size / 2.0 - 2.0;
    let r_in = r_out - 30.0;
    let p = ui.painter();
    let mut hsv = crate::procreate::rgb_to_hsv(st.color);
    // anneau de teinte
    let n = 96;
    let mut mesh = egui::Mesh::default();
    for i in 0..=n {
        let a = i as f32 / n as f32 * std::f32::consts::TAU;
        let col = c32(crate::procreate::hsv(i as f32 / n as f32, 1.0, 1.0));
        let d = Vec2::new(a.cos(), a.sin());
        mesh.colored_vertex(c + d * r_in, col);
        mesh.colored_vertex(c + d * r_out, col);
        if i > 0 {
            let k = (i * 2) as u32;
            mesh.add_triangle(k - 2, k - 1, k);
            mesh.add_triangle(k - 1, k + 1, k);
        }
    }
    p.add(mesh);
    // carré saturation / luminosité (interpolation bilinéaire exacte)
    let half = r_in * 0.68;
    let sq = Rect::from_center_size(c, Vec2::splat(half * 2.0));
    let mut m = egui::Mesh::default();
    m.colored_vertex(sq.left_top(), Color32::WHITE);
    m.colored_vertex(sq.right_top(), c32(crate::procreate::hsv(hsv[0], 1.0, 1.0)));
    m.colored_vertex(sq.right_bottom(), Color32::BLACK);
    m.colored_vertex(sq.left_bottom(), Color32::BLACK);
    m.add_triangle(0, 1, 2);
    m.add_triangle(0, 2, 3);
    p.add(m);
    // repères
    let ha = hsv[0] * std::f32::consts::TAU;
    let hp = c + Vec2::new(ha.cos(), ha.sin()) * (r_in + r_out) / 2.0;
    p.circle_stroke(hp, 12.0, Stroke::new(3.0, Color32::WHITE));
    let sp = Pos2::new(sq.left() + hsv[1] * sq.width(), sq.bottom() - hsv[2] * sq.height());
    p.circle_filled(sp, 11.0, c32(st.color));
    p.circle_stroke(sp, 11.0, Stroke::new(3.0, Color32::WHITE));
    // interaction
    let id = ui.scope_id().with("disc_drag");
    if resp.drag_started() || resp.clicked() {
        if let Some(pos) = resp.interact_pointer_pos() {
            let d = (pos - c).length();
            let zone: u8 = if d >= r_in - 6.0 { 1 } else if sq.expand(10.0).contains(pos) { 2 } else { 0 };
            ui.ctx().data_mut(|dm| dm.insert_temp(id, zone));
        }
    }
    if resp.dragged() || resp.clicked() {
        let zone: u8 = ui.ctx().data(|dm| dm.get_temp(id)).unwrap_or(0);
        if let Some(pos) = resp.interact_pointer_pos() {
            if zone == 1 {
                let v = pos - c;
                hsv[0] = (v.y.atan2(v.x) / std::f32::consts::TAU).rem_euclid(1.0);
            } else if zone == 2 {
                hsv[1] = ((pos.x - sq.left()) / sq.width()).clamp(0.0, 1.0);
                hsv[2] = ((sq.bottom() - pos.y) / sq.height()).clamp(0.0, 1.0);
            }
            if zone != 0 {
                st.color = crate::procreate::hsv(hsv[0], hsv[1], hsv[2]);
            }
        }
    }
    if resp.drag_stopped() || resp.clicked() {
        st.push_recent();
    }
}

fn swatch(ui: &mut egui::Ui, c: [f32; 3]) -> egui::Response {
    let (r, resp) = ui.allocate_exact_size(Vec2::splat(30.0), Sense::click());
    ui.painter().rect_filled(r, 6.0, c32(c));
    resp
}

fn color_panel(ui: &mut egui::Ui, st: &mut UiState, actions: &mut Vec<Action>) {
    ui.horizontal(|ui| {
        ui.heading("Couleurs");
        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            ui.selectable_value(&mut st.color_mode, 2, "Palettes");
            ui.selectable_value(&mut st.color_mode, 1, "Valeurs");
            ui.selectable_value(&mut st.color_mode, 0, "Disque");
        });
    });
    match st.color_mode {
        1 => {
            let mut col = c32(st.color);
            if egui::color_picker::color_picker_color32(ui, &mut col, egui::color_picker::Alpha::Opaque) {
                st.color = [col.r() as f32 / 255.0, col.g() as f32 / 255.0, col.b() as f32 / 255.0];
            }
            let mut hex = format!("{:02X}{:02X}{:02X}", col.r(), col.g(), col.b());
            ui.horizontal(|ui| {
                ui.label("Hexadécimal #");
                if ui.text_edit_singleline(&mut hex).changed() && hex.len() == 6 {
                    if let Ok(v) = u32::from_str_radix(&hex, 16) {
                        st.color = [((v >> 16) & 255) as f32 / 255.0, ((v >> 8) & 255) as f32 / 255.0, (v & 255) as f32 / 255.0];
                    }
                }
            });
        }
        2 => {
            if ui.button("Importer une palette Procreate (.swatches)").clicked() {
                actions.push(Action::PickFiles);
            }
            let mut del = None;
            for (pi, (name, cols)) in st.palettes.clone().iter().enumerate() {
                ui.horizontal(|ui| {
                    ui.label(RichText::new(name).strong());
                    if ui.small_button("✕").on_hover_text("Supprimer la palette").clicked() {
                        del = Some(pi);
                    }
                });
                ui.horizontal_wrapped(|ui| {
                    for c in cols {
                        if swatch(ui, *c).clicked() {
                            st.color = *c;
                            st.push_recent();
                        }
                    }
                    if ui.button("+").on_hover_text("Ajouter la couleur actuelle").clicked() {
                        st.palettes[pi].1.push(st.color);
                    }
                });
            }
            if let Some(i) = del {
                st.palettes.remove(i);
            }
            if ui.button("Nouvelle palette").clicked() {
                let n = st.palettes.len() + 1;
                st.palettes.push((format!("Palette {n}"), vec![st.color]));
            }
        }
        _ => color_disc(ui, st),
    }
    ui.label(RichText::new("Récentes").color(Color32::GRAY));
    ui.horizontal_wrapped(|ui| {
        for c in st.recent.clone() {
            if swatch(ui, c).clicked() {
                st.color = c;
            }
        }
    });
}

const FX: &[(u32, &str)] = &[
    (0, "Teinte, saturation, luminosité"),
    (6, "Balance des couleurs"),
    (2, "Luminosité et contraste"),
    (1, "Flou gaussien"),
    (4, "Bruit"),
    (5, "Noir et blanc"),
    (3, "Négatif"),
];

fn fx_default(kind: u32) -> [f32; 3] {
    match kind {
        0 => [0.0, 1.0, 0.0],
        1 => [8.0, 0.0, 0.0],
        2 => [0.0, 1.0, 0.0],
        4 => [0.15, 1.0, 0.0],
        5 => [1.0, 0.0, 0.0],
        _ => [0.0, 0.0, 0.0],
    }
}

fn adjust_panel(ui: &mut egui::Ui, st: &mut UiState, c: &mut Canvas) {
    match st.fx {
        None => {
            ui.heading("Ajustements");
            ui.label(RichText::new(format!("Sur le calque « {} »", c.info.layers[c.info.active].name)).color(Color32::GRAY));
            for (k, name) in FX {
                if ui.add(egui::Button::new(*name).min_size(Vec2::new(ui.available_width(), 38.0))).clicked() {
                    let p = fx_default(*k);
                    st.fx = Some((*k, p));
                    c.fx_preview(*k, p);
                }
            }
        }
        Some((kind, mut p)) => {
            ui.heading(FX.iter().find(|f| f.0 == kind).map(|f| f.1).unwrap_or("Ajustement"));
            let mut changed = false;
            let mut sl = |ui: &mut egui::Ui, label: &str, v: &mut f32, r: std::ops::RangeInclusive<f32>| {
                ui.horizontal(|ui| {
                    ui.label(label);
                    changed |= ui.add(egui::Slider::new(v, r)).changed();
                });
            };
            match kind {
                0 => {
                    sl(ui, "Teinte", &mut p[0], -0.5..=0.5);
                    sl(ui, "Saturation", &mut p[1], 0.0..=2.0);
                    sl(ui, "Luminosité", &mut p[2], -1.0..=1.0);
                }
                6 => {
                    sl(ui, "Cyan – Rouge", &mut p[0], -1.0..=1.0);
                    sl(ui, "Magenta – Vert", &mut p[1], -1.0..=1.0);
                    sl(ui, "Jaune – Bleu", &mut p[2], -1.0..=1.0);
                }
                2 => {
                    sl(ui, "Luminosité", &mut p[0], -0.5..=0.5);
                    sl(ui, "Contraste", &mut p[1], 0.0..=3.0);
                }
                1 => sl(ui, "Rayon (px)", &mut p[0], 0.5..=120.0),
                4 => sl(ui, "Quantité", &mut p[0], 0.0..=1.0),
                5 => sl(ui, "Intensité", &mut p[0], 0.0..=1.0),
                _ => {}
            }
            if changed {
                st.fx = Some((kind, p));
                c.fx_preview(kind, p);
            }
            ui.horizontal(|ui| {
                if ui.add(egui::Button::new(RichText::new("Appliquer").color(Color32::WHITE)).fill(ACCENT)).clicked() {
                    c.fx_apply();
                    st.fx = None;
                }
                if ui.button("Annuler").clicked() {
                    c.fx_cancel();
                    st.fx = None;
                }
                if ui.button("Réinitialiser").clicked() {
                    let d = fx_default(kind);
                    st.fx = Some((kind, d));
                    c.fx_preview(kind, d);
                }
            });
        }
    }
}

fn transform_panel(ui: &mut egui::Ui, st: &mut UiState, c: &mut Canvas) {
    let Some(mut x) = c.xform else {
        st.panel = None;
        return;
    };
    ui.label(RichText::new("Glisser pour déplacer · pincer pour agrandir et tourner").color(Color32::GRAY));
    let mut ch = false;
    ui.horizontal(|ui| {
        ui.label("Taille");
        let mut pct = x.scale * 100.0;
        if ui.add(egui::Slider::new(&mut pct, 5.0..=400.0).suffix(" %").logarithmic(true)).changed() {
            x.scale = pct / 100.0;
            ch = true;
        }
    });
    ui.horizontal(|ui| {
        ui.label("Rotation");
        let mut deg = x.rot.to_degrees();
        if ui.add(egui::Slider::new(&mut deg, -180.0..=180.0).suffix("°")).changed() {
            x.rot = deg.to_radians();
            ch = true;
        }
    });
    ui.horizontal_wrapped(|ui| {
        if ui.button("Miroir horizontal").clicked() {
            x.flip_h = !x.flip_h;
            ch = true;
        }
        if ui.button("Miroir vertical").clicked() {
            x.flip_v = !x.flip_v;
            ch = true;
        }
        if ui.button("Pivoter 90°").clicked() {
            x.rot += std::f32::consts::FRAC_PI_2;
            ch = true;
        }
        if ui.button("Réinitialiser").clicked() {
            x = crate::canvas::Xform::default();
            ch = true;
        }
    });
    if ch {
        c.xform = Some(x);
        c.transform_update();
    }
    ui.horizontal(|ui| {
        if ui.add(egui::Button::new(RichText::new("Valider").color(Color32::WHITE)).fill(ACCENT)).clicked() {
            c.transform_apply();
            st.panel = None;
        }
        if ui.button("Annuler").clicked() {
            c.transform_cancel();
            st.panel = None;
        }
    });
}

fn actions_panel(ui: &mut egui::Ui, st: &mut UiState, c: Option<&mut Canvas>, actions: &mut Vec<Action>) {
    ui.heading("Actions");
    ui.label(RichText::new("Ajouter").color(Color32::GRAY));
    if ui.button("Insérer une image ou un fichier").clicked() {
        actions.push(Action::PickFiles);
        st.panel = None;
    }
    ui.separator();
    ui.label(RichText::new("Partager").color(Color32::GRAY));
    ui.horizontal_wrapped(|ui| {
        for (k, label) in [("png", "PNG"), ("jpeg", "JPEG"), ("psd", "PSD (calques)")] {
            if ui.button(format!("Exporter en {label}")).clicked() {
                actions.push(Action::Export(k));
                st.panel = None;
            }
        }
    });
    if ui.button("Enregistrer maintenant").clicked() {
        actions.push(Action::Save);
    }
    ui.separator();
    ui.label(RichText::new("Toile").color(Color32::GRAY));
    if ui.button("Ajuster à l'écran").clicked() {
        actions.push(Action::Fit);
    }
    if let Some(c) = c {
        ui.label(format!("Dimensions : {} × {} px · {} calques", c.info.w, c.info.h, c.info.layers.len()));
    }
    if !cfg!(target_os = "android") && ui.button("Plein écran").clicked() {
        actions.push(Action::Fullscreen);
    }
    if ui.button("Masquer l'interface").clicked() {
        st.hide_ui = true;
        st.panel = None;
    }
    ui.separator();
    ui.label(RichText::new("Préférences").color(Color32::GRAY));
    ui.checkbox(&mut st.finger_draw, "Dessiner aussi au doigt (avec un stylet)");
    ui.checkbox(&mut st.quickshape, "Forme rapide (maintenir à la fin du trait)");
    ui.horizontal(|ui| {
        ui.label("Pression");
        ui.add(egui::Slider::new(&mut st.pressure_curve, 0.4..=2.5).show_value(false));
        ui.label(if st.pressure_curve < 0.85 { "douce" } else if st.pressure_curve > 1.25 { "ferme" } else { "normale" });
    });
    ui.label(RichText::new(format!("Version 0.1.{}", crate::updater::build_number())).size(12.0).color(Color32::GRAY));
    ui.separator();
    ui.label(RichText::new("Gestes : 2 doigts = annuler, 3 doigts = rétablir, pincer = zoom/rotation, 4 doigts = masquer l'interface.").size(12.0).color(Color32::GRAY));
}

fn gallery_panel(ui: &mut egui::Ui, st: &mut UiState, actions: &mut Vec<Action>) {
    ui.heading("Galerie");
    ui.label(RichText::new("Nouvelle toile").color(Color32::GRAY));
    ui.horizontal_wrapped(|ui| {
        for (name, w, h) in [("Écran", 2560, 1600), ("Carré 2048", 2048, 2048), ("A4 300 dpi", 2480, 3508), ("4K", 3840, 2160), ("Portrait", 1080, 1920)] {
            if ui.button(name).clicked() {
                actions.push(Action::NewCanvas(w, h));
                st.panel = None;
            }
        }
    });
    if ui.button("Importer (.procreate, image, pinceaux, palette)").clicked() {
        actions.push(Action::PickFiles);
        st.panel = None;
    }
    ui.separator();
    ui.label(RichText::new("Dessins précédents").color(Color32::GRAY));
    if st.gallery.is_none() {
        let mut list = Vec::new();
        if let Ok(rd) = std::fs::read_dir(doc::drawings_dir()) {
            let mut files: Vec<_> = rd.flatten().filter(|e| e.path().extension().is_some_and(|x| x == "yujin")).filter(|e| e.file_name() != "courant.yujin").collect();
            files.sort_by_key(|e| std::cmp::Reverse(e.metadata().and_then(|m| m.modified()).ok()));
            for e in files.into_iter().take(40) {
                let p = e.path();
                let tex = read_thumb(&p).map(|(w, h, px)| ui.ctx().load_texture(p.to_string_lossy(), egui::ColorImage::from_rgba_unmultiplied([w as usize, h as usize], &px), Default::default()));
                list.push((p.clone(), p.file_stem().map(|s| s.to_string_lossy().to_string()).unwrap_or_default(), tex));
            }
        }
        st.gallery = Some(list);
    }
    let list = st.gallery.as_ref().unwrap();
    if list.is_empty() {
        ui.label("Aucun autre dessin pour l'instant.");
    }
    let mut open = None;
    ui.horizontal_wrapped(|ui| {
        for (p, _name, tex) in list {
            let (r, resp) = ui.allocate_exact_size(Vec2::new(104.0, 104.0), Sense::click());
            ui.painter().rect_filled(r, 8.0, Color32::from_gray(60));
            if let Some(t) = tex {
                let s = t.size_vec2();
                let k = (96.0 / s.x).min(96.0 / s.y);
                ui.painter().image(t.id(), Rect::from_center_size(r.center(), s * k), Rect::from_min_max(Pos2::ZERO, Pos2::new(1.0, 1.0)), Color32::WHITE);
            }
            if resp.clicked() {
                open = Some(p.clone());
            }
        }
    });
    if let Some(p) = open {
        actions.push(Action::Open(p));
        st.panel = None;
        st.gallery = None;
    }
}

fn read_thumb(p: &std::path::Path) -> Option<(u32, u32, Vec<u8>)> {
    use std::io::Read;
    let f = std::fs::File::open(p).ok()?;
    let mut z = zip::ZipArchive::new(f).ok()?;
    let mut data = Vec::new();
    z.by_name("apercu.png").ok()?.read_to_end(&mut data).ok()?;
    doc::decode_png(&data)
}
