//! Interface façon Procreate (egui) : barre du haut, barre latérale, panneaux.

use crate::brush::Brush;
use crate::canvas::{Canvas, Tool};
use crate::doc;
use egui::{Align2, Color32, CornerRadius, Pos2, Rect, RichText, Sense, Stroke, Vec2};
use serde::{Deserialize, Serialize};
use std::path::PathBuf;
use std::time::Instant;

pub const ACCENT: Color32 = Color32::from_rgb(139, 92, 246);
const BAR: Color32 = Color32::from_rgba_premultiplied(24, 24, 27, 235);
const PANEL: Color32 = Color32::from_rgb(30, 30, 34);

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Panel {
    Gallery,
    Adjust,
    Transform,
    Select,
    Actions,
    Brushes,
    Layers,
    Color,
}

pub enum Action {
    NewCanvas(u32, u32),
    Open(PathBuf),
    Fit,
    Save,
    Export(&'static str),
    Fullscreen,
    OpenUrl(String),
    Restart,
    DismissUpdate,
    PickFiles,
    DeleteBrush(String),
    Gallery,
    DeleteDrawings(Vec<PathBuf>),
    DuplicateDrawings(Vec<PathBuf>),
    Rename(PathBuf, String),
}

pub struct GalleryEntry {
    pub path: PathBuf,
    pub name: String,
    pub w: u32,
    pub h: u32,
    pub tex: Option<egui::TextureHandle>,
}

#[derive(Default)]
pub struct GalleryUi {
    pub list: Option<Vec<GalleryEntry>>,
    pub selecting: Option<std::collections::HashSet<PathBuf>>,
    pub rename: Option<(PathBuf, String)>,
    pub new_open: bool,
    pub custom: (u32, u32),
    pub confirm_delete: bool,
}

#[derive(Serialize, Deserialize)]
#[serde(default)]
pub struct UiState {
    #[serde(skip, default = "default_tool")]
    pub tool: Tool,
    pub brush: String,
    pub eraser_brush: String,
    pub palettes: Vec<(String, Vec<[f32; 3]>)>,
    /// onglet du panneau Couleurs : 0 disque, 1 classique, 2 harmonie, 3 valeurs, 4 palettes
    pub color_mode: u8,
    pub color_float: bool,
    pub smudge_brush: String,
    pub size_smudge: f32,
    pub op_smudge: f32,
    pub size_brush: f32,
    pub op_brush: f32,
    pub size_eraser: f32,
    pub op_eraser: f32,
    pub color: [f32; 3],
    pub recent: Vec<[f32; 3]>,
    pub pressure_curve: f32,
    pub quickshape: bool,
    pub finger_draw: bool,
    pub pen_seen: bool,
    #[serde(skip)]
    pub panel: Option<Panel>,
    #[serde(skip)]
    pub hide_ui: bool,
    #[serde(skip)]
    pub eyedropper: bool,
    #[serde(skip)]
    toast: Option<(String, Instant)>,
    #[serde(skip)]
    pub gal: GalleryUi,
    #[serde(skip)]
    pub brush_cat: String,
    /// aperçus rendus des pinceaux (id -> texture)
    #[serde(skip)]
    pub previews: std::collections::HashMap<String, egui::TextureHandle>,
    #[serde(default)]
    pub harmony: u8,
    /// ajustement en cours : (type, réglages)
    #[serde(skip)]
    pub fx: Option<(u32, [f32; 3])>,
}

fn default_tool() -> Tool {
    Tool::Brush
}

impl Default for UiState {
    fn default() -> Self {
        UiState {
            tool: Tool::Brush,
            brush: "encre-tech".into(),
            eraser_brush: "aero-doux".into(),
            palettes: Vec::new(),
            color_mode: 0,
            color_float: false,
            smudge_brush: "pinceau-rond".into(),
            size_smudge: 0.35,
            op_smudge: 0.6,
            size_brush: 0.25,
            op_brush: 1.0,
            size_eraser: 0.35,
            op_eraser: 1.0,
            color: [0.12, 0.1, 0.16],
            recent: Vec::new(),
            pressure_curve: 1.0,
            quickshape: true,
            finger_draw: false,
            pen_seen: false,
            panel: None,
            hide_ui: false,
            eyedropper: false,
            toast: None,
            gal: GalleryUi { custom: (2048, 2048), ..Default::default() },
            brush_cat: String::new(),
            previews: Default::default(),
            harmony: 0,
            fx: None,
        }
    }
}

pub fn slider_to_px(v: f32, max: f32) -> f32 {
    1.0 + (max - 1.0) * v.clamp(0.0, 1.0).powi(2)
}

impl UiState {
    fn path() -> PathBuf {
        doc::data_dir().join("reglages.json")
    }
    pub fn load() -> Self {
        std::fs::read_to_string(Self::path()).ok().and_then(|s| serde_json::from_str(&s).ok()).unwrap_or_default()
    }
    pub fn save(&self) {
        let _ = std::fs::create_dir_all(doc::data_dir());
        if let Ok(s) = serde_json::to_string_pretty(self) {
            let _ = std::fs::write(Self::path(), s);
        }
    }
    pub fn toast(&mut self, s: String) {
        self.toast = Some((s, Instant::now()));
    }
    pub fn push_recent(&mut self) {
        let c = self.color;
        self.recent.retain(|r| r.iter().zip(c.iter()).map(|(a, b)| (a - b).abs()).sum::<f32>() > 0.01);
        self.recent.insert(0, c);
        self.recent.truncate(10);
    }
    pub fn invalidate_gallery(&mut self) {
        self.gal.list = None;
    }

    pub fn brush_cat_set(&mut self, c: &str) {
        self.brush_cat = c.to_string();
        self.panel = Some(Panel::Brushes);
    }
    pub fn bump_size(&mut self, d: f32) {
        match self.tool {
            Tool::Brush => self.size_brush = (self.size_brush + d).clamp(0.0, 1.0),
            Tool::Eraser => self.size_eraser = (self.size_eraser + d).clamp(0.0, 1.0),
            Tool::Smudge => self.size_smudge = (self.size_smudge + d).clamp(0.0, 1.0),
        }
    }
    pub fn is_over_ui(&self, ctx: &egui::Context, pos: Pos2) -> bool {
        ctx.layer_id_at(pos).is_some_and(|l| l.order != egui::Order::Background)
    }
}

fn c32(c: [f32; 3]) -> Color32 {
    Color32::from_rgb((c[0] * 255.0).round() as u8, (c[1] * 255.0).round() as u8, (c[2] * 255.0).round() as u8)
}

pub fn setup_style(ctx: &egui::Context) {
    let mut v = egui::Visuals::dark();
    v.selection.bg_fill = ACCENT;
    v.widgets.hovered.bg_fill = Color32::from_rgb(55, 55, 62);
    v.widgets.inactive.bg_fill = Color32::from_rgb(44, 44, 50);
    v.window_fill = PANEL;
    v.panel_fill = PANEL;
    ctx.set_visuals(v);
    ctx.all_styles_mut(|s| {
        s.spacing.item_spacing = Vec2::new(8.0, 8.0);
        s.spacing.button_padding = Vec2::new(10.0, 6.0);
        s.spacing.interact_size.y = 34.0;
        s.spacing.slider_width = 180.0;
        for (_, f) in s.text_styles.iter_mut() {
            f.size *= 1.15;
        }
    });
}

/// Dessine la toile (texture GPU) avec la vue courante.
pub fn paint_canvas(ctx: &egui::Context, c: &Canvas, ids: (egui::TextureId, egui::TextureId)) {
    let p = ctx.layer_painter(egui::LayerId::background());
    let v = &c.view;
    let (w, h) = (c.info.w as f32, c.info.h as f32);
    let corners = [Pos2::new(0.0, 0.0), Pos2::new(w, 0.0), Pos2::new(w, h), Pos2::new(0.0, h)];
    let uvs = [Pos2::new(0.0, 0.0), Pos2::new(1.0, 0.0), Pos2::new(1.0, 1.0), Pos2::new(0.0, 1.0)];
    let tex = if v.scale * ctx.pixels_per_point() >= 2.0 { ids.1 } else { ids.0 };
    // ombre
    let mut sh = egui::Mesh::default();
    for k in corners {
        sh.colored_vertex(v.to_screen(k) + Vec2::new(0.0, 3.0), Color32::from_black_alpha(90));
    }
    sh.add_triangle(0, 1, 2);
    sh.add_triangle(0, 2, 3);
    p.add(sh);
    if !c.info.bg_visible {
        // damier sous un fond transparent
        let r = Rect::from_points(&corners.map(|k| v.to_screen(k)));
        p.rect_filled(r, 0.0, Color32::from_gray(200));
    }
    let mut m = egui::Mesh::with_texture(tex);
    for (k, uv) in corners.iter().zip(uvs) {
        m.vertices.push(egui::epaint::Vertex { pos: v.to_screen(*k), uv, color: Color32::WHITE });
    }
    m.add_triangle(0, 1, 2);
    m.add_triangle(0, 2, 3);
    p.add(m);
    // contour de la sélection (fourmis)
    if let Some((poly, _)) = &c.selection {
        let pts: Vec<Pos2> = poly.iter().chain(poly.first()).map(|q| v.to_screen(Pos2::new(q.0, q.1))).collect();
        let phase = (ctx.input(|i| i.time) * 20.0) as f32;
        p.add(egui::Shape::line(pts.clone(), Stroke::new(1.5, Color32::WHITE)));
        p.extend(egui::Shape::dashed_line_with_offset(&pts, Stroke::new(1.5, Color32::BLACK), &[6.0], &[6.0], phase));
        ctx.request_repaint_after(std::time::Duration::from_millis(80));
    }
}

/// Lasso en cours de tracé.
pub fn paint_lasso(ctx: &egui::Context, c: &Canvas, pts: &[(f32, f32)]) {
    if pts.len() < 2 {
        return;
    }
    let p = ctx.layer_painter(egui::LayerId::background());
    let s: Vec<Pos2> = pts.iter().map(|q| c.view.to_screen(Pos2::new(q.0, q.1))).collect();
    p.add(egui::Shape::line(s.clone(), Stroke::new(2.0, Color32::WHITE)));
    p.extend(egui::Shape::dashed_line(&s, Stroke::new(2.0, ACCENT), 6.0, 6.0));
}

#[derive(Clone, Copy)]
enum Icon {
    Undo,
    Redo,
    Picker,
}

/// Bouton avec une icône dessinée (pas de dépendance aux polices d'icônes).
fn icon_button(ui: &mut egui::Ui, icon: Icon, on: bool, enabled: bool) -> egui::Response {
    let (r, resp) = ui.allocate_exact_size(Vec2::splat(40.0), if enabled { Sense::click() } else { Sense::hover() });
    let p = ui.painter();
    let bg = if on { ACCENT } else if resp.hovered() && enabled { Color32::from_rgb(60, 60, 68) } else { Color32::from_rgb(44, 44, 50) };
    p.rect_filled(r, 10.0, bg);
    let col = if enabled { Color32::from_gray(235) } else { Color32::from_gray(110) };
    let st = Stroke::new(2.2, col);
    let c = r.center();
    match icon {
        Icon::Undo | Icon::Redo => {
            let s = if matches!(icon, Icon::Undo) { 1.0 } else { -1.0 };
            // arc
            let pts: Vec<Pos2> = (0..=16)
                .map(|i| {
                    let a = std::f32::consts::PI * (0.15 + 1.1 * i as f32 / 16.0);
                    Pos2::new(c.x + s * 8.0 * a.cos(), c.y + 2.0 - 8.0 * a.sin())
                })
                .collect();
            p.add(egui::Shape::line(pts.clone(), st));
            let tip = pts[16];
            p.line_segment([tip, tip + Vec2::new(s * 5.0, -4.0)], st);
            p.line_segment([tip, tip + Vec2::new(s * 6.0, 4.0)], st);
        }
        Icon::Picker => {
            p.line_segment([c + Vec2::new(-8.0, 8.0), c + Vec2::new(4.0, -4.0)], Stroke::new(3.0, col));
            p.circle_filled(c + Vec2::new(6.0, -6.0), 4.5, col);
        }
    }
    resp
}

/// Icônes de la barre du haut (dessinées, façon Procreate).
fn bar_icon(ui: &mut egui::Ui, label: &str, on: bool) -> egui::Response {
    let w = if ui.ctx().content_rect().width() < 500.0 { 32.0 } else { 38.0 };
    let (r, resp) = ui.allocate_exact_size(Vec2::new(w, 34.0), Sense::click());
    let col = if on { ACCENT } else if resp.hovered() { Color32::WHITE } else { Color32::from_gray(225) };
    let st = Stroke::new(1.6, col);
    let p = ui.painter();
    let c = r.center();
    // icônes dessinées sur une grille de ±10, réduites comme dans Procreate
    let k = 0.78;
    let v = |x: f32, y: f32| c + Vec2::new(x * k, y * k);
    match label {
        "Galerie" => {
            for (x, y) in [(-6.0, -6.0), (6.0, -6.0), (-6.0, 6.0), (6.0, 6.0)] {
                p.rect_stroke(Rect::from_center_size(v(x, y), Vec2::splat(9.0 * k)), 2.0, st, egui::StrokeKind::Middle);
            }
        }
        "Actions" => {
            // clé : manche + tête
            p.line_segment([v(-8.0, 8.0), v(3.0, -3.0)], Stroke::new(3.0, col));
            p.circle_stroke(v(6.0, -6.0), 5.0 * k, st);
        }
        "Ajustements" => {
            // baguette magique
            p.line_segment([v(-9.0, 9.0), v(4.0, -4.0)], Stroke::new(3.0, col));
            for (a, b) in [((7.0, -11.0), (7.0, -5.0)), ((4.0, -8.0), (10.0, -8.0))] {
                p.line_segment([v(a.0, a.1), v(b.0, b.1)], st);
            }
        }
        "Sélection" => {
            // ruban en S : deux demi-cercles
            let mut pts = Vec::new();
            for i in 0..=14 {
                let a = (20.0f32 + (270.0 - 20.0) * i as f32 / 14.0).to_radians();
                pts.push(v(4.5 * a.cos(), -4.5 - 4.5 * a.sin()));
            }
            for i in 0..=14 {
                let a = (90.0f32 - (90.0 + 160.0) * i as f32 / 14.0).to_radians();
                pts.push(v(4.5 * a.cos(), 4.5 - 4.5 * a.sin()));
            }
            p.add(egui::Shape::line(pts, Stroke::new(2.2, col)));
        }
        "Estompe" => {
            // doigt tendu
            p.line_segment([v(-9.0, 9.0), v(6.0, -6.0)], Stroke::new(4.0, col));
            p.circle_filled(v(7.0, -7.0), 2.6, col);
        }
        "Transformer" => {
            let pts = vec![v(-7.0, -9.0), v(7.0, 2.0), v(1.0, 2.0), v(4.0, 9.0), v(1.0, 10.0), v(-2.0, 3.0), v(-7.0, 7.0)];
            p.add(egui::Shape::closed_line(pts, st));
        }
        "Pinceau" => {
            p.line_segment([v(9.0, -9.0), v(-1.0, 1.0)], Stroke::new(2.5, col));
            p.add(egui::Shape::convex_polygon(vec![v(-1.0, 1.0), v(-4.0, -2.0), v(-10.0, 9.0), v(1.0, 4.0)], col, Stroke::NONE));
        }
        "Gomme" => {
            let pts = vec![v(-9.0, 4.0), v(1.0, -8.0), v(9.0, -1.0), v(-1.0, 10.0)];
            p.add(egui::Shape::closed_line(pts, st));
            p.line_segment([v(-4.0, -2.0), v(4.0, 5.0)], st);
        }
        "Calques" => {
            for dy in [4.0, -3.0] {
                let pts = vec![v(0.0, dy - 6.0), v(10.0, dy), v(0.0, dy + 6.0), v(-10.0, dy)];
                p.add(egui::Shape::convex_polygon(pts, Color32::from_rgb(28, 28, 32), st));
            }
        }
        _ => {
            p.text(c, Align2::CENTER_CENTER, label, egui::FontId::proportional(15.0), col);
        }
    }
    resp.on_hover_text(label)
}

fn bar_button(ui: &mut egui::Ui, label: &str, on: bool) -> egui::Response {
    let t = RichText::new(label).size(16.0).color(if on { ACCENT } else { Color32::from_gray(230) });
    ui.add(egui::Button::new(t).frame(false).min_size(Vec2::new(44.0, 40.0)))
}

fn panel_frame() -> egui::Frame {
    egui::Frame::new().fill(PANEL).corner_radius(CornerRadius::same(14)).inner_margin(14.0).stroke(Stroke::new(1.0, Color32::from_gray(55)))
}

fn toggle_panel(ui: &mut UiState, p: Panel) {
    ui.panel = if ui.panel == Some(p) { None } else { Some(p) };

}

/// Construit l'interface et renvoie les actions à exécuter.
pub fn build(ctx: &egui::Context, st: &mut UiState, mut canvas: Option<&mut Canvas>, brushes: &[Brush], update: Option<&crate::updater::Status>) -> Vec<Action> {
    let mut actions = Vec::new();
    let screen = ctx.content_rect();
    show_update(ctx, update, &mut actions);
    if st.hide_ui {
        egui::Area::new(egui::Id::unique("show_ui")).anchor(Align2::RIGHT_TOP, Vec2::new(-8.0, 8.0)).show(ctx, |ui| {
            if ui.button("Afficher l'interface").clicked() {
                st.hide_ui = false;
            }
        });
        return actions;
    }

    // ---- Barre du haut ----
    egui::Area::new(egui::Id::unique("topbar")).fixed_pos(Pos2::ZERO).order(egui::Order::Middle).show(ctx, |ui| {
        egui::Frame::new().fill(BAR).inner_margin(egui::Margin::symmetric(8, 1)).show(ui, |ui| {
            ui.set_width(screen.width() - 16.0);
            ui.spacing_mut().item_spacing.x = 2.0;
            ui.horizontal(|ui| {
                let narrow = screen.width() < 520.0;
                if !narrow {
                    if ui.add(egui::Button::new(RichText::new("Galerie").size(15.0).color(Color32::from_gray(230))).frame(false).min_size(Vec2::new(60.0, 34.0))).clicked() {
                        actions.push(Action::Gallery);
                    }
                } else if bar_icon(ui, "Galerie", false).clicked() {
                    actions.push(Action::Gallery);
                }
                if bar_icon(ui, "Actions", st.panel == Some(Panel::Actions)).clicked() {
                    toggle_panel(st, Panel::Actions);
                }
                if bar_icon(ui, "Ajustements", st.panel == Some(Panel::Adjust)).clicked() {
                    toggle_panel(st, Panel::Adjust);
                }
                if bar_icon(ui, "Sélection", st.panel == Some(Panel::Select)).clicked() {
                    toggle_panel(st, Panel::Select);
                }
                if bar_icon(ui, "Transformer", st.panel == Some(Panel::Transform)).clicked() {
                    if st.panel == Some(Panel::Transform) {
                        if let Some(c) = canvas.as_deref_mut() {
                            c.transform_apply();
                        }
                        st.panel = None;
                    } else if st.fx.is_none() {
                        st.panel = Some(Panel::Transform);
                        if let Some(c) = canvas.as_deref_mut() {
                            c.transform_start();
                        }
                    }
                }
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    // pastille de couleur
                    let (r, resp) = ui.allocate_exact_size(Vec2::new(34.0, 34.0), Sense::click());
                    ui.painter().circle_filled(r.center(), 11.0, c32(st.color));
                    ui.painter().circle_stroke(r.center(), 12.5, Stroke::new(1.5, Color32::from_gray(200)));
                    if resp.clicked() {
                        if st.color_float {
                            st.color_float = false;
                        } else {
                            toggle_panel(st, Panel::Color);
                        }
                    }
                    if bar_icon(ui, "Calques", st.panel == Some(Panel::Layers)).clicked() {
                        toggle_panel(st, Panel::Layers);
                    }
                    for (name, tool) in [("Gomme", Tool::Eraser), ("Estompe", Tool::Smudge), ("Pinceau", Tool::Brush)] {
                        if bar_icon(ui, name, st.tool == tool).clicked() {
                            if st.tool == tool {
                                toggle_panel(st, Panel::Brushes);
                            } else {
                                st.tool = tool;
                            }
                        }
                    }
                });
            });
        });
    });

    // ---- Couleurs en fenêtre flottante (détachée) ----
    if st.color_float {
        let mut open = true;
        egui::Window::new("Couleurs")
            .open(&mut open)
            .collapsible(false)
            .resizable(false)
            .default_pos(Pos2::new(screen.width() - 300.0, 60.0))
            .frame(panel_frame())
            .show(ctx, |ui| {
                ui.set_width(250.0);
                color_body(ui, st, &mut actions, 230.0);
            });
        if !open {
            st.color_float = false;
        }
    }

    // ---- Barre latérale ----
    egui::Area::new(egui::Id::unique("sidebar")).anchor(Align2::LEFT_CENTER, Vec2::new(8.0, 0.0)).order(egui::Order::Middle).show(ctx, |ui| {
        egui::Frame::new().fill(BAR).corner_radius(CornerRadius::same(14)).inner_margin(8.0).show(ui, |ui| {
            ui.spacing_mut().slider_width = 170.0;
            ui.vertical_centered(|ui| {
                let (size, op) = match st.tool {
                    Tool::Brush => (&mut st.size_brush, &mut st.op_brush),
                    Tool::Eraser => (&mut st.size_eraser, &mut st.op_eraser),
                    Tool::Smudge => (&mut st.size_smudge, &mut st.op_smudge),
                };
                ui.label(RichText::new("Taille").size(11.0).color(Color32::GRAY));
                ui.add(egui::Slider::new(size, 0.0..=1.0).vertical().show_value(false));
                ui.add_space(6.0);
                if icon_button(ui, Icon::Picker, st.eyedropper, true).on_hover_text("Pipette").clicked() {
                    st.eyedropper = !st.eyedropper;
                }
                ui.add_space(6.0);
                ui.add(egui::Slider::new(op, 0.0..=1.0).vertical().show_value(false));
                ui.label(RichText::new("Opacité").size(11.0).color(Color32::GRAY));
                ui.add_space(8.0);
                let (can_undo, can_redo) = canvas.as_ref().map(|c| (!c.undo.is_empty(), !c.redo.is_empty())).unwrap_or((false, false));
                if icon_button(ui, Icon::Undo, false, can_undo).on_hover_text("Annuler").clicked() {
                    if let Some(c) = canvas.as_deref_mut() {
                        c.undo();
                    }
                }
                if icon_button(ui, Icon::Redo, false, can_redo).on_hover_text("Rétablir").clicked() {
                    if let Some(c) = canvas.as_deref_mut() {
                        c.redo();
                    }
                }
            });
        });
    });

    // ---- Panneaux ----
    if let Some(p) = st.panel {
        let (anchor, off) = match p {
            Panel::Gallery | Panel::Actions | Panel::Adjust => (Align2::LEFT_TOP, Vec2::new(60.0, 52.0)),
            Panel::Transform | Panel::Select => (Align2::CENTER_BOTTOM, Vec2::new(0.0, -16.0)),
            _ => (Align2::RIGHT_TOP, Vec2::new(-10.0, 52.0)),
        };
        egui::Area::new(egui::Id::unique("panel")).anchor(anchor, off).order(egui::Order::Foreground).show(ctx, |ui| {
            panel_frame().show(ui, |ui| {
                if p == Panel::Brushes {
                    ui.set_width(540.0f32.min(screen.width() - 48.0));
                    let h = (screen.height() - 110.0).min(640.0).max(200.0);
                    brushes_panel(ui, st, brushes, &mut actions, h);
                    return;
                }
                ui.set_width(360.0f32.min(screen.width() - 24.0));
                ui.set_max_height(screen.height() - 90.0);
                egui::ScrollArea::vertical().show(ui, |ui| match p {
                    Panel::Brushes => {}
                    Panel::Layers => {
                        if let Some(c) = canvas.as_deref_mut() {
                            layers_panel(ui, c);
                        }
                    }
                    Panel::Color => color_panel(ui, st, &mut actions),
                    Panel::Actions => actions_panel(ui, st, canvas.as_deref_mut(), &mut actions),
                    Panel::Gallery => {}
                    Panel::Select => {
                        if let Some(c) = canvas.as_deref_mut() {
                            select_panel(ui, st, c);
                        }
                    }
                    Panel::Transform => {
                        if let Some(c) = canvas.as_deref_mut() {
                            transform_panel(ui, st, c);
                        }
                    }
                    Panel::Adjust => {
                        if let Some(c) = canvas.as_deref_mut() {
                            adjust_panel(ui, st, c);
                        }
                    }
                });
            });
        });
    }

    // ---- Message ----
    if let Some((msg, t)) = &st.toast {
        if t.elapsed().as_secs_f32() < 3.0 {
            egui::Area::new(egui::Id::unique("toast")).anchor(Align2::CENTER_BOTTOM, Vec2::new(0.0, -30.0)).order(egui::Order::Tooltip).show(ctx, |ui| {
                egui::Frame::new().fill(Color32::from_rgb(42, 37, 51)).corner_radius(CornerRadius::same(12)).inner_margin(12.0).show(ui, |ui| {
                    ui.label(RichText::new(msg.as_str()).color(Color32::WHITE));
                });
            });
            ctx.request_repaint_after(std::time::Duration::from_millis(250));
        } else {
            st.toast = None;
        }
    }
    actions
}

/// Petite icône dessinée pour une catégorie de pinceaux (index dans brush::CATEGORIES).
fn cat_icon(p: &egui::Painter, r: Rect, idx: Option<usize>, col: Color32) {
    let c = r.center();
    let k = r.width() / 2.0;
    let st = Stroke::new(1.6, col);
    let at = |x: f32, y: f32| Pos2::new(c.x + x * k, c.y + y * k);
    match idx {
        // Esquisse : crayon
        Some(0) => {
            p.line_segment([at(-0.7, 0.7), at(0.5, -0.5)], Stroke::new(3.5, col));
            p.line_segment([at(-0.85, 0.85), at(-0.7, 0.7)], Stroke::new(1.5, col));
        }
        // Encrage : plume
        Some(1) => {
            p.add(egui::Shape::convex_polygon(vec![at(0.0, -0.8), at(0.45, 0.1), at(0.0, 0.8), at(-0.45, 0.1)], Color32::TRANSPARENT, st));
            p.line_segment([at(0.0, -0.1), at(0.0, 0.8)], st);
        }
        // Dessin : crayon et trait
        Some(2) => {
            p.line_segment([at(-0.2, 0.5), at(0.6, -0.6)], Stroke::new(3.0, col));
            p.line_segment([at(-0.8, 0.8), at(0.2, 0.8)], st);
        }
        // Peinture : pinceau
        Some(3) => {
            p.line_segment([at(0.7, -0.7), at(-0.1, 0.1)], Stroke::new(2.0, col));
            p.circle_filled(at(-0.35, 0.4), 0.3 * k, col);
        }
        // Artistique : palette
        Some(4) => {
            p.circle_stroke(c, 0.75 * k, st);
            for (x, y) in [(-0.3, -0.3), (0.2, -0.4), (0.35, 0.05)] {
                p.circle_filled(at(x, y), 0.12 * k, col);
            }
        }
        // Calligraphie : boucle
        Some(5) => {
            let pts: Vec<Pos2> = (0..30).map(|i| { let t = i as f32 / 29.0 * 6.3; at(-0.8 + t / 4.0 + t.sin() * 0.2, -t.cos() * 0.45) }).collect();
            p.add(egui::Shape::line(pts, Stroke::new(2.0, col)));
        }
        // Aérographie : nuage de points
        Some(6) => {
            for i in 0..14 {
                let a = i as f32 * 2.4;
                let rr = 0.15 + (i as f32 * 0.37).fract() * 0.6;
                p.circle_filled(at(a.cos() * rr, a.sin() * rr), 0.07 * k, col);
            }
        }
        // Textures : grille
        Some(7) => {
            for i in 0..4 {
                let v = -0.75 + i as f32 * 0.5;
                p.line_segment([at(v, -0.75), at(v, 0.75)], Stroke::new(1.0, col));
                p.line_segment([at(-0.75, v), at(0.75, v)], Stroke::new(1.0, col));
            }
        }
        // Abstrait : formes
        Some(8) => {
            p.circle_stroke(at(-0.3, -0.25), 0.35 * k, st);
            p.add(egui::Shape::convex_polygon(vec![at(0.15, 0.75), at(0.55, 0.0), at(0.85, 0.75)], Color32::TRANSPARENT, st));
        }
        // Fusains : bâton
        Some(9) => {
            p.line_segment([at(-0.6, 0.6), at(0.6, -0.6)], Stroke::new(5.0, col));
        }
        // Éléments : goutte / flamme
        Some(10) | Some(17) => {
            p.circle_filled(at(0.0, 0.25), 0.45 * k, col);
            p.add(egui::Shape::convex_polygon(vec![at(0.0, -0.85), at(0.4, 0.1), at(-0.4, 0.1)], col, Stroke::NONE));
        }
        // Aérosols : bombe
        Some(11) => {
            p.rect_stroke(Rect::from_min_max(at(-0.35, -0.3), at(0.35, 0.85)), 2.0, st, egui::StrokeKind::Middle);
            p.rect_filled(Rect::from_min_max(at(-0.12, -0.6), at(0.12, -0.3)), 1.0, col);
            p.circle_filled(at(0.55, -0.6), 0.06 * k, col);
            p.circle_filled(at(0.75, -0.4), 0.06 * k, col);
        }
        // Retouches : étincelle
        Some(12) => {
            p.line_segment([at(0.0, -0.8), at(0.0, 0.8)], st);
            p.line_segment([at(-0.8, 0.0), at(0.8, 0.0)], st);
            p.line_segment([at(-0.4, -0.4), at(0.4, 0.4)], Stroke::new(1.0, col));
            p.line_segment([at(-0.4, 0.4), at(0.4, -0.4)], Stroke::new(1.0, col));
        }
        // Vintage : trame
        Some(13) => {
            for y in 0..3 {
                for x in 0..3 {
                    p.circle_filled(at(-0.5 + x as f32 * 0.5, -0.5 + y as f32 * 0.5), (0.08 + 0.05 * (x + y) as f32) * k, col);
                }
            }
        }
        // Luminance : soleil
        Some(14) => {
            p.circle_filled(c, 0.3 * k, col);
            for i in 0..8 {
                let a = i as f32 * std::f32::consts::FRAC_PI_4;
                p.line_segment([at(a.cos() * 0.5, a.sin() * 0.5), at(a.cos() * 0.8, a.sin() * 0.8)], st);
            }
        }
        // Industriel : écrou
        Some(15) => {
            let pts: Vec<Pos2> = (0..6).map(|i| { let a = i as f32 * 1.047 + 0.52; at(a.cos() * 0.8, a.sin() * 0.8) }).collect();
            p.add(egui::Shape::convex_polygon(pts, Color32::TRANSPARENT, st));
            p.circle_stroke(c, 0.3 * k, st);
        }
        // Organique : feuille
        Some(16) => {
            p.add(egui::Shape::convex_polygon(vec![at(-0.7, 0.7), at(-0.5, -0.2), at(0.0, -0.6), at(0.7, -0.7), at(0.6, 0.0), at(0.2, 0.5)], Color32::TRANSPARENT, st));
            p.line_segment([at(-0.7, 0.7), at(0.4, -0.4)], Stroke::new(1.0, col));
        }
        // Importés : boîte
        _ => {
            p.rect_stroke(Rect::from_center_size(at(0.0, 0.15), Vec2::new(1.4 * k, 1.0 * k)), 2.0, st, egui::StrokeKind::Middle);
            p.line_segment([at(-0.7, -0.35), at(0.0, -0.75)], st);
            p.line_segment([at(0.7, -0.35), at(0.0, -0.75)], st);
        }
    }
}

fn brushes_panel(ui: &mut egui::Ui, st: &mut UiState, brushes: &[Brush], actions: &mut Vec<Action>, height: f32) {
    ui.horizontal(|ui| {
        ui.heading(match st.tool {
            Tool::Eraser => "Gomme",
            Tool::Smudge => "Estompe",
            Tool::Brush => "Bibliothèque de pinceaux",
        });
        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            if ui.add(egui::Button::new(RichText::new("+").size(22.0)).frame(false)).on_hover_text("Importer des pinceaux Procreate (.brush, .brushset)").clicked() {
                actions.push(Action::PickFiles);
            }
        });
    });
    ui.add_space(4.0);
    let cats = crate::library::categories(brushes);
    if !cats.contains(&st.brush_cat) {
        // catégorie du pinceau actif par défaut
        let cur = match st.tool {
            Tool::Eraser => &st.eraser_brush,
            Tool::Smudge => &st.smudge_brush,
            Tool::Brush => &st.brush,
        };
        st.brush_cat = brushes.iter().find(|b| &b.id == cur).map(|b| b.cat.clone()).filter(|c| cats.contains(c)).unwrap_or_else(|| cats.first().cloned().unwrap_or_default());
    }
    let total = ui.available_width();
    let narrow = total < 440.0;
    let left_w = if narrow { 128.0 } else { 172.0 };
    let tool = st.tool;
    let mut picked: Option<&Brush> = None;
    ui.horizontal_top(|ui| {
        // ---- colonne des catégories ----
        ui.allocate_ui_with_layout(Vec2::new(left_w, height), egui::Layout::top_down(egui::Align::Min), |ui| {
            egui::ScrollArea::vertical().id_salt("cats").max_height(height).show(ui, |ui| {
                ui.spacing_mut().item_spacing.y = 2.0;
                for c in &cats {
                    let (r, resp) = ui.allocate_exact_size(Vec2::new(left_w - 6.0, 40.0), Sense::click());
                    let on = st.brush_cat == *c;
                    if on {
                        ui.painter().rect_filled(r, 8.0, ACCENT);
                    } else if resp.hovered() {
                        ui.painter().rect_filled(r, 8.0, Color32::from_gray(44));
                    }
                    let col = if on { Color32::WHITE } else { Color32::from_gray(200) };
                    let idx = crate::brush::CATEGORIES.iter().position(|x| *x == c.as_str());
                    cat_icon(ui.painter(), Rect::from_center_size(Pos2::new(r.left() + 20.0, r.center().y), Vec2::splat(20.0)), idx, col);
                    let font = egui::FontId::proportional(if narrow { 13.0 } else { 15.0 });
                    let name = ui.painter().layout(c.clone(), font, col, r.width() - 44.0);
                    ui.painter().galley(Pos2::new(r.left() + 38.0, r.center().y - name.size().y / 2.0), name, col);
                    if resp.clicked() {
                        st.brush_cat = c.clone();
                    }
                }
            });
        });
        ui.add(egui::Separator::default().vertical().spacing(6.0));
        // ---- colonne des pinceaux ----
        let right_w = ui.available_width();
        ui.allocate_ui_with_layout(Vec2::new(right_w, height), egui::Layout::top_down(egui::Align::Min), |ui| {
            egui::ScrollArea::vertical().id_salt(("brushes", st.brush_cat.clone())).max_height(height).show(ui, |ui| {
                ui.spacing_mut().item_spacing.y = 3.0;
                let pw = right_w - 8.0;
                let ph = (pw / 4.0).min(64.0);
                for b in brushes.iter().filter(|b| b.cat == st.brush_cat) {
                    let (r, resp) = ui.allocate_exact_size(Vec2::new(pw, ph + 22.0), Sense::click());
                    let on = match tool {
                        Tool::Eraser => st.eraser_brush == b.id,
                        Tool::Smudge => st.smudge_brush == b.id,
                        Tool::Brush => st.brush == b.id,
                    };
                    if on {
                        ui.painter().rect_filled(r, 8.0, ACCENT);
                    } else if resp.hovered() {
                        ui.painter().rect_filled(r, 8.0, Color32::from_gray(40));
                    }
                    ui.painter().text(Pos2::new(r.left() + 10.0, r.top() + 4.0), Align2::LEFT_TOP, &b.name, egui::FontId::proportional(14.0), Color32::WHITE);
                    let pr = Rect::from_min_size(Pos2::new(r.left() + 4.0, r.top() + 20.0), Vec2::new(ph * 4.0, ph));
                    if let Some(t) = st.previews.get(&b.id) {
                        ui.painter().image(t.id(), pr, Rect::from_min_max(Pos2::ZERO, Pos2::new(1.0, 1.0)), Color32::WHITE);
                    } else {
                        ui.painter().line_segment([Pos2::new(pr.left() + 16.0, pr.center().y), Pos2::new(pr.right() - 16.0, pr.center().y)], Stroke::new(1.0, Color32::from_gray(80)));
                    }
                    if resp.clicked() {
                        picked = Some(b);
                    }
                    if on && !crate::library::is_builtin(b) {
                        let del = Rect::from_center_size(Pos2::new(r.right() - 18.0, r.top() + 14.0), Vec2::splat(24.0));
                        if ui.put(del, egui::Button::new("✕")).on_hover_text("Supprimer ce pinceau").clicked() {
                            actions.push(Action::DeleteBrush(b.id.clone()));
                        }
                    }
                }
                if !brushes.iter().any(|b| b.cat == st.brush_cat) {
                    ui.label(RichText::new("Aucun pinceau ici").color(Color32::GRAY));
                }
            });
        });
    });
    if let Some(b) = picked {
        // taille par défaut du pinceau importé
        let v = if crate::library::is_builtin(b) { None } else { Some(b.def_size.clamp(0.01, 1.0).sqrt()) };
        match tool {
            Tool::Eraser => {
                st.eraser_brush = b.id.clone();
                if let Some(v) = v {
                    st.size_eraser = v;
                }
            }
            Tool::Smudge => {
                st.smudge_brush = b.id.clone();
                if let Some(v) = v {
                    st.size_smudge = v;
                }
            }
            Tool::Brush => {
                st.brush = b.id.clone();
                if let Some(v) = v {
                    st.size_brush = v;
                }
            }
        }
    }
}

fn layers_panel(ui: &mut egui::Ui, c: &mut Canvas) {
    ui.horizontal(|ui| {
        ui.heading("Calques");
        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            if ui.button(RichText::new("+").size(20.0)).on_hover_text("Nouveau calque").clicked() {
                c.add_layer();
            }
        });
    });
    let n = c.info.layers.len();
    let aspect = c.info.h as f32 / c.info.w as f32;
    let mut select = None;
    let mut toggle_vis = None;
    for i in (0..n).rev() {
        let on = c.info.active == i;
        let l = &c.info.layers[i];
        let (r, resp) = ui.allocate_exact_size(Vec2::new(ui.available_width(), 58.0), Sense::click());
        ui.painter().rect_filled(r, 10.0, if on { Color32::from_rgb(58, 45, 90) } else { Color32::from_rgb(38, 38, 44) });
        let tw = 46.0f32;
        let th = (tw * aspect).min(46.0);
        let tr = Rect::from_center_size(Pos2::new(r.left() + 34.0, r.center().y), Vec2::new(tw.min(46.0 / aspect), th));
        ui.painter().rect_filled(tr, 3.0, Color32::from_gray(235));
        if let Some(Some(t)) = c.thumbs.get(i) {
            ui.painter().image(*t, tr, Rect::from_min_max(Pos2::ZERO, Pos2::new(1.0, 1.0)), Color32::WHITE);
        }
        ui.painter().text(Pos2::new(r.left() + 66.0, r.center().y - 8.0), Align2::LEFT_CENTER, &l.name, egui::FontId::proportional(15.0), Color32::WHITE);
        ui.painter().text(
            Pos2::new(r.left() + 66.0, r.center().y + 11.0),
            Align2::LEFT_CENTER,
            format!("{} · {} %", doc::blend_name(l.mode), (l.opacity * 100.0).round()),
            egui::FontId::proportional(12.0),
            Color32::GRAY,
        );
        // case de visibilité
        let cb = Rect::from_center_size(Pos2::new(r.right() - 24.0, r.center().y), Vec2::splat(26.0));
        ui.painter().rect_stroke(cb, 6.0, Stroke::new(2.0, Color32::from_gray(200)), egui::StrokeKind::Inside);
        if l.visible {
            ui.painter().rect_filled(cb.shrink(5.0), 3.0, ACCENT);
        }
        if resp.clicked() {
            if let Some(pos) = resp.interact_pointer_pos() {
                if cb.expand(8.0).contains(pos) {
                    toggle_vis = Some(i);
                } else {
                    select = Some(i);
                }
            }
        }
    }
    if let Some(i) = toggle_vis {
        c.set_props(i, |l| l.visible = !l.visible);
    }
    if let Some(i) = select {
        c.info.active = i;
        c.engine.invalidate();
        c.dirty = true;
    }
    ui.separator();
    // réglages du calque actif
    let a = c.info.active;
    let mut op = c.info.layers[a].opacity;
    ui.horizontal(|ui| {
        ui.label("Opacité");
        if ui.add(egui::Slider::new(&mut op, 0.0..=1.0).show_value(false)).changed() {
            c.set_props(a, |l| l.opacity = op);
        }
    });
    let mut mode = c.info.layers[a].mode;
    egui::ComboBox::from_label("Mode de fusion").selected_text(doc::blend_name(mode)).show_ui(ui, |ui| {
        for (name, m) in doc::BLENDS {
            ui.selectable_value(&mut mode, *m, *name);
        }
    });
    if mode != c.info.layers[a].mode {
        c.set_props(a, |l| l.mode = mode);
    }
    let mut lock = c.info.layers[a].lock_alpha;
    if ui.checkbox(&mut lock, "Verrouiller la transparence").changed() {
        c.set_props(a, |l| l.lock_alpha = lock);
    }
    ui.horizontal_wrapped(|ui| {
        if ui.button("Dupliquer").clicked() {
            c.duplicate_layer(a);
        }
        if ui.add_enabled(a > 0, egui::Button::new("Fusionner vers le bas")).clicked() {
            c.merge_down(a);
        }
        if ui.add_enabled(a + 1 < n, egui::Button::new("Monter")).clicked() {
            c.move_layer(a, a + 1);
        }
        if ui.add_enabled(a > 0, egui::Button::new("Descendre")).clicked() {
            c.move_layer(a, a - 1);
        }
        if ui.button("Effacer").clicked() {
            c.clear_active();
        }
        if ui.button("Supprimer").clicked() {
            c.delete_layer(a);
        }
    });
    ui.separator();
    ui.horizontal(|ui| {
        let mut vis = c.info.bg_visible;
        if ui.checkbox(&mut vis, "Fond").changed() {
            c.info.bg_visible = vis;
            c.changed();
            c.engine.invalidate();
        }
        let mut col = c32(c.info.bg);
        if ui.color_edit_button_srgba(&mut col).changed() {
            c.info.bg = [col.r() as f32 / 255.0, col.g() as f32 / 255.0, col.b() as f32 / 255.0];
            c.changed();
            c.engine.invalidate();
        }
    });
}

/// Carré saturation / luminosité avec anneau de teinte (onglet Classique).
fn color_square(ui: &mut egui::Ui, st: &mut UiState, size: f32) {
    let (r, resp) = ui.allocate_exact_size(Vec2::new(ui.available_width(), size), Sense::click_and_drag());
    let c = r.center();
    let p = ui.painter();
    let mut hsv = crate::procreate::rgb_to_hsv(st.color);
    // carré saturation / luminosité (interpolation bilinéaire exacte)
    let half = size / 2.0 - 4.0;
    let sq = r.shrink(4.0);
    let _ = (half, c);
    let mut m = egui::Mesh::default();
    m.colored_vertex(sq.left_top(), Color32::WHITE);
    m.colored_vertex(sq.right_top(), c32(crate::procreate::hsv(hsv[0], 1.0, 1.0)));
    m.colored_vertex(sq.right_bottom(), Color32::BLACK);
    m.colored_vertex(sq.left_bottom(), Color32::BLACK);
    m.add_triangle(0, 1, 2);
    m.add_triangle(0, 2, 3);
    p.add(m);
    // repères
    let sp = Pos2::new(sq.left() + hsv[1] * sq.width(), sq.bottom() - hsv[2] * sq.height());
    p.circle_filled(sp, 11.0, c32(st.color));
    p.circle_stroke(sp, 11.0, Stroke::new(3.0, Color32::WHITE));
    // interaction
    let id = ui.scope_id().with("disc_drag");
    if resp.drag_started() || resp.clicked() {
        if let Some(pos) = resp.interact_pointer_pos() {
            let d = (pos - c).length();
            let _ = d;
            let zone: u8 = 2;
            ui.ctx().data_mut(|dm| dm.insert_temp(id, zone));
        }
    }
    if resp.dragged() || resp.clicked() {
        let zone: u8 = ui.ctx().data(|dm| dm.get_temp(id)).unwrap_or(0);
        if let Some(pos) = resp.interact_pointer_pos() {
            if zone == 1 {
                let v = pos - c;
                hsv[0] = (v.y.atan2(v.x) / std::f32::consts::TAU).rem_euclid(1.0);
            } else if zone == 2 {
                hsv[1] = ((pos.x - sq.left()) / sq.width()).clamp(0.0, 1.0);
                hsv[2] = ((sq.bottom() - pos.y) / sq.height()).clamp(0.0, 1.0);
            }
            if zone != 0 {
                st.color = crate::procreate::hsv(hsv[0], hsv[1], hsv[2]);
            }
        }
    }
    if resp.drag_stopped() || resp.clicked() {
        st.push_recent();
    }
}

fn swatch(ui: &mut egui::Ui, c: [f32; 3]) -> egui::Response {
    let (r, resp) = ui.allocate_exact_size(Vec2::splat(30.0), Sense::click());
    ui.painter().rect_filled(r, 6.0, c32(c));
    resp
}

fn color_panel(ui: &mut egui::Ui, st: &mut UiState, actions: &mut Vec<Action>) {
    ui.horizontal(|ui| {
        ui.heading("Couleurs");
        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            if ui.button("Détacher").on_hover_text("Garder la roue de couleurs ouverte dans une petite fenêtre").clicked() {
                st.color_float = true;
                st.panel = None;
            }
        });
    });
    color_body(ui, st, actions, 300.0);
}

/// Curseur en dégradé (teinte, saturation, etc.). Renvoie vrai si la valeur change.
fn grad_slider(ui: &mut egui::Ui, label: &str, v: &mut f32, max: f32, col: impl Fn(f32) -> [f32; 3]) -> egui::Response {
    let w = ui.available_width();
    ui.label(RichText::new(label).size(12.0).color(Color32::GRAY));
    let (r, mut resp) = ui.allocate_exact_size(Vec2::new(w, 26.0), Sense::click_and_drag());
    let bar = r.shrink2(Vec2::new(10.0, 3.0));
    let n = 32;
    let mut m = egui::Mesh::default();
    for i in 0..=n {
        let t = i as f32 / n as f32;
        let x = bar.left() + t * bar.width();
        let c = c32(col(t));
        m.colored_vertex(Pos2::new(x, bar.top()), c);
        m.colored_vertex(Pos2::new(x, bar.bottom()), c);
        if i > 0 {
            let k = (i * 2) as u32;
            m.add_triangle(k - 2, k - 1, k);
            m.add_triangle(k - 1, k + 1, k);
        }
    }
    ui.painter().add(m);
    let t = (*v / max).clamp(0.0, 1.0);
    let kp = Pos2::new(bar.left() + t * bar.width(), bar.center().y);
    ui.painter().circle_filled(kp, 11.0, c32(col(t)));
    ui.painter().circle_stroke(kp, 11.0, Stroke::new(3.0, Color32::WHITE));
    if resp.dragged() || resp.clicked() {
        if let Some(p) = resp.interact_pointer_pos() {
            let nv = ((p.x - bar.left()) / bar.width()).clamp(0.0, 1.0) * max;
            if nv != *v {
                *v = nv;
                resp.mark_changed();
            }
        }
    }
    resp
}

/// Disque Procreate : anneau de teinte + disque intérieur (saturation à l'horizontale, luminosité à la verticale).
fn color_disc_round(ui: &mut egui::Ui, st: &mut UiState, size: f32) {
    let (r, resp) = ui.allocate_exact_size(Vec2::splat(size), Sense::click_and_drag());
    let c = r.center();
    let r_out = size / 2.0 - 2.0;
    let r_in = r_out - (size * 0.1).max(18.0);
    let p = ui.painter();
    let mut hsv = crate::procreate::rgb_to_hsv(st.color);
    let n = 96;
    let mut mesh = egui::Mesh::default();
    for i in 0..=n {
        let a = i as f32 / n as f32 * std::f32::consts::TAU;
        let col = c32(crate::procreate::hsv(i as f32 / n as f32, 1.0, 1.0));
        let d = Vec2::new(a.cos(), a.sin());
        mesh.colored_vertex(c + d * r_in, col);
        mesh.colored_vertex(c + d * r_out, col);
        if i > 0 {
            let k = (i * 2) as u32;
            mesh.add_triangle(k - 2, k - 1, k);
            mesh.add_triangle(k - 1, k + 1, k);
        }
    }
    p.add(mesh);
    // disque intérieur : grille polaire, couleur calculée à chaque sommet
    let rd = r_in - 6.0;
    let (rings, segs) = (14usize, 48usize);
    let mut m = egui::Mesh::default();
    let col_at = |x: f32, y: f32| c32(crate::procreate::hsv(hsv[0], ((x + 1.0) / 2.0).clamp(0.0, 1.0), ((1.0 - y) / 2.0).clamp(0.0, 1.0)));
    m.colored_vertex(c, col_at(0.0, 0.0));
    for ri in 1..=rings {
        let rr = ri as f32 / rings as f32;
        for si in 0..segs {
            let a = si as f32 / segs as f32 * std::f32::consts::TAU;
            let (x, y) = (a.cos() * rr, a.sin() * rr);
            m.colored_vertex(c + Vec2::new(x, y) * rd, col_at(x, y));
        }
    }
    let idx = |ri: usize, si: usize| -> u32 { if ri == 0 { 0 } else { (1 + (ri - 1) * segs + si % segs) as u32 } };
    for ri in 0..rings {
        for si in 0..segs {
            if ri == 0 {
                m.add_triangle(0, idx(1, si), idx(1, si + 1));
            } else {
                m.add_triangle(idx(ri, si), idx(ri + 1, si), idx(ri + 1, si + 1));
                m.add_triangle(idx(ri, si), idx(ri + 1, si + 1), idx(ri, si + 1));
            }
        }
    }
    p.add(m);
    let ha = hsv[0] * std::f32::consts::TAU;
    let hp = c + Vec2::new(ha.cos(), ha.sin()) * (r_in + r_out) / 2.0;
    p.circle_stroke(hp, 12.0, Stroke::new(3.0, Color32::WHITE));
    let mut d = Vec2::new(hsv[1] * 2.0 - 1.0, 1.0 - hsv[2] * 2.0);
    if d.length() > 1.0 {
        d = d.normalized();
    }
    let sp = c + d * rd;
    p.circle_filled(sp, 11.0, c32(st.color));
    p.circle_stroke(sp, 11.0, Stroke::new(3.0, Color32::WHITE));
    let id = ui.scope_id().with("disc2_drag");
    if resp.drag_started() || resp.clicked() {
        if let Some(pos) = resp.interact_pointer_pos() {
            let zone: u8 = if (pos - c).length() >= r_in - 3.0 { 1 } else { 2 };
            ui.ctx().data_mut(|dm| dm.insert_temp(id, zone));
        }
    }
    if resp.dragged() || resp.clicked() {
        let zone: u8 = ui.ctx().data(|dm| dm.get_temp(id)).unwrap_or(0);
        if let Some(pos) = resp.interact_pointer_pos() {
            let v = pos - c;
            if zone == 1 {
                hsv[0] = (v.y.atan2(v.x) / std::f32::consts::TAU).rem_euclid(1.0);
            } else if zone == 2 {
                let mut q = v / rd;
                if q.length() > 1.0 {
                    q = q.normalized();
                }
                hsv[1] = ((q.x + 1.0) / 2.0).clamp(0.0, 1.0);
                hsv[2] = ((1.0 - q.y) / 2.0).clamp(0.0, 1.0);
            }
            if zone != 0 {
                st.color = crate::procreate::hsv(hsv[0], hsv[1], hsv[2]);
            }
        }
    }
    if resp.drag_stopped() || resp.clicked() {
        st.push_recent();
    }
}

const HARMONIES: &[(&str, &[f32])] = &[
    ("Complémentaire", &[0.5]),
    ("Complémentaire divisée", &[0.4167, 0.5833]),
    ("Analogue", &[-0.0833, 0.0833]),
    ("Triadique", &[0.3333, 0.6667]),
    ("Tétradique", &[0.25, 0.5, 0.75]),
];

/// Harmonie : disque teinte (angle) / saturation (rayon), couleurs associées et luminosité.
fn color_harmony(ui: &mut egui::Ui, st: &mut UiState, size: f32) {
    let mut hsv = crate::procreate::rgb_to_hsv(st.color);
    let hi = (st.harmony as usize).min(HARMONIES.len() - 1);
    egui::ComboBox::from_id_salt("harmonie").selected_text(HARMONIES[hi].0).width(ui.available_width() - 8.0).show_ui(ui, |ui| {
        for (k, (name, _)) in HARMONIES.iter().enumerate() {
            ui.selectable_value(&mut st.harmony, k as u8, *name);
        }
    });
    let (r, resp) = ui.allocate_exact_size(Vec2::splat(size), Sense::click_and_drag());
    let c = r.center();
    let rd = size / 2.0 - 4.0;
    let (rings, segs) = (12usize, 72usize);
    let mut m = egui::Mesh::default();
    m.colored_vertex(c, c32(crate::procreate::hsv(0.0, 0.0, hsv[2])));
    for ri in 1..=rings {
        let rr = ri as f32 / rings as f32;
        for si in 0..segs {
            let a = si as f32 / segs as f32 * std::f32::consts::TAU;
            m.colored_vertex(c + Vec2::new(a.cos(), a.sin()) * rr * rd, c32(crate::procreate::hsv(si as f32 / segs as f32, rr, hsv[2])));
        }
    }
    let idx = |ri: usize, si: usize| -> u32 { if ri == 0 { 0 } else { (1 + (ri - 1) * segs + si % segs) as u32 } };
    for ri in 0..rings {
        for si in 0..segs {
            if ri == 0 {
                m.add_triangle(0, idx(1, si), idx(1, si + 1));
            } else {
                m.add_triangle(idx(ri, si), idx(ri + 1, si), idx(ri + 1, si + 1));
                m.add_triangle(idx(ri, si), idx(ri + 1, si + 1), idx(ri, si + 1));
            }
        }
    }
    ui.painter().add(m);
    let pos_of = |h: f32, s: f32| c + Vec2::new((h * std::f32::consts::TAU).cos(), (h * std::f32::consts::TAU).sin()) * s * rd;
    let main = pos_of(hsv[0], hsv[1]);
    let mut others = Vec::new();
    for off in HARMONIES[hi].1 {
        let h = (hsv[0] + off).rem_euclid(1.0);
        let p = pos_of(h, hsv[1]);
        ui.painter().line_segment([c, p], Stroke::new(1.0, Color32::from_white_alpha(120)));
        ui.painter().circle_stroke(p, 8.0, Stroke::new(2.0, Color32::WHITE));
        others.push(crate::procreate::hsv(h, hsv[1], hsv[2]));
    }
    ui.painter().line_segment([c, main], Stroke::new(1.0, Color32::from_white_alpha(160)));
    ui.painter().circle_filled(main, 11.0, c32(st.color));
    ui.painter().circle_stroke(main, 11.0, Stroke::new(3.0, Color32::WHITE));
    if resp.dragged() || resp.clicked() {
        if let Some(pos) = resp.interact_pointer_pos() {
            let v = pos - c;
            hsv[0] = (v.y.atan2(v.x) / std::f32::consts::TAU).rem_euclid(1.0);
            hsv[1] = (v.length() / rd).clamp(0.0, 1.0);
            st.color = crate::procreate::hsv(hsv[0], hsv[1], hsv[2]);
        }
    }
    if resp.drag_stopped() || resp.clicked() {
        st.push_recent();
    }
    let mut v = hsv[2];
    let h0 = hsv;
    if grad_slider(ui, "Luminosité", &mut v, 1.0, |t| crate::procreate::hsv(h0[0], h0[1], t)).changed() {
        st.color = crate::procreate::hsv(hsv[0], hsv[1], v);
    }
    ui.horizontal(|ui| {
        swatch(ui, st.color);
        for o in others {
            if swatch(ui, o).on_hover_text("Choisir cette couleur").clicked() {
                st.color = o;
                st.push_recent();
            }
        }
    });
}

/// Icônes des onglets du panneau Couleurs.
fn color_tab_icon(p: &egui::Painter, r: Rect, k: u8, col: Color32) {
    let c = r.center();
    let s = Stroke::new(1.8, col);
    match k {
        0 => {
            p.circle_stroke(c, 10.0, s);
            p.circle_stroke(c, 5.0, s);
        }
        1 => {
            p.rect_stroke(Rect::from_center_size(c + Vec2::new(0.0, -2.0), Vec2::splat(14.0)), 2.0, s, egui::StrokeKind::Middle);
            p.line_segment([c + Vec2::new(-8.0, 9.0), c + Vec2::new(8.0, 9.0)], s);
        }
        2 => {
            p.circle_stroke(c, 10.0, s);
            p.circle_filled(c + Vec2::new(-5.0, -4.0), 2.5, col);
            p.circle_filled(c + Vec2::new(5.0, 4.0), 2.5, col);
        }
        3 => {
            for (i, x) in [-4.0f32, 2.0, 6.0].iter().enumerate() {
                let y = -7.0 + i as f32 * 7.0;
                p.line_segment([c + Vec2::new(-10.0, y), c + Vec2::new(10.0, y)], Stroke::new(1.5, col));
                p.circle_filled(c + Vec2::new(*x, y), 2.8, col);
            }
        }
        _ => {
            for y in 0..2 {
                for x in 0..3 {
                    p.rect_filled(Rect::from_min_size(c + Vec2::new(-10.0 + x as f32 * 7.5, -6.0 + y as f32 * 7.5), Vec2::splat(5.5)), 1.0, col);
                }
            }
        }
    }
}

fn color_body(ui: &mut egui::Ui, st: &mut UiState, actions: &mut Vec<Action>, disc: f32) {
    let disc = disc.min(ui.available_width());
    // historique en haut, comme Procreate
    ui.horizontal_wrapped(|ui| {
        ui.spacing_mut().item_spacing.x = 4.0;
        for c in st.recent.clone().into_iter().take(10) {
            if swatch(ui, c).clicked() {
                st.color = c;
            }
        }
    });
    ui.add_space(6.0);
    let mut hsv = crate::procreate::rgb_to_hsv(st.color);
    // hauteur fixe : les onglets du bas ne bougent pas d'un onglet à l'autre
    let content_h = disc * 0.9 + 150.0;
    egui::ScrollArea::vertical().id_salt("couleurs").max_height(content_h).show(ui, |ui| {
    ui.set_min_height(content_h);
    match st.color_mode {
        1 => {
            // Classique : carré + curseurs teinte / saturation / luminosité
            color_square(ui, st, disc * 0.9);
            let h0 = hsv;
            let mut ch = false;
            ch |= grad_slider(ui, "Teinte", &mut hsv[0], 1.0, |t| crate::procreate::hsv(t, 1.0, 1.0)).changed();
            ch |= grad_slider(ui, "Saturation", &mut hsv[1], 1.0, |t| crate::procreate::hsv(h0[0], t, h0[2].max(0.15))).changed();
            ch |= grad_slider(ui, "Luminosité", &mut hsv[2], 1.0, |t| crate::procreate::hsv(h0[0], h0[1], t)).changed();
            if ch {
                st.color = crate::procreate::hsv(hsv[0], hsv[1], hsv[2]);
            }
        }
        2 => color_harmony(ui, st, disc * 0.85),
        3 => {
            // Valeurs : TSL + RVB + hexadécimal
            let h0 = hsv;
            let mut ch = false;
            ch |= grad_slider(ui, &format!("Teinte  {}°", (hsv[0] * 360.0).round()), &mut hsv[0], 1.0, |t| crate::procreate::hsv(t, 1.0, 1.0)).changed();
            ch |= grad_slider(ui, &format!("Saturation  {} %", (hsv[1] * 100.0).round()), &mut hsv[1], 1.0, |t| crate::procreate::hsv(h0[0], t, h0[2].max(0.15))).changed();
            ch |= grad_slider(ui, &format!("Luminosité  {} %", (hsv[2] * 100.0).round()), &mut hsv[2], 1.0, |t| crate::procreate::hsv(h0[0], h0[1], t)).changed();
            if ch {
                st.color = crate::procreate::hsv(hsv[0], hsv[1], hsv[2]);
            }
            ui.add_space(4.0);
            let c0 = st.color;
            let mut rgb = st.color;
            let mut ch = false;
            ch |= grad_slider(ui, &format!("Rouge  {}", (rgb[0] * 255.0).round()), &mut rgb[0], 1.0, |t| [t, c0[1], c0[2]]).changed();
            ch |= grad_slider(ui, &format!("Vert  {}", (rgb[1] * 255.0).round()), &mut rgb[1], 1.0, |t| [c0[0], t, c0[2]]).changed();
            ch |= grad_slider(ui, &format!("Bleu  {}", (rgb[2] * 255.0).round()), &mut rgb[2], 1.0, |t| [c0[0], c0[1], t]).changed();
            if ch {
                st.color = rgb;
            }
            let col = c32(st.color);
            let id = ui.make_persistent_id("hex");
            let mut hex: String = ui.ctx().data(|d| d.get_temp(id)).unwrap_or_else(|| format!("{:02X}{:02X}{:02X}", col.r(), col.g(), col.b()));
            ui.horizontal(|ui| {
                ui.label("Hexadécimal #");
                let r = ui.add(egui::TextEdit::singleline(&mut hex).desired_width(90.0));
                if r.changed() {
                    let hx = hex.trim().trim_start_matches('#');
                    if hx.len() == 6 {
                        if let Ok(v) = u32::from_str_radix(hx, 16) {
                            st.color = [((v >> 16) & 255) as f32 / 255.0, ((v >> 8) & 255) as f32 / 255.0, (v & 255) as f32 / 255.0];
                        }
                    }
                }
                if r.has_focus() {
                    ui.ctx().data_mut(|d| d.insert_temp(id, hex.clone()));
                } else {
                    ui.ctx().data_mut(|d| d.remove::<String>(id));
                }
            });
        }
        4 => {
            if ui.button("Importer une palette Procreate (.swatches)").clicked() {
                actions.push(Action::PickFiles);
            }
            let mut del = None;
            for (pi, (name, cols)) in st.palettes.clone().iter().enumerate() {
                ui.horizontal(|ui| {
                    ui.label(RichText::new(name).strong());
                    if ui.small_button("✕").on_hover_text("Supprimer la palette").clicked() {
                        del = Some(pi);
                    }
                });
                ui.horizontal_wrapped(|ui| {
                    for c in cols {
                        if swatch(ui, *c).clicked() {
                            st.color = *c;
                            st.push_recent();
                        }
                    }
                    if ui.button("+").on_hover_text("Ajouter la couleur actuelle").clicked() {
                        st.palettes[pi].1.push(st.color);
                    }
                });
            }
            if let Some(i) = del {
                st.palettes.remove(i);
            }
            if ui.button("Nouvelle palette").clicked() {
                let n = st.palettes.len() + 1;
                st.palettes.push((format!("Palette {n}"), vec![st.color]));
            }
        }
        _ => color_disc_round(ui, st, (content_h - 8.0).min(ui.available_width())),
    }
    });
    // onglets en bas, comme dans Procreate
    ui.add_space(6.0);
    ui.separator();
    let names = ["Disque", "Classique", "Harmonie", "Valeurs", "Palettes"];
    let w = ui.available_width() / 5.0;
    ui.horizontal(|ui| {
        ui.spacing_mut().item_spacing.x = 0.0;
        for (k, name) in names.iter().enumerate() {
            let (r, resp) = ui.allocate_exact_size(Vec2::new(w, 46.0), Sense::click());
            let on = st.color_mode == k as u8;
            let col = if on { ACCENT } else { Color32::from_gray(170) };
            color_tab_icon(ui.painter(), Rect::from_center_size(Pos2::new(r.center().x, r.top() + 15.0), Vec2::splat(24.0)), k as u8, col);
            ui.painter().text(Pos2::new(r.center().x, r.bottom() - 4.0), Align2::CENTER_BOTTOM, *name, egui::FontId::proportional(11.0), col);
            if resp.clicked() {
                st.color_mode = k as u8;
            }
        }
    });
}

const FX: &[(u32, &str)] = &[
    (0, "Teinte, saturation, luminosité"),
    (6, "Balance des couleurs"),
    (2, "Luminosité et contraste"),
    (1, "Flou gaussien"),
    (4, "Bruit"),
    (5, "Noir et blanc"),
    (3, "Négatif"),
];

fn fx_default(kind: u32) -> [f32; 3] {
    match kind {
        0 => [0.0, 1.0, 0.0],
        1 => [8.0, 0.0, 0.0],
        2 => [0.0, 1.0, 0.0],
        4 => [0.15, 1.0, 0.0],
        5 => [1.0, 0.0, 0.0],
        _ => [0.0, 0.0, 0.0],
    }
}

fn adjust_panel(ui: &mut egui::Ui, st: &mut UiState, c: &mut Canvas) {
    match st.fx {
        None => {
            ui.heading("Ajustements");
            ui.label(RichText::new(format!("Sur le calque « {} »", c.info.layers[c.info.active].name)).color(Color32::GRAY));
            for (k, name) in FX {
                if ui.add(egui::Button::new(*name).min_size(Vec2::new(ui.available_width(), 38.0))).clicked() {
                    let p = fx_default(*k);
                    st.fx = Some((*k, p));
                    c.fx_preview(*k, p);
                }
            }
        }
        Some((kind, mut p)) => {
            ui.heading(FX.iter().find(|f| f.0 == kind).map(|f| f.1).unwrap_or("Ajustement"));
            let mut changed = false;
            let mut sl = |ui: &mut egui::Ui, label: &str, v: &mut f32, r: std::ops::RangeInclusive<f32>| {
                ui.horizontal(|ui| {
                    ui.label(label);
                    changed |= ui.add(egui::Slider::new(v, r)).changed();
                });
            };
            match kind {
                0 => {
                    sl(ui, "Teinte", &mut p[0], -0.5..=0.5);
                    sl(ui, "Saturation", &mut p[1], 0.0..=2.0);
                    sl(ui, "Luminosité", &mut p[2], -1.0..=1.0);
                }
                6 => {
                    sl(ui, "Cyan – Rouge", &mut p[0], -1.0..=1.0);
                    sl(ui, "Magenta – Vert", &mut p[1], -1.0..=1.0);
                    sl(ui, "Jaune – Bleu", &mut p[2], -1.0..=1.0);
                }
                2 => {
                    sl(ui, "Luminosité", &mut p[0], -0.5..=0.5);
                    sl(ui, "Contraste", &mut p[1], 0.0..=3.0);
                }
                1 => sl(ui, "Rayon (px)", &mut p[0], 0.5..=120.0),
                4 => sl(ui, "Quantité", &mut p[0], 0.0..=1.0),
                5 => sl(ui, "Intensité", &mut p[0], 0.0..=1.0),
                _ => {}
            }
            if changed {
                st.fx = Some((kind, p));
                c.fx_preview(kind, p);
            }
            ui.horizontal(|ui| {
                if ui.add(egui::Button::new(RichText::new("Appliquer").color(Color32::WHITE)).fill(ACCENT)).clicked() {
                    c.fx_apply();
                    st.fx = None;
                }
                if ui.button("Annuler").clicked() {
                    c.fx_cancel();
                    st.fx = None;
                }
                if ui.button("Réinitialiser").clicked() {
                    let d = fx_default(kind);
                    st.fx = Some((kind, d));
                    c.fx_preview(kind, d);
                }
            });
        }
    }
}

fn select_panel(ui: &mut egui::Ui, st: &mut UiState, c: &mut Canvas) {
    ui.label(RichText::new("Dessine le contour à main levée sur la toile (lasso)").color(Color32::GRAY));
    let has = c.selection.is_some();
    ui.horizontal_wrapped(|ui| {
        if ui.add_enabled(has, egui::Button::new("Inverser")).clicked() {
            c.invert_selection();
        }
        if ui.add_enabled(has, egui::Button::new("Effacer le contenu")).clicked() {
            c.clear_selection_content();
        }
        if ui.add_enabled(has, egui::Button::new("Désélectionner")).clicked() {
            c.set_selection(None, false);
        }
        if ui.add(egui::Button::new(RichText::new("Terminé").color(Color32::WHITE)).fill(ACCENT)).clicked() {
            st.panel = None;
        }
    });
    ui.label(RichText::new("Tant qu'une zone est sélectionnée, le dessin, la gomme et les ajustements restent dedans.").size(12.0).color(Color32::GRAY));
}

fn transform_panel(ui: &mut egui::Ui, st: &mut UiState, c: &mut Canvas) {
    let Some(mut x) = c.xform else {
        st.panel = None;
        return;
    };
    ui.label(RichText::new("Glisser pour déplacer · pincer pour agrandir et tourner").color(Color32::GRAY));
    let mut ch = false;
    ui.horizontal(|ui| {
        ui.label("Taille");
        let mut pct = x.scale * 100.0;
        if ui.add(egui::Slider::new(&mut pct, 5.0..=400.0).suffix(" %").logarithmic(true)).changed() {
            x.scale = pct / 100.0;
            ch = true;
        }
    });
    ui.horizontal(|ui| {
        ui.label("Rotation");
        let mut deg = x.rot.to_degrees();
        if ui.add(egui::Slider::new(&mut deg, -180.0..=180.0).suffix("°")).changed() {
            x.rot = deg.to_radians();
            ch = true;
        }
    });
    ui.horizontal_wrapped(|ui| {
        if ui.button("Miroir horizontal").clicked() {
            x.flip_h = !x.flip_h;
            ch = true;
        }
        if ui.button("Miroir vertical").clicked() {
            x.flip_v = !x.flip_v;
            ch = true;
        }
        if ui.button("Pivoter 90°").clicked() {
            x.rot += std::f32::consts::FRAC_PI_2;
            ch = true;
        }
        if ui.button("Réinitialiser").clicked() {
            x = crate::canvas::Xform::default();
            ch = true;
        }
    });
    if ch {
        c.xform = Some(x);
        c.transform_update();
    }
    ui.horizontal(|ui| {
        if ui.add(egui::Button::new(RichText::new("Valider").color(Color32::WHITE)).fill(ACCENT)).clicked() {
            c.transform_apply();
            st.panel = None;
        }
        if ui.button("Annuler").clicked() {
            c.transform_cancel();
            st.panel = None;
        }
    });
}

fn actions_panel(ui: &mut egui::Ui, st: &mut UiState, c: Option<&mut Canvas>, actions: &mut Vec<Action>) {
    ui.heading("Actions");
    ui.label(RichText::new("Ajouter").color(Color32::GRAY));
    if ui.button("Insérer une image ou un fichier").clicked() {
        actions.push(Action::PickFiles);
        st.panel = None;
    }
    ui.separator();
    ui.label(RichText::new("Partager").color(Color32::GRAY));
    ui.horizontal_wrapped(|ui| {
        for (k, label) in [("png", "PNG"), ("jpeg", "JPEG"), ("psd", "PSD (calques)")] {
            if ui.button(format!("Exporter en {label}")).clicked() {
                actions.push(Action::Export(k));
                st.panel = None;
            }
        }
    });
    if ui.button("Enregistrer maintenant").clicked() {
        actions.push(Action::Save);
    }
    ui.separator();
    ui.label(RichText::new("Toile").color(Color32::GRAY));
    if ui.button("Ajuster à l'écran").clicked() {
        actions.push(Action::Fit);
    }
    if let Some(c) = c {
        ui.label(format!("Dimensions : {} × {} px · {} calques", c.info.w, c.info.h, c.info.layers.len()));
    }
    if !cfg!(target_os = "android") && ui.button("Plein écran").clicked() {
        actions.push(Action::Fullscreen);
    }
    if ui.button("Masquer l'interface").clicked() {
        st.hide_ui = true;
        st.panel = None;
    }
    ui.separator();
    ui.label(RichText::new("Préférences").color(Color32::GRAY));
    ui.checkbox(&mut st.finger_draw, "Dessiner aussi au doigt (avec un stylet)");
    ui.checkbox(&mut st.quickshape, "Forme rapide (maintenir à la fin du trait)");
    ui.horizontal(|ui| {
        ui.label("Pression");
        ui.add(egui::Slider::new(&mut st.pressure_curve, 0.4..=2.5).show_value(false));
        ui.label(if st.pressure_curve < 0.85 { "douce" } else if st.pressure_curve > 1.25 { "ferme" } else { "normale" });
    });
    ui.label(RichText::new(format!("Version 0.1.{}", crate::updater::build_number())).size(12.0).color(Color32::GRAY));
    ui.separator();
    ui.label(RichText::new("Gestes : 2 doigts = annuler, 3 doigts = rétablir, pincer = zoom/rotation, 4 doigts = masquer l'interface.").size(12.0).color(Color32::GRAY));
}


// ---------------- Écran d'accueil : la galerie ----------------

fn load_gallery(ctx: &egui::Context) -> Vec<GalleryEntry> {
    let mut files: Vec<_> = std::fs::read_dir(doc::drawings_dir())
        .map(|rd| rd.flatten().filter(|e| e.path().extension().is_some_and(|x| x == "yujin")).collect())
        .unwrap_or_default();
    files.sort_by_key(|e| std::cmp::Reverse(e.metadata().and_then(|m| m.modified()).ok()));
    files
        .into_iter()
        .filter_map(|e| {
            let path = e.path();
            let info = doc::read_info(&path)?;
            let tex = doc::read_thumb(&path).and_then(|d| doc::decode_png(&d)).map(|(w, h, px)| {
                ctx.load_texture(path.to_string_lossy(), egui::ColorImage::from_rgba_unmultiplied([w as usize, h as usize], &px), Default::default())
            });
            Some(GalleryEntry { path, name: info.name, w: info.w, h: info.h, tex })
        })
        .collect()
}

fn show_update(ctx: &egui::Context, update: Option<&crate::updater::Status>, actions: &mut Vec<Action>) {
    if let Some(u) = update {
        egui::Area::new(egui::Id::unique("update")).anchor(Align2::CENTER_BOTTOM, Vec2::new(0.0, -24.0)).order(egui::Order::Foreground).show(ctx, |ui| {
            egui::Frame::new().fill(Color32::from_rgb(42, 37, 51)).corner_radius(CornerRadius::same(14)).inner_margin(12.0).show(ui, |ui| {
                ui.horizontal(|ui| match u {
                    crate::updater::Status::Available { build, url } => {
                        ui.label(RichText::new(format!("Nouvelle version disponible (0.1.{build})")).color(Color32::WHITE));
                        if ui.add(egui::Button::new(RichText::new("Télécharger").color(Color32::WHITE)).fill(ACCENT)).clicked() {
                            actions.push(Action::OpenUrl(url.clone()));
                            actions.push(Action::DismissUpdate);
                        }
                        if ui.button("Plus tard").clicked() {
                            actions.push(Action::DismissUpdate);
                        }
                    }
                    crate::updater::Status::Installed { build } => {
                        ui.label(RichText::new(format!("Mise à jour 0.1.{build} installée")).color(Color32::WHITE));
                        if ui.add(egui::Button::new(RichText::new("Redémarrer").color(Color32::WHITE)).fill(ACCENT)).clicked() {
                            actions.push(Action::Restart);
                        }
                        if ui.button("Plus tard").clicked() {
                            actions.push(Action::DismissUpdate);
                        }
                    }
                });
            });
        });
    }
}

fn show_toast(ctx: &egui::Context, st: &mut UiState) {
    if let Some((msg, t)) = &st.toast {
        if t.elapsed().as_secs_f32() < 3.0 {
            egui::Area::new(egui::Id::unique("toast")).anchor(Align2::CENTER_BOTTOM, Vec2::new(0.0, -30.0)).order(egui::Order::Tooltip).show(ctx, |ui| {
                egui::Frame::new().fill(Color32::from_rgb(42, 37, 51)).corner_radius(CornerRadius::same(12)).inner_margin(12.0).show(ui, |ui| {
                    ui.label(RichText::new(msg.as_str()).color(Color32::WHITE));
                });
            });
            ctx.request_repaint_after(std::time::Duration::from_millis(250));
        } else {
            st.toast = None;
        }
    }
}

pub fn gallery_screen(ctx: &egui::Context, st: &mut UiState, update: Option<&crate::updater::Status>) -> Vec<Action> {
    let mut actions = Vec::new();
    if st.gal.list.is_none() {
        st.gal.list = Some(load_gallery(ctx));
    }
    let screen = ctx.content_rect();
    egui::Area::new(egui::Id::unique("gallery")).fixed_pos(Pos2::ZERO).order(egui::Order::Background).show(ctx, |ui| {
        ui.set_min_size(screen.size());
        ui.painter().rect_filled(screen, 0.0, Color32::from_rgb(17, 17, 19));
        egui::Frame::new().inner_margin(egui::Margin::symmetric(24, 14)).show(ui, |ui| {
            ui.set_width(screen.width() - 48.0);
            // barre du haut
            let narrow = screen.width() < 560.0;
            if narrow {
                ui.label(RichText::new("Galerie").size(26.0).strong().color(Color32::WHITE));
            }
            ui.horizontal(|ui| {
                if !narrow {
                    ui.label(RichText::new("Galerie").size(30.0).strong().color(Color32::WHITE));
                }
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    let plus = ui.add(egui::Button::new(RichText::new("+").size(26.0).color(Color32::WHITE)).fill(ACCENT).min_size(Vec2::splat(44.0)).corner_radius(22.0));
                    if plus.clicked() {
                        st.gal.new_open = !st.gal.new_open;
                    }
                    if bar_button(ui, "Photo", false).clicked() || bar_button(ui, "Importer", false).clicked() {
                        actions.push(Action::PickFiles);
                    }
                    let sel_on = st.gal.selecting.is_some();
                    if bar_button(ui, if sel_on { "Annuler" } else { "Sélectionner" }, sel_on).clicked() {
                        st.gal.selecting = if sel_on { None } else { Some(Default::default()) };
                        st.gal.confirm_delete = false;
                    }
                });
            });
            // actions de sélection
            if let Some(sel) = st.gal.selecting.clone() {
                ui.horizontal(|ui| {
                    ui.label(RichText::new(format!("{} sélectionné(s)", sel.len())).color(Color32::GRAY));
                    if ui.add_enabled(!sel.is_empty(), egui::Button::new("Dupliquer")).clicked() {
                        actions.push(Action::DuplicateDrawings(sel.iter().cloned().collect()));
                        st.gal.selecting = None;
                    }
                    if !st.gal.confirm_delete {
                        if ui.add_enabled(!sel.is_empty(), egui::Button::new("Supprimer")).clicked() {
                            st.gal.confirm_delete = true;
                        }
                    } else {
                        ui.label(RichText::new("Supprimer définitivement ?").color(Color32::from_rgb(255, 120, 120)));
                        if ui.add(egui::Button::new(RichText::new("Oui, supprimer").color(Color32::WHITE)).fill(Color32::from_rgb(190, 50, 60))).clicked() {
                            actions.push(Action::DeleteDrawings(sel.iter().cloned().collect()));
                            st.gal.selecting = None;
                            st.gal.confirm_delete = false;
                        }
                        if ui.button("Non").clicked() {
                            st.gal.confirm_delete = false;
                        }
                    }
                });
            }
            ui.add_space(10.0);
            let list = st.gal.list.as_ref().unwrap();
            if list.is_empty() {
                ui.add_space(80.0);
                ui.vertical_centered(|ui| {
                    ui.label(RichText::new("Aucun dessin pour l'instant").size(20.0).color(Color32::GRAY));
                    ui.label(RichText::new("Touche + pour créer une toile, ou Importer pour ouvrir un fichier Procreate.").color(Color32::GRAY));
                });
            }
            let mut open = None;
            let mut toggle = None;
            let mut start_rename = None;
            egui::ScrollArea::vertical().show(ui, |ui| {
                let card = if screen.width() < 560.0 { ((screen.width() - 48.0 - 16.0) / 2.0).max(120.0) } else { 230.0f32 };
                let cols = ((ui.available_width() + 16.0) / (card + 16.0)).floor().max(1.0) as usize;
                egui::Grid::new("gal_grid").spacing(Vec2::new(16.0, 18.0)).show(ui, |ui| {
                    for (i, e) in list.iter().enumerate() {
                        ui.vertical(|ui| {
                            let (r, resp) = ui.allocate_exact_size(Vec2::new(card, card * 0.78), Sense::click());
                            let selected = st.gal.selecting.as_ref().is_some_and(|s| s.contains(&e.path));
                            ui.painter().rect_filled(r, 10.0, Color32::from_rgb(40, 40, 46));
                            if let Some(t) = &e.tex {
                                let sz = t.size_vec2();
                                let k = ((r.width() - 12.0) / sz.x).min((r.height() - 12.0) / sz.y);
                                let ir = Rect::from_center_size(r.center(), sz * k);
                                ui.painter().rect_filled(ir.translate(Vec2::new(0.0, 3.0)), 3.0, Color32::from_black_alpha(90));
                                ui.painter().image(t.id(), ir, Rect::from_min_max(Pos2::ZERO, Pos2::new(1.0, 1.0)), Color32::WHITE);
                            }
                            if selected {
                                ui.painter().rect_stroke(r, 10.0, Stroke::new(3.0, ACCENT), egui::StrokeKind::Inside);
                                ui.painter().circle_filled(r.right_top() + Vec2::new(-18.0, 18.0), 11.0, ACCENT);
                            }
                            if resp.clicked() {
                                if st.gal.selecting.is_some() {
                                    toggle = Some(e.path.clone());
                                } else {
                                    open = Some(e.path.clone());
                                }
                            }
                            // nom (toucher pour renommer)
                            let renaming = st.gal.rename.as_ref().is_some_and(|(p, _)| *p == e.path);
                            if renaming {
                                let (_, txt) = st.gal.rename.as_mut().unwrap();
                                let ed = ui.add(egui::TextEdit::singleline(txt).desired_width(card));
                                ed.request_focus();
                                if ed.lost_focus() || ui.input(|i| i.key_pressed(egui::Key::Enter)) {
                                    let (p, n) = st.gal.rename.take().unwrap();
                                    let n = n.trim().to_string();
                                    if !n.is_empty() {
                                        actions.push(Action::Rename(p, n));
                                    }
                                }
                            } else if ui.add(egui::Label::new(RichText::new(&e.name).color(Color32::WHITE).size(15.0)).sense(Sense::click())).clicked() {
                                start_rename = Some((e.path.clone(), e.name.clone()));
                            }
                            ui.label(RichText::new(format!("{} × {} px", e.w, e.h)).size(12.0).color(Color32::GRAY));
                        });
                        if (i + 1) % cols == 0 {
                            ui.end_row();
                        }
                    }
                });
            });
            if let Some(p) = toggle {
                let s = st.gal.selecting.as_mut().unwrap();
                if !s.remove(&p) {
                    s.insert(p);
                }
            }
            if let Some(r) = start_rename {
                st.gal.rename = Some(r);
            }
            if let Some(p) = open {
                actions.push(Action::Open(p));
            }
        });
    });
    // menu « Nouvelle toile »
    if st.gal.new_open {
        egui::Area::new(egui::Id::unique("gal_new")).anchor(Align2::RIGHT_TOP, Vec2::new(-24.0, 70.0)).order(egui::Order::Foreground).show(ctx, |ui| {
            panel_frame().show(ui, |ui| {
                ui.set_width(300.0f32.min(screen.width() - 48.0));
                ui.heading("Nouvelle toile");
                for (name, w, h) in [("Format écran", 2560, 1600), ("Carré", 2048, 2048), ("A4 · 300 dpi", 2480, 3508), ("4K", 3840, 2160), ("Portrait (story)", 1080, 1920), ("Papier peint téléphone", 1440, 3120)] {
                    let r = ui.add(egui::Button::new(format!("{name}   {w} × {h} px")).min_size(Vec2::new(ui.available_width(), 36.0)));
                    if r.clicked() {
                        actions.push(Action::NewCanvas(w, h));
                        st.gal.new_open = false;
                    }
                }
                ui.separator();
                ui.label(RichText::new("Personnalisée").color(Color32::GRAY));
                ui.horizontal(|ui| {
                    ui.add(egui::DragValue::new(&mut st.gal.custom.0).range(16..=8192).suffix(" px"));
                    ui.label("×");
                    ui.add(egui::DragValue::new(&mut st.gal.custom.1).range(16..=8192).suffix(" px"));
                    if ui.add(egui::Button::new(RichText::new("Créer").color(Color32::WHITE)).fill(ACCENT)).clicked() {
                        actions.push(Action::NewCanvas(st.gal.custom.0, st.gal.custom.1));
                        st.gal.new_open = false;
                    }
                });
            });
        });
    }
    show_update(ctx, update, &mut actions);
    show_toast(ctx, st);
    actions
}
