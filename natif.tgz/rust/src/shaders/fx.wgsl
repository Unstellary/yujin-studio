// Ajustements d'image sur un calque (valeurs prémultipliées en entrée et en sortie).
struct U {
    kind: u32,
    p0: f32,
    p1: f32,
    p2: f32,
    dir: vec2<f32>,
    size: vec2<f32>,
    m0: vec4<f32>,
    m1: vec2<f32>,
};
@group(0) @binding(0) var<uniform> u: U;
@group(0) @binding(1) var src_t: texture_2d<f32>;

@vertex
fn vs(@builtin(vertex_index) vi: u32) -> @builtin(position) vec4<f32> {
    let x = f32((vi << 1u) & 2u) * 2.0 - 1.0;
    let y = f32(vi & 2u) * 2.0 - 1.0;
    return vec4<f32>(x, y, 0.0, 1.0);
}

fn rgb2hsv(c: vec3<f32>) -> vec3<f32> {
    let mx = max(c.r, max(c.g, c.b));
    let mn = min(c.r, min(c.g, c.b));
    let d = mx - mn;
    var h = 0.0;
    if (d > 1e-5) {
        if (mx == c.r) { h = ((c.g - c.b) / d) / 6.0; }
        else if (mx == c.g) { h = ((c.b - c.r) / d + 2.0) / 6.0; }
        else { h = ((c.r - c.g) / d + 4.0) / 6.0; }
    }
    h = fract(h + 1.0);
    var s = 0.0;
    if (mx > 0.0) { s = d / mx; }
    return vec3<f32>(h, s, mx);
}
fn hsv2rgb(c: vec3<f32>) -> vec3<f32> {
    let k = vec3<f32>(1.0, 2.0 / 3.0, 1.0 / 3.0);
    let p = abs(fract(c.xxx + k) * 6.0 - 3.0);
    return c.z * mix(vec3<f32>(1.0), clamp(p - 1.0, vec3<f32>(0.0), vec3<f32>(1.0)), c.y);
}
fn hash(p: vec2<f32>) -> f32 {
    return fract(sin(dot(p, vec2<f32>(12.9898, 78.233))) * 43758.5453);
}

@fragment
fn fs(@builtin(position) pos: vec4<f32>) -> @location(0) vec4<f32> {
    let ip = vec2<i32>(pos.xy);
    let sz = vec2<i32>(u.size);
    if (u.kind == 1u) {
        // flou gaussien séparable (une direction par passe)
        let r = max(u.p0, 0.5);
        let sigma = r / 2.0;
        let n = i32(ceil(r));
        var acc = vec4<f32>(0.0);
        var wsum = 0.0;
        for (var k = -n; k <= n; k = k + 1) {
            let q = clamp(ip + vec2<i32>(u.dir * f32(k)), vec2<i32>(0), sz - vec2<i32>(1));
            let w = exp(-f32(k * k) / (2.0 * sigma * sigma));
            acc = acc + textureLoad(src_t, q, 0) * w;
            wsum = wsum + w;
        }
        return acc / wsum;
    }
    if (u.kind == 7u) {
        // transformation : on lit la source à la position inverse (bilinéaire)
        let d = pos.xy;
        let sp = vec2<f32>(u.m0.x * d.x + u.m0.y * d.y + u.m0.z, u.m0.w * d.x + u.m1.x * d.y + u.m1.y) - vec2<f32>(0.5);
        let f = floor(sp);
        let t = sp - f;
        let i0 = vec2<i32>(f);
        var acc = vec4<f32>(0.0);
        for (var k = 0; k < 4; k = k + 1) {
            let o = vec2<i32>(k & 1, k >> 1);
            let q = i0 + o;
            var v = vec4<f32>(0.0);
            if (q.x >= 0 && q.y >= 0 && q.x < sz.x && q.y < sz.y) { v = textureLoad(src_t, q, 0); }
            let wx = select(1.0 - t.x, t.x, o.x == 1);
            let wy = select(1.0 - t.y, t.y, o.y == 1);
            acc = acc + v * wx * wy;
        }
        return acc;
    }
    let s = textureLoad(src_t, ip, 0);
    if (s.a <= 0.0) { return s; }
    var c = s.rgb / s.a;
    switch u.kind {
        case 0u: { // teinte / saturation / luminosité
            var h = rgb2hsv(c);
            h.x = fract(h.x + u.p0 + 1.0);
            h.y = clamp(h.y * u.p1, 0.0, 1.0);
            c = hsv2rgb(h);
            if (u.p2 >= 0.0) { c = mix(c, vec3<f32>(1.0), u.p2); } else { c = c * (1.0 + u.p2); }
        }
        case 2u: { // luminosité / contraste
            c = (c - 0.5) * u.p1 + 0.5 + u.p0;
        }
        case 3u: { c = 1.0 - c; } // négatif
        case 4u: { // bruit
            let n = hash(pos.xy + vec2<f32>(u.p1, u.p1 * 1.7)) - 0.5;
            c = c + n * u.p0;
        }
        case 5u: { // niveaux de gris
            let l = dot(c, vec3<f32>(0.299, 0.587, 0.114));
            c = mix(c, vec3<f32>(l), u.p0);
        }
        case 6u: { // balance des couleurs (cyan-rouge, magenta-vert, jaune-bleu)
            c = c + vec3<f32>(u.p0, u.p1, u.p2) * 0.5;
        }
        default: {}
    }
    c = clamp(c, vec3<f32>(0.0), vec3<f32>(1.0));
    return vec4<f32>(c * s.a, s.a);
}
