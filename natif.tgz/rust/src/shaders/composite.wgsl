// Composition des calques (couleurs prémultipliées, valeurs sRGB comme Procreate/Photoshop).
struct U {
    color: vec4<f32>,      // couleur du trait en cours (rgb), a inutilisé
    opacity: f32,          // opacité du calque
    mode: u32,             // mode de fusion
    stroke_mode: u32,      // 0 = rien, 1 = peinture, 2 = gomme, 3 = lumière
    stroke_opacity: f32,
    lock_alpha: u32,
    has_sel: u32,
    pad1: u32,
    pad2: u32,
};
@group(0) @binding(0) var<uniform> u: U;
@group(0) @binding(1) var back_t: texture_2d<f32>;
@group(0) @binding(2) var layer_t: texture_2d<f32>;
@group(0) @binding(3) var stroke_t: texture_2d<f32>;
@group(0) @binding(4) var sel_t: texture_2d<f32>;

fn sel_at(ip: vec2<i32>) -> f32 {
    if (u.has_sel == 0u) { return 1.0; }
    return textureLoad(sel_t, ip, 0).r;
}

@vertex
fn vs(@builtin(vertex_index) vi: u32) -> @builtin(position) vec4<f32> {
    let x = f32((vi << 1u) & 2u) * 2.0 - 1.0;
    let y = f32(vi & 2u) * 2.0 - 1.0;
    return vec4<f32>(x, y, 0.0, 1.0);
}

fn layer_with_stroke(ip: vec2<i32>) -> vec4<f32> {
    var l = textureLoad(layer_t, ip, 0);
    if (u.stroke_mode == 1u) {
        var s = textureLoad(stroke_t, ip, 0).r * u.stroke_opacity * sel_at(ip);
        if (u.lock_alpha == 1u) {
            let a = l.a;
            let c = u.color.rgb * a;
            l = vec4<f32>(mix(l.rgb, c, s), a);
        } else {
            l = vec4<f32>(u.color.rgb * s, s) + l * (1.0 - s);
        }
    } else if (u.stroke_mode == 2u) {
        let s = textureLoad(stroke_t, ip, 0).r * u.stroke_opacity * sel_at(ip);
        l = l * (1.0 - s);
    } else if (u.stroke_mode == 3u) {
        // lumière : la couleur s'ajoute, le cœur blanchit
        let s = textureLoad(stroke_t, ip, 0).r * u.stroke_opacity * sel_at(ip);
        let add = u.color.rgb * s + vec3<f32>(max(s - 0.6, 0.0) * 1.2);
        if (u.lock_alpha == 1u) {
            l = vec4<f32>(min(l.rgb + add * l.a, vec3<f32>(l.a)), l.a);
        } else {
            let a = l.a + s * (1.0 - l.a);
            l = vec4<f32>(min(l.rgb + add, vec3<f32>(a)), a);
        }
    }
    return l;
}

fn lum(c: vec3<f32>) -> f32 { return dot(c, vec3<f32>(0.3, 0.59, 0.11)); }
fn clip_color(c: vec3<f32>) -> vec3<f32> {
    let l = lum(c);
    let n = min(c.r, min(c.g, c.b));
    let x = max(c.r, max(c.g, c.b));
    var o = c;
    if (n < 0.0) { o = l + (o - l) * l / max(l - n, 1e-5); }
    if (x > 1.0) { o = l + (o - l) * (1.0 - l) / max(x - l, 1e-5); }
    return o;
}
fn set_lum(c: vec3<f32>, l: f32) -> vec3<f32> { return clip_color(c + (l - lum(c))); }
fn sat(c: vec3<f32>) -> f32 { return max(c.r, max(c.g, c.b)) - min(c.r, min(c.g, c.b)); }
fn set_sat(c: vec3<f32>, s: f32) -> vec3<f32> {
    let mx = max(c.r, max(c.g, c.b));
    let mn = min(c.r, min(c.g, c.b));
    if (mx - mn < 1e-5) { return vec3<f32>(0.0); }
    return (c - mn) * s / (mx - mn);
}

fn soft_light1(b: f32, s: f32) -> f32 {
    if (s <= 0.5) { return b - (1.0 - 2.0 * s) * b * (1.0 - b); }
    var d: f32;
    if (b <= 0.25) { d = ((16.0 * b - 12.0) * b + 4.0) * b; } else { d = sqrt(b); }
    return b + (2.0 * s - 1.0) * (d - b);
}

// b = fond, s = calque (non prémultipliés)
fn blend(b: vec3<f32>, s: vec3<f32>, m: u32) -> vec3<f32> {
    switch m {
        case 1u: { return b * s; }                                  // Produit
        case 2u: { return b + s - b * s; }                          // Écran
        case 3u: {                                                  // Incrustation
            return select(1.0 - 2.0 * (1.0 - b) * (1.0 - s), 2.0 * b * s, b <= vec3<f32>(0.5));
        }
        case 4u: { return min(b, s); }                              // Obscurcir
        case 5u: { return max(b, s); }                              // Éclaircir
        case 6u: {                                                  // Densité couleur -
            return select(min(vec3<f32>(1.0), b / max(1.0 - s, vec3<f32>(1e-5))), vec3<f32>(0.0), b <= vec3<f32>(0.0));
        }
        case 7u: {                                                  // Densité couleur +
            return select(1.0 - min(vec3<f32>(1.0), (1.0 - b) / max(s, vec3<f32>(1e-5))), vec3<f32>(1.0), b >= vec3<f32>(1.0));
        }
        case 8u: {                                                  // Lumière crue
            return select(1.0 - 2.0 * (1.0 - b) * (1.0 - s), 2.0 * b * s, s <= vec3<f32>(0.5));
        }
        case 9u: { return vec3<f32>(soft_light1(b.r, s.r), soft_light1(b.g, s.g), soft_light1(b.b, s.b)); } // Lumière tamisée
        case 10u: { return abs(b - s); }                            // Différence
        case 11u: { return b + s - 2.0 * b * s; }                   // Exclusion
        case 12u: { return min(vec3<f32>(1.0), b + s); }            // Ajout
        case 13u: { return max(vec3<f32>(0.0), b - s); }            // Soustraction
        case 14u: { return set_lum(set_sat(s, sat(b)), lum(b)); }   // Teinte
        case 15u: { return set_lum(set_sat(b, sat(s)), lum(b)); }   // Saturation
        case 16u: { return set_lum(s, lum(b)); }                    // Couleur
        case 17u: { return set_lum(b, lum(s)); }                    // Luminosité
        case 18u: { return max(vec3<f32>(0.0), b + s - 1.0); }      // Densité linéaire -
        default: { return s; }                                      // Normal
    }
}

@fragment
fn fs_composite(@builtin(position) p: vec4<f32>) -> @location(0) vec4<f32> {
    let ip = vec2<i32>(p.xy);
    let b = textureLoad(back_t, ip, 0);
    let l = layer_with_stroke(ip) * u.opacity;
    if (l.a <= 0.0) { return b; }
    if (u.mode == 0u || b.a <= 0.0) { return l + b * (1.0 - l.a); }
    let cb = b.rgb / b.a;
    let cs = l.rgb / l.a;
    let mixed = clamp(blend(cb, cs, u.mode), vec3<f32>(0.0), vec3<f32>(1.0));
    let rgb = (1.0 - l.a) * b.rgb + (1.0 - b.a) * l.rgb + l.a * b.a * mixed;
    return vec4<f32>(rgb, l.a + b.a * (1.0 - l.a));
}

// Fusion du trait dans le calque (sortie = nouveau contenu du calque)
@fragment
fn fs_commit(@builtin(position) p: vec4<f32>) -> @location(0) vec4<f32> {
    return layer_with_stroke(vec2<i32>(p.xy));
}

// Affichage : la texture cible est en sRGB, on lui donne des valeurs linéaires
// pour que les octets stockés restent ceux de la composition.
fn to_linear(c: vec3<f32>) -> vec3<f32> {
    return select(pow((c + 0.055) / 1.055, vec3<f32>(2.4)), c / 12.92, c <= vec3<f32>(0.04045));
}
@fragment
fn fs_present(@builtin(position) p: vec4<f32>) -> @location(0) vec4<f32> {
    let v = textureLoad(layer_t, vec2<i32>(p.xy), 0);
    return vec4<f32>(to_linear(v.rgb), v.a);
}

// Ajustement limité à la sélection : mélange calque d'origine (back) / calque ajusté (layer)
@fragment
fn fs_selmix(@builtin(position) p: vec4<f32>) -> @location(0) vec4<f32> {
    let ip = vec2<i32>(p.xy);
    let m = sel_at(ip);
    return mix(textureLoad(back_t, ip, 0), textureLoad(layer_t, ip, 0), m);
}
