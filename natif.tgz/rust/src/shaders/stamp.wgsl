// Tampons de pinceau : un quad par tampon, dessiné dans la texture de trait (R8).
struct Globals { canvas: vec2<f32>, pad: vec2<f32> };
@group(0) @binding(0) var<uniform> g: Globals;
@group(0) @binding(1) var tip_t: texture_2d<f32>;
@group(0) @binding(2) var tip_s: sampler;

struct Inst {
    @location(0) pos: vec2<f32>,
    @location(1) size: f32,
    @location(2) angle: f32,
    @location(3) alpha: f32,
};
struct VOut {
    @builtin(position) p: vec4<f32>,
    @location(0) uv: vec2<f32>,
    @location(1) a: f32,
};

@vertex
fn vs(@builtin(vertex_index) vi: u32, inst: Inst) -> VOut {
    var corners = array<vec2<f32>, 6>(
        vec2<f32>(-0.5, -0.5), vec2<f32>(0.5, -0.5), vec2<f32>(0.5, 0.5),
        vec2<f32>(-0.5, -0.5), vec2<f32>(0.5, 0.5), vec2<f32>(-0.5, 0.5));
    let c = corners[vi];
    let cs = cos(inst.angle);
    let sn = sin(inst.angle);
    let r = vec2<f32>(c.x * cs - c.y * sn, c.x * sn + c.y * cs) * inst.size;
    let px = inst.pos + r;
    var o: VOut;
    o.p = vec4<f32>(px.x / g.canvas.x * 2.0 - 1.0, 1.0 - px.y / g.canvas.y * 2.0, 0.0, 1.0);
    o.uv = c + vec2<f32>(0.5, 0.5);
    o.a = inst.alpha;
    return o;
}

@fragment
fn fs(i: VOut) -> @location(0) vec4<f32> {
    let m = textureSample(tip_t, tip_s, i.uv).r * i.a;
    return vec4<f32>(m, m, m, m);
}
