// Estompe : on reprend la peinture sous le tampon précédent et on l'étale au tampon suivant.
struct Globals { canvas: vec2<f32>, pad: vec2<f32> };
struct SmU { pos: vec2<f32>, size: f32, strength: f32 };
@group(0) @binding(0) var<uniform> g: Globals;
@group(0) @binding(1) var tip_t: texture_2d<f32>;
@group(0) @binding(2) var tip_s: sampler;
@group(0) @binding(3) var pick_t: texture_2d<f32>;
@group(0) @binding(4) var<uniform> u: SmU;

struct VOut { @builtin(position) p: vec4<f32>, @location(0) uv: vec2<f32> };

@vertex
fn vs(@builtin(vertex_index) vi: u32) -> VOut {
    var corners = array<vec2<f32>, 6>(
        vec2<f32>(0.0, 0.0), vec2<f32>(1.0, 0.0), vec2<f32>(1.0, 1.0),
        vec2<f32>(0.0, 0.0), vec2<f32>(1.0, 1.0), vec2<f32>(0.0, 1.0));
    let c = corners[vi];
    let px = u.pos + c * u.size;
    var o: VOut;
    o.p = vec4<f32>(px.x / g.canvas.x * 2.0 - 1.0, 1.0 - px.y / g.canvas.y * 2.0, 0.0, 1.0);
    o.uv = c;
    return o;
}

fn amount(uv: vec2<f32>) -> f32 {
    return textureSampleLevel(tip_t, tip_s, uv, 0.0).r * u.strength;
}

// 1re passe : le calque est multiplié par (1 - k)
@fragment
fn fs_fade(i: VOut) -> @location(0) vec4<f32> {
    let k = amount(i.uv);
    return vec4<f32>(0.0, 0.0, 0.0, k);
}

// 2e passe : on ajoute la peinture reprise × k
@fragment
fn fs_add(i: VOut) -> @location(0) vec4<f32> {
    let k = amount(i.uv);
    let dims = vec2<f32>(textureDimensions(pick_t));
    let q = clamp(vec2<i32>(i.uv * u.size), vec2<i32>(0), vec2<i32>(dims) - vec2<i32>(1));
    return textureLoad(pick_t, q, 0) * k;
}
