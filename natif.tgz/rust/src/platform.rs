//! Fonctions propres à chaque système (exports, ouverture de liens).

use std::path::PathBuf;

fn exports_dir() -> PathBuf {
    #[cfg(target_os = "android")]
    {
        return PathBuf::from("/storage/emulated/0/Pictures/Yujin Studio");
    }
    #[cfg(target_os = "windows")]
    {
        if let Ok(p) = std::env::var("USERPROFILE") {
            return PathBuf::from(p).join("Pictures").join("Yujin Studio");
        }
    }
    #[allow(unreachable_code)]
    if let Ok(h) = std::env::var("HOME") {
        return PathBuf::from(h).join("Pictures").join("Yujin Studio");
    }
    crate::doc::data_dir().join("exports")
}

/// Enregistre un fichier exporté ; renvoie l'endroit où il se trouve.
pub fn save_export(name: &str, mime: &str, data: &[u8]) -> Result<String, String> {
    #[cfg(target_os = "android")]
    {
        match android::save_media(name, mime, data) {
            Ok(w) => return Ok(w),
            Err(e) => log::warn!("MediaStore : {e}"),
        }
    }
    let _ = mime;
    let mut dir = exports_dir();
    if std::fs::create_dir_all(&dir).is_err() {
        dir = crate::doc::data_dir().join("exports");
        std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    }
    let safe: String = name.chars().map(|c| if "\\/:*?\"<>|".contains(c) { '_' } else { c }).collect();
    let (stem, ext) = match safe.rsplit_once('.') {
        Some((s, e)) => (s.to_string(), format!(".{e}")),
        None => (safe.clone(), String::new()),
    };
    let mut path = dir.join(&safe);
    let mut k = 2;
    while path.exists() {
        path = dir.join(format!("{stem} ({k}){ext}"));
        k += 1;
    }
    std::fs::write(&path, data).map_err(|e| e.to_string())?;
    Ok(path.parent().map(|p| p.display().to_string()).unwrap_or_default())
}

/// Ouvre un lien dans le navigateur.
pub fn open_url(url: &str) {
    #[cfg(target_os = "android")]
    {
        if let Err(e) = android::open_url(url) {
            log::warn!("ouverture du lien : {e}");
        }
    }
    #[cfg(target_os = "windows")]
    {
        let _ = std::process::Command::new("cmd").args(["/C", "start", "", url]).spawn();
    }
    #[cfg(all(not(target_os = "android"), not(target_os = "windows")))]
    {
        let _ = std::process::Command::new("xdg-open").arg(url).spawn();
    }
}

#[cfg(target_os = "android")]
pub mod android {
    use jni::objects::{JObject, JValue};
    use jni::JavaVM;

    fn with_env<T>(f: impl FnOnce(&mut jni::JNIEnv, &JObject) -> jni::errors::Result<T>) -> Result<T, String> {
        let ctx = ndk_context::android_context();
        let vm = unsafe { JavaVM::from_raw(ctx.vm().cast()) }.map_err(|e| e.to_string())?;
        let mut env = vm.attach_current_thread().map_err(|e| e.to_string())?;
        let activity = unsafe { JObject::from_raw(ctx.context().cast()) };
        let r = f(&mut env, &activity);
        if env.exception_check().unwrap_or(false) {
            let _ = env.exception_describe();
            let _ = env.exception_clear();
            return Err("exception Java".into());
        }
        r.map_err(|e| e.to_string())
    }

    pub fn open_url(url: &str) -> Result<(), String> {
        with_env(|env, activity| {
            let jurl = env.new_string(url)?;
            let uri = env.call_static_method("android/net/Uri", "parse", "(Ljava/lang/String;)Landroid/net/Uri;", &[JValue::Object(&jurl)])?.l()?;
            let action = env.new_string("android.intent.action.VIEW")?;
            let intent = env.new_object("android/content/Intent", "(Ljava/lang/String;Landroid/net/Uri;)V", &[JValue::Object(&action), JValue::Object(&uri)])?;
            env.call_method(&intent, "addFlags", "(I)Landroid/content/Intent;", &[JValue::Int(0x1000_0000)])?;
            env.call_method(activity, "startActivity", "(Landroid/content/Intent;)V", &[JValue::Object(&intent)])?;
            Ok(())
        })
    }

    pub fn pick_files() -> Result<(), String> {
        with_env(|env, activity| {
            env.call_method(activity, "pickFiles", "()V", &[])?;
            Ok(())
        })
    }

    /// Enregistre dans la galerie (Images / Films / Téléchargements) via MediaStore.
    pub fn save_media(name: &str, mime: &str, data: &[u8]) -> Result<String, String> {
        let (coll_class, dir, label) = if mime.starts_with("image/") && mime != "image/vnd.adobe.photoshop" {
            ("android/provider/MediaStore$Images$Media", "Pictures/Yujin Studio", "Images/Yujin Studio")
        } else if mime.starts_with("video/") {
            ("android/provider/MediaStore$Video$Media", "Movies/Yujin Studio", "Films/Yujin Studio")
        } else {
            ("android/provider/MediaStore$Downloads", "Download/Yujin Studio", "Téléchargements/Yujin Studio")
        };
        with_env(|env, activity| {
            let resolver = env.call_method(activity, "getContentResolver", "()Landroid/content/ContentResolver;", &[])?.l()?;
            let vol = env.new_string("external_primary")?;
            let coll = env.call_static_method(coll_class, "getContentUri", "(Ljava/lang/String;)Landroid/net/Uri;", &[JValue::Object(&vol)])?.l()?;
            let cv = env.new_object("android/content/ContentValues", "()V", &[])?;
            let put = |env: &mut jni::JNIEnv, k: &str, v: &str| -> jni::errors::Result<()> {
                let k = env.new_string(k)?;
                let v = env.new_string(v)?;
                env.call_method(&cv, "put", "(Ljava/lang/String;Ljava/lang/String;)V", &[JValue::Object(&k), JValue::Object(&v)])?;
                Ok(())
            };
            put(env, "_display_name", name)?;
            put(env, "mime_type", mime)?;
            put(env, "relative_path", dir)?;
            let uri = env.call_method(&resolver, "insert", "(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;", &[JValue::Object(&coll), JValue::Object(&cv)])?.l()?;
            if uri.is_null() {
                return Err(jni::errors::Error::NullPtr("insert"));
            }
            let os = env.call_method(&resolver, "openOutputStream", "(Landroid/net/Uri;)Ljava/io/OutputStream;", &[JValue::Object(&uri)])?.l()?;
            let arr = env.byte_array_from_slice(data)?;
            env.call_method(&os, "write", "([B)V", &[JValue::Object(&arr)])?;
            env.call_method(&os, "close", "()V", &[])?;
            Ok(label.to_string())
        })
    }
}

// ---------------- Choix de fichiers ----------------

static PICKED: std::sync::Mutex<Vec<PathBuf>> = std::sync::Mutex::new(Vec::new());
static WAKE: std::sync::Mutex<Option<Box<dyn Fn() + Send>>> = std::sync::Mutex::new(None);

/// Fonction appelée pour réveiller l'appli quand des fichiers arrivent.
pub fn set_wake(f: impl Fn() + Send + 'static) {
    *WAKE.lock().unwrap() = Some(Box::new(f));
}

pub fn push_picked(paths: Vec<PathBuf>) {
    if paths.is_empty() {
        return;
    }
    PICKED.lock().unwrap().extend(paths);
    if let Some(w) = WAKE.lock().unwrap().as_ref() {
        w();
    }
}

pub fn take_picked() -> Vec<PathBuf> {
    std::mem::take(&mut *PICKED.lock().unwrap())
}

/// Ouvre le sélecteur de fichiers du système (le résultat arrive plus tard).
pub fn pick_files() {
    #[cfg(target_os = "android")]
    {
        if let Err(e) = android::pick_files() {
            log::warn!("sélecteur de fichiers : {e}");
        }
    }
    #[cfg(not(target_os = "android"))]
    {
        std::thread::spawn(|| {
            let files = rfd::FileDialog::new()
                .set_title("Importer dans Yujin Studio")
                .add_filter("Fichiers Procreate et images", &["brush", "brushset", "swatches", "procreate", "png", "jpg", "jpeg", "webp"])
                .add_filter("Tous les fichiers", &["*"])
                .pick_files();
            if let Some(f) = files {
                push_picked(f);
            }
        });
    }
}

#[cfg(target_os = "android")]
pub mod android_jni {
    use jni::objects::{JClass, JObjectArray, JString};
    use jni::JNIEnv;

    /// Appelée par MainActivity.java quand l'utilisateur a choisi des fichiers (copiés dans le cache).
    #[no_mangle]
    pub extern "system" fn Java_fr_unstellary_yujinstudio_natif_MainActivity_nativeFilesPicked(mut env: JNIEnv, _class: JClass, arr: JObjectArray) {
        let n = env.get_array_length(&arr).unwrap_or(0);
        let mut out = Vec::new();
        for i in 0..n {
            if let Ok(o) = env.get_object_array_element(&arr, i) {
                let js = JString::from(o);
                if let Ok(s) = env.get_string(&js) {
                    out.push(std::path::PathBuf::from(String::from(s)));
                }
            }
        }
        super::push_picked(out);
    }
}
