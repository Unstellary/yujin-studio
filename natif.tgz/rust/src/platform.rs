//! Fonctions propres à chaque système (enregistrement des exports).

use std::path::PathBuf;

fn exports_dir() -> PathBuf {
    #[cfg(target_os = "android")]
    {
        return PathBuf::from("/storage/emulated/0/Pictures/Yujin Studio");
    }
    #[cfg(target_os = "windows")]
    {
        if let Ok(p) = std::env::var("USERPROFILE") {
            return PathBuf::from(p).join("Pictures").join("Yujin Studio");
        }
    }
    #[allow(unreachable_code)]
    if let Ok(h) = std::env::var("HOME") {
        return PathBuf::from(h).join("Pictures").join("Yujin Studio");
    }
    crate::doc::data_dir().join("exports")
}

/// Enregistre un fichier exporté ; renvoie l'endroit où il se trouve.
pub fn save_export(name: &str, _mime: &str, data: &[u8]) -> Result<String, String> {
    let mut dir = exports_dir();
    if std::fs::create_dir_all(&dir).is_err() {
        dir = crate::doc::data_dir().join("exports");
        std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    }
    let safe: String = name.chars().map(|c| if "\\/:*?\"<>|".contains(c) { '_' } else { c }).collect();
    let (stem, ext) = match safe.rsplit_once('.') {
        Some((s, e)) => (s.to_string(), format!(".{e}")),
        None => (safe.clone(), String::new()),
    };
    let mut path = dir.join(&safe);
    let mut k = 2;
    while path.exists() {
        path = dir.join(format!("{stem} ({k}){ext}"));
        k += 1;
    }
    std::fs::write(&path, data).map_err(|e| e.to_string())?;
    Ok(path.parent().map(|p| p.display().to_string()).unwrap_or_default())
}
