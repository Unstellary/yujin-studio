//! Aperçus des pinceaux : chaque pinceau trace une vraie courbe en S avec le moteur GPU,
//! le résultat devient une texture affichée dans la bibliothèque (comme Procreate).
use crate::brush::{Brush, Point, StrokeBuilder};
use crate::gpu::{Engine, LayerDraw, StrokeState, Tip};
use std::collections::HashMap;

pub const W: u32 = 600;
pub const H: u32 = 150;

pub struct Previews {
    engine: Option<Engine>,
    tips: HashMap<String, Tip>,
}

impl Previews {
    pub fn new() -> Self {
        Previews { engine: None, tips: HashMap::new() }
    }

    /// Rend l'aperçu d'un pinceau (RGBA prémultiplié, W×H).
    pub fn render(&mut self, device: &wgpu::Device, queue: &wgpu::Queue, srgb: bool, b: &Brush) -> Vec<u8> {
        let e = self.engine.get_or_insert_with(|| {
            let mut e = Engine::new(device.clone(), queue.clone(), W, H, srgb);
            let l = e.new_layer();
            e.layers.push(l);
            e
        });
        let key = crate::library::tip_key(b);
        if !self.tips.contains_key(&key) {
            let (tip, grain) = crate::library::masks(b);
            let t = e.make_tip(crate::brush::TIP, &tip, grain.as_deref(), b.grain_scale, b.op_map);
            self.tips.insert(key.clone(), t);
        }
        let tip = &self.tips[&key];
        e.clear_layer(0);
        e.begin_stroke();
        let size = (b.max_size * 3.0).clamp(6.0, 54.0);
        let mut sb = StrokeBuilder::new(b.clone(), size, 1.0);
        let n = 90;
        let mut last = Point { x: 0.0, y: 0.0, p: 0.0, t: 0.0 };
        for i in 0..=n {
            let t = i as f32 / n as f32;
            let p = (t * std::f32::consts::PI).sin().powf(0.6).max(0.02);
            last = Point { x: 40.0 + t * (W as f32 - 80.0), y: H as f32 * 0.5 - (t * std::f32::consts::TAU).sin() * H as f32 * 0.24, p, t: t * 0.7 };
            let d = sb.add(last);
            e.stamp(tip, &d);
        }
        let d = sb.finish(last);
        e.stamp(tip, &d);
        let ld = LayerDraw { index: 0, visible: true, opacity: 1.0, mode: 0, lock_alpha: false };
        e.commit_stroke(0, &ld, StrokeState { color: [1.0, 1.0, 1.0], opacity: 1.0, erase: false, glow: b.glow });
        e.read_layer(0)
    }
}
