use yujin_studio::{doc, psd};
fn main() {
    let (w, h) = (64u32, 48u32);
    let mut info = doc::DocInfo::new(w, h);
    info.layers.push(doc::LayerInfo { name: "Ombre éclatée".into(), visible: false, opacity: 0.5, mode: 1, lock_alpha: false });
    let mut l0 = vec![0u8; (w * h * 4) as usize];
    let mut l1 = l0.clone();
    for y in 0..h { for x in 0..w { let i = ((y * w + x) * 4) as usize;
        if x < 32 { l0[i..i+4].copy_from_slice(&[255, 0, 0, 255]); }
        if y > 20 { l1[i..i+4].copy_from_slice(&[0, 0, 255, 128]); } } }
    let flat: Vec<u8> = l0.iter().zip(l1.iter()).enumerate().map(|(i, (a, _))| if i % 4 == 3 { 255 } else { *a }).collect();
    std::fs::write("/tmp/t.psd", psd::write(&info, &[l0, l1], &flat)).unwrap();
}
