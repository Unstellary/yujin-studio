// Test des imports Procreate + rendu d'un trait avec chaque pinceau importé.
use yujin_studio::brush::{Point, StrokeBuilder};
use yujin_studio::{doc, gpu, library, procreate};

fn main() {
    let dir = std::path::Path::new("/home/claude/ptest");
    // décodeurs de tuiles
    let raw = std::fs::read(dir.join("tile.raw")).unwrap();
    for f in ["tile.lzo", "tile.lz4", "tile.bv4"] {
        let c = std::fs::read(dir.join(f)).unwrap();
        println!("{f}: ok = {}", procreate_test_decode(&c, raw.len()).map(|d| d == raw).unwrap_or(false));
    }
    for f in ["test.procreate", "flip.procreate"] {
        let d = procreate::import_procreate(&std::fs::read(dir.join(f)).unwrap(), f).unwrap();
        println!("{f}: {} {}x{} calques={} {:?}", d.name, d.w, d.h, d.layers.len(), d.layers.iter().map(|l| (&l.name, l.mode, l.opacity)).collect::<Vec<_>>());
    }
    let sw = procreate::import_swatches(&std::fs::read(dir.join("test.swatches")).unwrap(), "test.swatches").unwrap();
    println!("palettes: {:?}", sw.iter().map(|(n, c)| (n, c.len())).collect::<Vec<_>>());

    std::env::set_var("HOME", "/tmp/yuj_imp");
    let _ = std::fs::remove_dir_all("/tmp/yuj_imp");
    let mut all = library::load();
    for f in ["Lashes.brush", "Lineart_Clean.brush", "Lineart_Soft.brush", "Lineart_Mini.brushset", "glitter.brushset", "test.brushset"] {
        match library::import(&mut all, &std::fs::read(dir.join(f)).unwrap(), f) {
            Ok((c, n)) => println!("{f}: {n} pinceaux dans {c}"),
            Err(e) => println!("{f}: ERREUR {e}"),
        }
    }
    let imported: Vec<_> = all.iter().filter(|b| !library::is_builtin(b)).cloned().collect();
    for b in &imported {
        println!("  - {} [{}] max={} sp={} sizeP={} opP={} flow={} taper=({},{},{}) follow={} grain={:?} opmap={} scatter={} count={}", b.name, b.cat, b.max_size, b.spacing, b.size_p, b.op_p, b.flow, b.taper_start, b.taper_end, b.taper_size, b.follow, b.grain.is_some(), b.op_map, b.scatter, b.count);
    }
    // rendu
    let instance = wgpu::Instance::new(wgpu::InstanceDescriptor { backends: wgpu::Backends::all(), ..wgpu::InstanceDescriptor::new_without_display_handle() });
    let adapter = pollster::block_on(instance.request_adapter(&Default::default())).unwrap();
    let (device, queue) = pollster::block_on(adapter.request_device(&wgpu::DeviceDescriptor { required_limits: wgpu::Limits::downlevel_webgl2_defaults().using_resolution(adapter.limits()), ..Default::default() })).unwrap();
    let rows = imported.len().min(12) as u32;
    let (w, h) = (900u32, 70 * rows + 20);
    let mut e = gpu::Engine::new(device, queue, w, h, false);
    let l = e.new_layer();
    e.layers.push(l);
    for (i, b) in imported.iter().take(12).enumerate() {
        let (tip, grain) = library::masks(b);
        let t = e.make_tip(256, &tip, grain.as_deref(), b.grain_scale, b.op_map);
        e.begin_stroke();
        let size = (b.max_size * b.def_size.max(0.05)).min(40.0).max(6.0);
        let mut sb = StrokeBuilder::new(b.clone(), size, 1.0);
        let y0 = 45.0 + i as f32 * 70.0;
        let mut last = Point { x: 30.0, y: y0, p: 0.0, t: 0.0 };
        for k in 0..=100 {
            let tt = k as f32 / 100.0;
            last = Point { x: 30.0 + tt * 840.0, y: y0 + (tt * 9.0).sin() * 14.0, p: (tt * std::f32::consts::PI).sin(), t: tt * 0.6 };
            let d = sb.add(last);
            e.stamp(&t, &d);
        }
        let d = sb.finish(last);
        e.stamp(&t, &d);
        if sb.needs_replay() {
            e.clear_stroke();
            e.stroke_bbox = None;
            let d = sb.replay();
            e.stamp(&t, &d);
        }
        let ld = gpu::LayerDraw { index: 0, visible: true, opacity: 1.0, mode: 0, lock_alpha: false };
        e.commit_stroke(0, &ld, gpu::StrokeState { color: [0.15, 0.1, 0.25], opacity: 1.0, erase: false });
    }
    let ld = vec![gpu::LayerDraw { index: 0, visible: true, opacity: 1.0, mode: 0, lock_alpha: false }];
    e.compose(Some([1.0, 1.0, 1.0]), &ld, 0, None, 1);
    let mut px = e.read_display();
    doc::unpremultiply(&mut px);
    std::fs::write("/tmp/yujin_brushes.png", doc::encode_png(w, h, &px)).unwrap();
    println!("OK");
}

fn procreate_test_decode(c: &[u8], n: usize) -> Option<Vec<u8>> {
    yujin_studio::procreate::decode_chunk_pub(c, n)
}
