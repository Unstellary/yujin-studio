// Test sans écran : dessine quelques traits avec le moteur GPU et enregistre le résultat en PNG.
use yujin_studio::brush::{self, Point, StrokeBuilder};
use yujin_studio::doc;
use yujin_studio::gpu::{Engine, LayerDraw, StrokeState};

fn main() {
    let instance = wgpu::Instance::new(wgpu::InstanceDescriptor { backends: wgpu::Backends::all(), ..wgpu::InstanceDescriptor::new_without_display_handle() });
    let adapter = pollster::block_on(instance.request_adapter(&wgpu::RequestAdapterOptions { force_fallback_adapter: false, ..Default::default() })).expect("adapter");
    println!("adaptateur : {:?}", adapter.get_info());
    let (device, queue) = pollster::block_on(adapter.request_device(&wgpu::DeviceDescriptor { required_limits: wgpu::Limits::downlevel_webgl2_defaults().using_resolution(adapter.limits()), ..Default::default() })).expect("device");
    let (w, h) = (800u32, 500u32);
    let srgb = adapter.get_downlevel_capabilities().flags.contains(wgpu::DownlevelFlags::VIEW_FORMATS);
    let mut e = Engine::new(device, queue, w, h, srgb);
    let l0 = e.new_layer();
    e.layers.push(l0);
    let l1 = e.new_layer();
    e.layers.push(l1);
    let lib = brush::library();
    let tips: Vec<_> = [brush::Shape::Hard, brush::Shape::Soft, brush::Shape::Pencil, brush::Shape::Chalk].iter().map(|s| e.make_tip(brush::TIP, &brush::make_tip(*s))).collect();
    let draws = |m1: u32| vec![
        LayerDraw { index: 0, visible: true, opacity: 1.0, mode: 0, lock_alpha: false },
        LayerDraw { index: 1, visible: true, opacity: 0.8, mode: m1, lock_alpha: false },
    ];
    let mut stroke = |e: &mut Engine, layer: usize, bi: usize, size: f32, color: [f32; 3], erase: bool, y: f32| {
        let b = lib[bi].clone();
        let ti = match b.shape { brush::Shape::Hard => 0, brush::Shape::Soft => 1, brush::Shape::Pencil => 2, brush::Shape::Chalk => 3 };
        e.begin_stroke();
        let mut sb = StrokeBuilder::new(b, size, 1.0);
        let mut last = Point { x: 40.0, y, p: 0.0 };
        for i in 0..=120 {
            let t = i as f32 / 120.0;
            last = Point { x: 40.0 + t * 720.0, y: y + (t * 9.0).sin() * 30.0, p: (t * std::f32::consts::PI).sin() };
            let d = sb.add(last);
            e.stamp(&tips[ti], &d);
        }
        let d = sb.finish(last);
        e.stamp(&tips[ti], &d);
        let st = StrokeState { color, opacity: 1.0, erase };
        let r = e.stroke_rect().expect("rect");
        let _undo = e.save_region(layer, r);
        let dl = draws(0)[layer];
        e.commit_stroke(layer, &dl, st);
    };
    stroke(&mut e, 0, 0, 30.0, [0.1, 0.1, 0.15], false, 70.0);
    stroke(&mut e, 0, 3, 40.0, [0.85, 0.2, 0.3], false, 170.0);
    stroke(&mut e, 0, 6, 160.0, [0.2, 0.5, 0.95], false, 280.0);
    stroke(&mut e, 1, 8, 50.0, [0.95, 0.8, 0.1], false, 250.0);
    stroke(&mut e, 0, 0, 25.0, [0.0, 0.0, 0.0], true, 170.0);
    stroke(&mut e, 0, 4, 20.0, [0.3, 0.3, 0.3], false, 420.0);
    e.compose(Some([1.0, 1.0, 1.0]), &draws(1), 1, None, 1);
    let mut px = e.read_display();
    doc::unpremultiply(&mut px);
    std::fs::write("/tmp/yujin_headless.png", doc::encode_png(w, h, &px)).unwrap();
    // aller-retour enregistrement / ouverture
    let info = { let mut i = doc::DocInfo::new(w, h); i.layers.push(doc::LayerInfo::new("Calque 2")); i };
    let layers: Vec<Vec<u8>> = (0..2).map(|i| e.read_layer(i)).collect();
    doc::save(std::path::Path::new("/tmp/test.yujin"), &info, layers.clone(), None).unwrap();
    let (_i2, l2) = doc::load(std::path::Path::new("/tmp/test.yujin")).unwrap();
    let diff = layers[0].iter().zip(l2[0].iter()).map(|(a, b)| (*a as i32 - *b as i32).abs()).max().unwrap();
    println!("aller-retour .yujin : écart max {diff}");
    println!("OK");
}
