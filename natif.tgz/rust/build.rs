fn main() {
    // Icône de l'exe Windows
    if std::env::var("CARGO_CFG_TARGET_OS").as_deref() == Ok("windows") {
        let _ = embed_resource::compile("assets/app.rc", embed_resource::NONE);
    }
    println!("cargo:rerun-if-changed=assets/app.rc");
}
